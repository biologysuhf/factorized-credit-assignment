"""
P2 Experiment 3: emergent routing + superadditive synergy test.

Three latent contexts, no context labels:
  ctx0: arm0 -> Ber(0.9), arm1 -> Ber(0.1)
  ctx1: reversed
  ctx2: arm0 -> Ber(0.6) [risky, higher mean], arm1 -> 0.5 deterministic
        [safe, lower mean]: risk-neutral readout MUST pick the risky arm;
        only a distributional readout can express risk aversion (safe arm).

Policy: risk-averse readout for Q=7 models,
    V(x) = 0.5 * Vw.x + 0.5 * sum_q w_q V_{q,c}(x),  w_q ~ (1 - tau_q)^2
(scalar/compartment-only models have no distribution to read from).

Joint model must BOTH route contexts to compartments (memory) AND exploit
the learned distribution (risk-sensitive choice) -> synergy test:
    choice_quality(joint) > max(dist, comp).

Sweeps vary cue_noise (task overlap), switch rate -> gate purity.
"""
import numpy as np
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from p2_model import FactorizedModel, TAUS7, make_states

NCTX = 3
EPS = 0.10
NSEEDS = 20
RISK_W = 0.75
_w = (1 - np.array(TAUS7)) ** 2
W_RISK = _w / _w.sum()


def arm_rewards(c, a, rng):
    if c == 0:
        return float(rng.random() < (0.9 if a == 0 else 0.1))
    if c == 1:
        return float(rng.random() < (0.1 if a == 0 else 0.9))
    return float(rng.random() < 0.6) if a == 0 else 0.5   # ctx2: risky vs safe


OPT = {0: 0, 1: 1, 2: 1}     # risk-adjusted optimal arm per context


def gen_schedule(rng, T, switch_every):
    ctx = np.zeros(T, dtype=int)
    t, cur = 0, rng.integers(0, NCTX)
    while t < T:
        cur = (cur + rng.integers(1, NCTX)) % NCTX if t > 0 else cur
        L = int(rng.exponential(switch_every)) + 10
        ctx[t:t + L] = cur
        t += L
    return ctx


def risk_value(m, x, c=None):
    """behavioral value; Q=7 models add risk-averse distributional readout."""
    base = m.behavior_value(x, c)
    if m.Q < 7:
        return base
    risk = m.behavior_value(x, c, w=W_RISK)
    return (1 - RISK_W) * base + RISK_W * risk


def run(variant, seed, T=3000, switch_every=25, cue_noise=0.35):
    rng = np.random.default_rng(3000 + seed)
    oracle = variant == 'oracle'
    C = 1 if variant in ('scalar', 'dist') else 3
    Q = 7 if variant in ('dist', 'joint', 'oracle') else 1
    learn_gate = not oracle and C > 1
    m = FactorizedModel(nfeat=16, Q=Q, C=C, seed=seed,
                        eta_c=np.linspace(0.35, 0.15, C), lr_chan=0.2,
                        learn_A=(variant == 'joint'), learn_gate=learn_gate)
    arms = make_states(2, 16, seed=5)
    ctx_feats = make_states(NCTX, 16, seed=9)
    ctx = gen_schedule(rng, T, switch_every)

    correct = np.zeros(T)
    rew = np.zeros(T)
    gate_rec = np.zeros((T, C))
    for t in range(T):
        c = ctx[t]
        o = ctx_feats[c] + cue_noise * rng.standard_normal(16)
        o /= np.linalg.norm(o)
        g = m.gate(o, context=c)
        if rng.random() < EPS:
            a = rng.integers(0, 2)
        else:
            c_arg = c if oracle else None
            v0 = risk_value(m, arms[0], c_arg) + 0.02 * rng.standard_normal()
            v1 = risk_value(m, arms[1], c_arg) + 0.02 * rng.standard_normal()
            a = int(v1 > v0)
        r = arm_rewards(c, a, rng)
        m.learn(arms[a], r, context=c, g_pre=g, obs=o)
        rew[t] = r
        correct[t] = float(a == OPT[c])
        gate_rec[t] = g

    k = 50
    qual = float(np.convolve(correct, np.ones(k) / k, 'same')[k:-k].mean())
    # per-context late-phase quality
    late = np.arange(T) > T - 400
    q_by_ctx = {}
    for c in range(NCTX):
        msk = late & (ctx == c)
        q_by_ctx[c] = float(correct[msk].mean()) if msk.any() else np.nan
    purity = neff = np.nan
    if C > 1:
        assign = gate_rec.argmax(1)
        usage = np.array([(assign == j).mean() for j in range(C)])
        neff = float(np.exp(-(usage[usage > 1e-9]
                              * np.log(usage[usage > 1e-9])).sum()))
        purity = float(sum((assign == j).mean()
                           * max((ctx[assign == j] == c).mean()
                                 for c in range(NCTX))
                           for j in range(C) if (assign == j).any()))
    out = dict(qual=qual, q_by_ctx=q_by_ctx, purity=purity, neff=neff,
               rew=rew, gate_rec=gate_rec, ctx=ctx)
    if variant == 'joint':
        out['A'] = m.A.copy()
    return out


def summarize(res):
    for v in res:
        qs = [r['qual'] for r in res[v]]
        line = f"{v:8s} qual {np.mean(qs):.3f}±{np.std(qs):.3f}"
        q2 = [r['q_by_ctx'][2] for r in res[v] if not np.isnan(r['q_by_ctx'][2])]
        line += f"  ctx2-safe {np.mean(q2):.3f}"
        pur = [r['purity'] for r in res[v] if not np.isnan(r['purity'])]
        if pur:
            line += f"  purity {np.mean(pur):.3f}  neff {np.mean([r['neff'] for r in res[v] if not np.isnan(r['neff'])]):.2f}"
        print(line)


if __name__ == '__main__':
    variants = ['scalar', 'dist', 'comp', 'joint', 'oracle']
    res = {v: [] for v in variants}
    for v in variants:
        for s in range(NSEEDS):
            res[v].append(run(v, s))
    HERE = os.path.dirname(os.path.abspath(__file__))
    np.save(os.path.join(HERE, 'exp3_results.npy'), res, allow_pickle=True)
    summarize(res)

    # synergy: joint vs max(dist, comp), paired over seeds
    j = np.array([r['qual'] for r in res['joint']])
    best_base = np.maximum(np.array([r['qual'] for r in res['dist']]),
                           np.array([r['qual'] for r in res['comp']]))
    d = j - best_base
    from scipy import stats
    tt, pp = stats.ttest_1samp(d, 0)
    dz = d.mean() / d.std()
    print(f"\nsynergy joint-max(dist,comp): {d.mean():+.4f}±{d.std():.4f}  "
          f"t={tt:.2f} p={pp:.4f} dz={dz:.2f}")

    # sweeps
    sweeps = {}
    for noise in (0.15, 0.35, 0.6, 0.9):
        for v in ('comp', 'joint'):
            rs = [run(v, s, cue_noise=noise) for s in range(4)]
            sweeps[('noise', noise, v)] = dict(
                purity=float(np.mean([r['purity'] for r in rs])),
                qual=float(np.mean([r['qual'] for r in rs])))
    for sw in (20, 60, 150):
        for v in ('comp', 'joint'):
            rs = [run(v, s, switch_every=sw) for s in range(4)]
            sweeps[('switch', sw, v)] = dict(
                purity=float(np.mean([r['purity'] for r in rs])),
                qual=float(np.mean([r['qual'] for r in rs])))
    np.save(os.path.join(HERE, 'exp3_sweeps.npy'), sweeps, allow_pickle=True)
    for k_, v_ in sweeps.items():
        print(k_, {kk: round(vv, 3) for kk, vv in v_.items()})
