"""Fig 3 main figure plotting script (draft version).
Data: exp3_results.npy / exp3_sweeps.npy (20 seeds)
Output: fig3_mechanism_where.png
Note: compartment-to-context indices are randomly permuted per seed; before
      averaging across seeds, align by within-seed majority vote (permutation alignment),
      otherwise the specialization structure is diluted towards uniform.
"""
import sys, os, itertools
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

CODE = os.path.dirname(os.path.abspath(__file__))   # adjust to the actual path if needed
res = np.load(os.path.join(CODE, "exp3_results.npy"), allow_pickle=True).item()
sweeps = np.load(os.path.join(CODE, "exp3_sweeps.npy"), allow_pickle=True).item()

colors = {"scalar": "#888888", "dist": "#2176ae", "comp": "#e8a33d",
          "joint": "#c0392b", "oracle": "#2b2b2b"}
labels = {"scalar": "Scalar", "dist": "Dist-only", "comp": "Comp-only",
          "joint": "Joint", "oracle": "Oracle gate"}
variants = ["scalar", "dist", "comp", "joint", "oracle"]

# ---- per-context quality, mean +- SEM over 20 seeds ----
qbc = {v: {c: [] for c in range(3)} for v in variants}
for v in variants:
    for r in res[v]:
        for c in range(3):
            qbc[v][c].append(r["q_by_ctx"][c])
qmean = {v: [np.mean(qbc[v][c]) for c in range(3)] for v in variants}
qsem  = {v: [np.std(qbc[v][c], ddof=1)/np.sqrt(len(qbc[v][c])) for c in range(3)]
         for v in variants}

# ---- occupancy matrix, per-seed permutation-aligned ----
occ_seeds = []
for r in res["joint"]:
    g = r["gate_rec"].argmax(1); c = r["ctx"]
    M = np.zeros((3, 3), int)
    for j in range(3):
        msk = g == j
        if msk.any():
            M[j] = np.bincount(c[msk], minlength=3)
    bestp, bestscore = None, -1
    for p in itertools.permutations(range(3)):
        s = sum(M[j, p[j]] for j in range(3))
        if s > bestscore:
            bestscore, bestp = s, p
    oc = np.zeros((3, 3))
    for cc in range(3):
        col = np.bincount(g[c == cc], minlength=3) / len(g[c == cc])
        for j in range(3):
            oc[bestp[j], cc] = col[j]
    occ_seeds.append(oc)
occ = np.mean(occ_seeds, 0)

# ---- purity sweep ----
noises = [0.15, 0.35, 0.6, 0.9]
ps = {v: [sweeps[("noise", n, v)]["purity"] for n in noises]
      for v in ["comp", "joint"]}

# ---- example raster seed ----
r0 = res["joint"][0]
c0 = r0["ctx"]; g0 = r0["gate_rec"].argmax(1)
Cmap = {}
for j in range(3):
    msk = g0 == j
    Cmap[j] = int(np.bincount(c0[msk], minlength=3).argmax()) if msk.any() else j
mapped = np.array([Cmap[x] for x in g0])
hit = mapped == c0
purity0 = hit.mean()

fig = plt.figure(figsize=(16.5, 4.4), dpi=150)
gs = fig.add_gridspec(1, 4, wspace=0.34, width_ratios=[1.5, 1, 1.15, 1])

ax = fig.add_subplot(gs[0, 0])
t = np.arange(len(c0))
ax.step(t, c0, color="k", lw=1.3, where="post")
ax.scatter(t[hit], c0[hit] + 0.09, s=3, c="#2ca02c", label="Gate argmax (match)")
ax.scatter(t[~hit], mapped[~hit] + 0.09, s=4, c="#d62728",
           label="Gate argmax (mismatch)")
ax.set_yticks(range(3)); ax.set_yticklabels(["ctx0", "ctx1", "ctx2"])
ax.set_xlabel("Trial"); ax.set_xlim(0, 3000); ax.set_ylim(-0.4, 3.0)
ax.set_title("Unlabeled stream: gate tracks latent context",
             fontsize=10.5, loc="left", fontweight="bold")
ax.legend(fontsize=7.5, loc="upper center", frameon=False, ncols=2)
ax.text(0.01, 0.03, f"purity = {purity0:.3f} (example seed; n = 20 seeds)",
        transform=ax.transAxes, fontsize=8, color="#555")
ax.spines[["top", "right"]].set_visible(False)

ax = fig.add_subplot(gs[0, 1])
ax.imshow(occ, cmap="Blues", vmin=0, vmax=1)
for i in range(3):
    for j in range(3):
        ax.text(j, i, f"{occ[i, j]:.2f}", ha="center", va="center",
                fontsize=9.5, color="white" if occ[i, j] > 0.6 else "black")
ax.set_xticks(range(3)); ax.set_xticklabels(["ctx0", "ctx1", "ctx2"])
ax.set_yticks(range(3)); ax.set_yticklabels(["M0", "M1", "M2"])
ax.set_xlabel("True context"); ax.set_ylabel("Aligned compartment")
ax.set_title("Write events per compartment\n(per-seed aligned; chance = 0.33)",
             fontsize=10, loc="left", fontweight="bold")
axin = ax.inset_axes([0.5, 0.05, 0.48, 0.4])
axin.plot(noises, ps["joint"], "-o", c=colors["joint"], ms=3.5, lw=1.5, label="Joint")
axin.plot(noises, ps["comp"], "-s", c=colors["comp"], ms=3.5, lw=1.5,
          label="Comp-only")
axin.set_ylim(0.4, 1.02); axin.tick_params(labelsize=6.5)
axin.set_xlabel("Cue noise", fontsize=7); axin.set_ylabel("Purity", fontsize=7)
axin.legend(fontsize=6, frameon=False)
axin.set_title("routing fidelity vs task overlap", fontsize=7)

ax = fig.add_subplot(gs[0, 2])
x = np.arange(3); w = 0.16
for k, v in enumerate(variants):
    ax.bar(x + (k - 2) * w, qmean[v], w, yerr=qsem[v], color=colors[v],
           capsize=2.5, error_kw=dict(lw=0.9), label=labels[v])
ax.set_xticks(x); ax.set_xticklabels(["ctx0", "ctx1", "ctx2"])
ax.set_ylim(0, 1.05); ax.set_ylabel("Choice quality (learning off)")
ax.set_title("Post-stream probe per context", fontsize=10.5,
             loc="left", fontweight="bold")
ax.legend(fontsize=7, frameon=False, loc="lower left", ncols=2)
ax.spines[["top", "right"]].set_visible(False)

ax = fig.add_subplot(gs[0, 3])
vals = [qmean[v][2] for v in variants]
sems = [qsem[v][2] for v in variants]
ax.bar(range(5), vals, 0.62, yerr=sems, color=[colors[v] for v in variants],
       capsize=3, error_kw=dict(lw=1))
ax.axhline(0.5, ls=":", c="#777", lw=1)
ax.text(4.45, 0.515, "chance", fontsize=7.5, color="#777", ha="right")
ax.set_xticks(range(5))
ax.set_xticklabels([labels[v] for v in variants], rotation=18, ha="right")
ax.set_ylim(0, 1.05); ax.set_ylabel("Safe-arm choice (risk context)")
ax.set_title("Risk-averse readout from frozen memory", fontsize=10.5,
             loc="left", fontweight="bold")
ax.spines[["top", "right"]].set_visible(False)

fig.text(0.005, 0.935, "a", fontsize=15, fontweight="bold")
fig.text(0.295, 0.935, "b", fontsize=15, fontweight="bold")
fig.text(0.53, 0.935, "c", fontsize=15, fontweight="bold")
fig.text(0.772, 0.935, "d", fontsize=15, fontweight="bold")
out = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                   "fig3_mechanism_where.png")
fig.savefig(out, bbox_inches="tight")
print("saved:", os.path.abspath(out))
