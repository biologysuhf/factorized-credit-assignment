"""Supplementary Fig. 5: gating dynamics and robustness (2 panels), supports Fig. 6.
 Data: exp9v2_belief_gate.npy (a: joint per-seed dynamics aligned to switches, n=20)
             exp9v2_closing.npy (b: one-factor grid, n=10/cell off-default, n=20 default)
 Output: supplementary_fig5.png
"""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
CODE = os.path.dirname(os.path.abspath(__file__))   # adjust to the actual path if needed
d9 = np.load(os.path.join(CODE, "exp9v2_belief_gate.npy"), allow_pickle=True).item()
dc = np.load(os.path.join(CODE, "exp9v2_closing.npy"), allow_pickle=True).item()

fig = plt.figure(figsize=(9.6, 3.8), dpi=150)
gs = fig.add_gridspec(1, 2, wspace=0.32, width_ratios=[1.1, 1.25])

# ---------- a: switch-aligned dynamics (joint) ----------
ax = fig.add_subplot(gs[0, 0])
sty = {"belief_acc": ("#2c5fa0", "belief acc."),
       "choice_acc": ("#2e7d43", "choice acc."),
       "entropy": ("#a04a2c", "belief entropy (norm.)")}
for k in ["belief_acc", "choice_acc", "entropy"]:
    arr = np.array([r["dynamics"][k] for r in d9["res"]["joint"]
                    if r["dynamics"] is not None], dtype=float)
    m_ = np.nanmean(arr, axis=0)
    s_ = np.nanstd(arr, axis=0) / np.sqrt(len(arr))
    x = np.arange(1, len(m_) + 1)
    c, lab = sty[k]
    if k == "entropy":
        m_, s_ = m_ / np.log(4), s_ / np.log(4)
    ax.plot(x, m_, color=c, label=lab, lw=1.8)
    ax.fill_between(x, m_ - s_, m_ + s_, color=c, alpha=0.15, lw=0)
ax.set_xlabel("Trials since context switch")
ax.set_ylabel("Value (normalized)")
ax.set_ylim(0, 1.05)
ax.set_title("Switch-aligned dynamics (joint)", fontsize=10.5, loc="left",
             fontweight="bold")
ax.legend(fontsize=8, frameon=False)
ax.spines[["top", "right"]].set_visible(False)

# ---------- b: one-factor robustness ----------
ax = fig.add_subplot(gs[0, 1])
rob = dc["robustness"]
formal_delta = 0.2083
cells = [("W", 15), ("W", 25), ("W", 35),
         ("debounce", 6), ("debounce", 12), ("debounce", 18),
         ("lr_P", 0.0025), ("lr_P", 0.005), ("lr_P", 0.01)]
labels, vals, cols = [], [], []
for k, v in cells:
    if (k, v) in rob:
        vals.append(rob[(k, v)]["delta"])
        cols.append("#2c5fa0")
    else:
        vals.append(formal_delta)
        cols.append("#888888")
    lab = f"{k}={v}"
    labels.append(lab.replace("debounce", "D").replace("lr_P", "lr"))
ax.axhline(0, ls=":", c="k", lw=0.9)
ax.bar(range(len(cells)), vals, color=cols, width=0.66)
ax.set_xticks(range(len(cells)))
ax.set_xticklabels(labels, fontsize=7.5, rotation=30)
ax.set_ylabel(r"$\Delta$ synergy (joint − best control)")
ax.set_ylim(0, 0.36)
ax.set_title("One-factor robustness", fontsize=10.5, loc="left",
             fontweight="bold")
ax.text(0.97, 0.97,
        "gray = frozen default (n = 20);\nblue = one-factor cells (n = 10)",
        transform=ax.transAxes, fontsize=7.5, color="#444",
        ha="right", va="top")
ax.spines[["top", "right"]].set_visible(False)

for axx, L in zip(fig.axes, "ab"):
    axx.text(-0.14, 1.06, L, transform=axx.transAxes, fontsize=15,
             fontweight="bold", va="bottom", ha="right")
out = os.path.join(HERE, "supplementary_fig5.png")
fig.savefig(out, bbox_inches="tight")
print("saved:", os.path.abspath(out))
