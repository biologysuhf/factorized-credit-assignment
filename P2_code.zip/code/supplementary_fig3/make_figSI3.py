"""Supplementary Fig. 3: spiking-substrate controls (3 panels), supports Fig. 4.
 Panels: a = memory retention after reversal (bars),
                    b = retention x distributional-fidelity scatter,
                    c = AC-SNN revaluation (bars).
 Rationale for SI: overlaps with Figs. 2/5; kept as spiking supporting evidence.
 Data:
     a/b : snn_exp1_results.npy (8 seeds, error bars = std(ddof=1)/sqrt(8))
     c   : snn_exp6_revaluation.npy (20 seeds, error bars = std(ddof=1)/sqrt(20))
 Note: distributional fidelity in b is defined only for dist/joint (dist_L1 field);
             scalar/comp have no distributional code and are not plotted.
 Output: supplementary_fig3.png
"""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
CODE = os.path.dirname(os.path.abspath(__file__))   # adjust to the actual path if needed
res1 = np.load(os.path.join(CODE, "snn_exp1_results.npy"), allow_pickle=True).item()
res6 = np.load(os.path.join(CODE, "snn_exp6_revaluation.npy"), allow_pickle=True).item()

colors = {"scalar": "#888888", "dist": "#2176AE", "comp": "#E8A33D",
          "joint": "#C0392B", "oracle": "#2B2B2B", "randgate": "#7A5195"}
labels = {"scalar": "Scalar RPE", "dist": "Distributional only",
          "comp": "Compartment only", "joint": "Joint (full)",
          "oracle": "Oracle-gate", "randgate": "Rand-gate"}
V1 = ["scalar", "dist", "comp", "joint"]

fig = plt.figure(figsize=(10.8, 3.6), dpi=150)
gs = fig.add_gridspec(1, 3, wspace=0.4)

# ---------- a: memory retention after reversal ----------
ax = fig.add_subplot(gs[0, 0])
ret = [np.array([r["retention"] for r in res1[v]]) for v in V1]
xs = np.arange(4)
ax.bar(xs, [r.mean() for r in ret], 0.62,
       color=[colors[v] for v in V1],
       yerr=[r.std(ddof=1) / np.sqrt(len(r)) for r in ret],
       capsize=3, error_kw=dict(lw=1))
ax.axhline(0.5, color="k", ls=":", lw=0.9)
ax.set_xticks(xs)
ax.set_xticklabels(["Scalar", "Dist", "Comp", "Joint"], fontsize=8.5)
ax.set_ylim(0, 1.08)
ax.set_ylabel("Probe accuracy (return to A)")
ax.set_title("Memory retention after reversal", fontsize=10.5, loc="left",
             fontweight="bold")
ax.spines[["top", "right"]].set_visible(False)

# ---------- b: retention vs distributional fidelity ----------
ax = fig.add_subplot(gs[0, 1])
for v in ["dist", "joint"]:
    rv = np.mean([r["retention"] for r in res1[v]])
    fid = 1 - np.mean([r["dist_L1"] for r in res1[v]]) / 0.5
    ax.scatter(fid, rv, s=260, color=colors[v], zorder=3, edgecolor="k",
               lw=0.7, label=labels[v])
    if v == "joint":
        ax.annotate(labels[v], (fid, rv), textcoords="offset points",
                    xytext=(-8, 12), fontsize=8.5, ha="right")
    else:
        ax.annotate(labels[v], (fid, rv), textcoords="offset points",
                    xytext=(0, 14), fontsize=8.5, ha="center")
ax.text(0.03, 0.06,
        "Scalar / Comp: no distributional code,\n"
        "fidelity undefined (not shown)",
        transform=ax.transAxes, fontsize=7.5, color="#666")
ax.set_xlabel("Distributional fidelity (1 − norm. L1)")
ax.set_ylabel("Retention")
ax.set_xlim(-0.05, 1.06); ax.set_ylim(-0.05, 1.08)
ax.set_title("Spiking substrate keeps both", fontsize=10.5, loc="left",
             fontweight="bold")
ax.spines[["top", "right"]].set_visible(False)

# ---------- c: AC-SNN revaluation ----------
ax = fig.add_subplot(gs[0, 2])
V6 = ["scalar", "dist", "comp", "randgate", "joint", "oracle"]
rv = [np.array([r["reval_acc"] for r in res6[v]]) for v in V6]
xs = np.arange(len(V6))
ax.bar(xs, [r.mean() for r in rv], 0.66,
       color=[colors[v] for v in V6],
       yerr=[r.std(ddof=1) / np.sqrt(len(r)) for r in rv],
       capsize=3, error_kw=dict(lw=1))
ax.axhline(0.5, color="k", ls=":", lw=0.9)
ax.set_xticks(xs)
ax.set_xticklabels([labels[v] for v in V6], rotation=22, ha="right",
                   fontsize=7.5)
ax.set_ylim(0, 1.08); ax.set_ylabel("Zero-update accuracy")
ax.set_title("AC-SNN revaluation", fontsize=10.5, loc="left",
             fontweight="bold")
ax.spines[["top", "right"]].set_visible(False)

for axx, L in zip(fig.axes, "abc"):
    axx.text(-0.15, 1.06, L, transform=axx.transAxes, fontsize=15,
             fontweight="bold", va="bottom", ha="right")
fig.text(0.5, -0.02,
         "a/b: mean ± SEM, n = 8 seeds;   c: mean ± SEM, n = 20 seeds",
         fontsize=8, color="#444", ha="center", va="top")
out = os.path.join(HERE, "supplementary_fig3.png")
fig.savefig(out, bbox_inches="tight")
print("saved:", os.path.abspath(out))
