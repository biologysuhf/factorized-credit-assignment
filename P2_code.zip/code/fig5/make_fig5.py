"""Figure 5 | Embodied benchmark: factorization is necessary
Panels:
  a) Meta-World task cartoons + 2-box router/utility flow
  b) Ablation family + classic-CL baselines, two visual clusters
  c) Task x utility heatmap (correct/eligible over 5 seeds)
Usage: python make_fig5.py  (reads ./data/*.json, writes fig5_embodied.png)
"""
import json, glob, os, re
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import (FancyBboxPatch, FancyArrowPatch, Polygon,
                                Rectangle, Circle)
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.cm import ScalarMappable

COL = {"scalar": "#7f7f7f", "dist-only": "#1f77b4", "comp-only": "#ff9f1a",
       "random-gate": "#9467bd", "joint": "#d62728", "oracle": "#111111",
       "replay": "#8c564b", "ewc": "#8c564b", "si": "#8c564b"}
LBL = {"scalar": "Scalar", "dist-only": "Dist-only", "comp-only": "Comp-only",
       "random-gate": "Random-gate", "joint": "Joint", "oracle": "Oracle",
       "replay": "Replay", "ewc": "EWC", "si": "SI"}

def load_main():
    """Main GO set = gate_{v}_s{seed}.json files without _n/_gr suffixes"""
    out = {}
    for f in glob.glob("data/gate_*.json"):
        b = os.path.basename(f)
        m = re.match(r"gate_(\w+(?:-\w+)*)_s(\d+)\.json$", b)
        if not m:
            continue
        v, seed = m.group(1), int(m.group(2))
        out.setdefault(v, {})[seed] = json.load(open(f))
    return out

main = load_main()

fig = plt.figure(figsize=(16.5, 5.4))
ax_a = fig.add_axes([0.015, 0.02, 0.27, 0.86]); ax_a.axis("off")
ax_b = fig.add_axes([0.315, 0.13, 0.295, 0.72])
ax_c = fig.add_axes([0.655, 0.13, 0.27, 0.72])

# ================= panel a =================
def cartoon(ax, kind):
    """Meta-World task cartoons"""
    ax.set(xlim=(0, 1), ylim=(0, 1)); ax.axis("off")
    ax.add_patch(Polygon([[.07, .23], [.75, .23], [.94, .40], [.24, .40]],
                 facecolor="#E9EDF0", edgecolor="#BEC7CE", lw=.6))
    ax.add_patch(Rectangle((.13, .39), .14, .055, fc="#667888", ec="none"))
    pts = np.array([[.20, .44], [.25, .78], [.49, .85], [.64, .59]])
    ax.plot(pts[:, 0], pts[:, 1], color="#607D91", lw=7, solid_capstyle="round")
    ax.plot(pts[:, 0], pts[:, 1], color="#AFC1CD", lw=3.5, solid_capstyle="round")
    for p in pts[:-1]:
        ax.add_patch(Circle(p, .033, fc="#F5F7F8", ec="#607D91", lw=1))
    ax.plot([.61, .61, .67, .67], [.51, .58, .58, .51], color="#3B4C5A", lw=1.8)
    if kind == 0:      # push
        ax.add_patch(Polygon([[.60, .32], [.71, .32], [.74, .36], [.63, .36]],
                     fc="#D49A3D", ec="#A47629", lw=.6))
        ax.add_patch(Circle((.85, .34), .055, fc="none", ec="#6C9A7A", ls="--", lw=1))
        ax.add_patch(FancyArrowPatch((.71, .36), (.83, .36), arrowstyle="-|>",
                     mutation_scale=8, color=COL["joint"], lw=.8))
    elif kind == 1:    # peg insert
        ax.add_patch(Rectangle((.79, .32), .11, .22, fc="#AAB8C2", ec="#677D8C", lw=.7))
        ax.add_patch(Circle((.795, .425), .023, fc="white", ec="#445B6A", lw=.6))
        ax.plot([.64, .75], [.425, .425], color="#D49A3D", lw=4)
        ax.add_patch(FancyArrowPatch((.68, .50), (.78, .50), arrowstyle="-|>",
                     mutation_scale=8, color=COL["joint"], lw=.8))
    else:              # sweep
        for xy in [(.63, .34), (.68, .31), (.73, .35), (.70, .38)]:
            ax.add_patch(Circle(xy, .018, fc="#D49A3D"))
        ax.plot([.62, .62], [.51, .40], color="#3B4C5A", lw=2)
        ax.plot([.57, .69], [.40, .40], color="#607D91", lw=3)
        ax.add_patch(Rectangle((.84, .27), .065, .15, fc="#F4F7F4", ec="#6C9A7A",
                     ls="--", lw=.8))
        ax.add_patch(FancyArrowPatch((.72, .39), (.85, .39), arrowstyle="-|>",
                     mutation_scale=8, color=COL["joint"], lw=.8))
    ax.text(.5, .02, ["push", "peg insert", "sweep"][kind],
            ha="center", fontsize=8.5, fontweight="bold")

for i in range(3):
    cartoon(fig.add_axes([0.028 + i * 0.088, 0.615, 0.082, 0.255]), i)
fig.text(0.155, 0.588, "unlabelled stream · no task ID",
         ha="center", fontsize=8, color="#5F6B75")

ax_a.set_xlim(0, 1); ax_a.set_ylim(0, 1)
ax_a.add_patch(FancyBboxPatch((0.07, 0.30), 0.86, 0.205,
               boxstyle="round,pad=0.012,rounding_size=0.03",
               fc="#fff4e6", ec="#d62728", lw=1.2))
ax_a.text(0.5, 0.455, "router", ha="center", fontsize=9.5, color="#d62728",
          fontweight="bold")
ax_a.text(0.5, 0.38, "which context am I in?\nwrite credit to that compartment",
          ha="center", va="center", fontsize=8.5)
ax_a.add_patch(FancyBboxPatch((0.07, 0.02), 0.86, 0.185,
               boxstyle="round,pad=0.012,rounding_size=0.03",
               fc="#eaf7ea", ec="#2ca02c", lw=1.2))
ax_a.text(0.5, 0.15, "utility announced\nzero-update revaluation",
          ha="center", va="center", fontsize=8.5)
# figure coordinates: ax_a left 0.015, width 0.27, bottom 0.02, height 0.86
fig.add_artist(FancyArrowPatch((0.150, 0.613), (0.150, 0.470),
               transform=fig.transFigure, arrowstyle="-|>",
               mutation_scale=11, color="#888", lw=0.9))
fig.add_artist(FancyArrowPatch((0.150, 0.278), (0.150, 0.208),
               transform=fig.transFigure, arrowstyle="-|>",
               mutation_scale=11, color="#888", lw=0.9))
ax_a.set_title("Meta-World benchmark", fontsize=11, pad=30)

# ================= panel b =================
abl = ["scalar", "dist-only", "comp-only", "random-gate", "joint", "oracle"]
cl = ["replay", "ewc", "si"]
order = abl + cl
means, pts, colors, hatches = [], [], [], []
for v in order:
    if v not in main:
        print(f"WARN: variant {v} not found in data/ (skipped)")
        means.append(np.nan); pts.append([]); colors.append(COL[v])
        hatches.append("//" if v in cl else "")
        continue
    seeds = sorted(main[v])
    R = [main[v][s]["R_reval"] for s in seeds]
    means.append(float(np.mean(R))); pts.append(R)
    colors.append(COL[v]); hatches.append("" if v in abl else "//")
x = np.arange(len(order))
for i, v in enumerate(order):
    if pts[i] is None:
        continue
    m = means[i]; c = COL[v]
    sd = float(np.std(pts[i]))
    ax_b.errorbar([x[i]], [m], yerr=[sd], fmt="none", ecolor="#333",
                  elinewidth=1.1, capsize=3.5, zorder=2)
    ax_b.plot([x[i] - 0.14, x[i] + 0.14], [m, m], color="black", lw=1.7,
              zorder=4, solid_capstyle="butt")
    ax_b.scatter([x[i]] * len(pts[i]), pts[i], color=c, edgecolor="black",
                 s=26, zorder=3, linewidth=0.7)
ax_b.axvline(len(abl) - 0.5, color="black", ls=":", lw=1)
ax_b.text(np.mean(x[:len(abl)]), 1.045, "Removing factorization",
          ha="center", fontsize=9.5, style="italic")
ax_b.text(np.mean(x[len(abl):]), 1.045, "Conventional CL strategies",
          ha="center", fontsize=9.5, style="italic")
ax_b.set_xticks(x)
ax_b.set_xticklabels([LBL[v] for v in order], rotation=28, ha="right", fontsize=9)
ax_b.set_ylim(0, 1.09); ax_b.set_ylabel("Revaluation accuracy $R$")
ax_b.set_title("Factorization is necessary", fontsize=11)
ax_b.axhline(0.5, color="gray", lw=0.6, ls="--")
ax_b.spines[["top", "right"]].set_visible(False)

# ================= panel c: task x utility heatmap =================
tasks = ["push", "peg_insert", "sweep"]
utils = ["mean", "cvar_lo", "cvar_hi", "unseen_0.05", "unseen_0.15", "unseen_0.20"]
uselbl = ["mean", "CVaR$_-$", "CVaR$_+$", "$u_{.05}$", "$u_{.15}$", "$u_{.20}$"]
vs = ["dist-only", "comp-only", "joint"]
ROW0 = {0: 1, 1: 5, 2: 9}          # start row of each task block (rows 0/4/8 are spacer label rows)
mat = np.full((12, 6), np.nan)
cnt = {}
for ti, task in enumerate(tasks):
    for vi, v in enumerate(vs):
        for ui, u in enumerate(utils):
            corr = elig = 0
            for s in sorted(main.get(v, {})):
                d = main[v][s]
                if "margins" not in d:
                    continue
                e = bool(d["margins"][task][u][2])
                elig += e
                corr += e and (d["pred"][task][u] == d["gt_best"][task][u])
            if elig:
                mat[ROW0[ti] + vi, ui] = corr / elig
                cnt[(ti, vi, ui)] = (corr, elig)

cmap = LinearSegmentedColormap.from_list("acc", ["#ffffff", "#d62728"])
cmap.set_bad("#ececec")
ax_c.imshow(np.ma.masked_invalid(mat), vmin=0, vmax=1, cmap=cmap,
            aspect="auto", interpolation="nearest")
for ri in range(12):
    if ri in (0, 4, 8):
        continue                      # spacer row: white band carrying the task name
    for ui in range(6):
        z = mat[ri, ui]
        if np.isnan(z):
            ax_c.text(ui, ri, "n/e", ha="center", va="center",
                      fontsize=7, color="#999")
        else:
            ti = 0 if ri < 4 else (1 if ri < 8 else 2)
            c, e = cnt[(ti, ri - ROW0[ti], ui)]
            ax_c.text(ui, ri, f"{c}/{e}", ha="center", va="center",
                      fontsize=7.5, color="white" if z >= 0.65 else "#49382F")
for b in (0.5, 4.5, 8.5):
    ax_c.axhline(b, color="white", lw=5)
ax_c.axvline(2.5, color="white", lw=3)
ax_c.set_xticks(range(6)); ax_c.set_xticklabels(uselbl, fontsize=8.5)
ax_c.set_yticks([r for r in range(12) if r not in (0, 4, 8)])
ax_c.set_yticklabels([LBL[v] for v in vs] * 3, fontsize=8.5)
for tl, v in zip(ax_c.get_yticklabels(), vs * 3):
    tl.set_color(COL[v])
interf = {"push": "high interference", "peg_insert": "moderate interference",
          "sweep": "low interference"}
for y, task in ((0, "push"), (4, "peg_insert"), (8, "sweep")):
    ax_c.text(2.5, y, f"{task.replace('_', ' ')} · {interf[task]}",
              ha="center", va="center", fontsize=9.5, fontweight="bold",
              color="#3B4C5A")
ax_c.set_xticks(np.arange(-.5, 6), minor=True)
ax_c.set_yticks(np.arange(-.5, 12), minor=True)
ax_c.grid(which="minor", color="white", lw=1.2)
ax_c.tick_params(which="minor", length=0)
ax_c.tick_params(length=0)
for sp in ax_c.spines.values():
    sp.set_visible(False)
ax_c.set_title("Selective memory preservation across utility objectives",
               fontsize=11)
cax = fig.add_axes([0.938, 0.13, 0.011, 0.28])
cb = fig.colorbar(ScalarMappable(norm=Normalize(0, 1), cmap=cmap), cax=cax,
                  ticks=[0, 0.5, 1])
cb.ax.tick_params(labelsize=7, length=2)
cb.outline.set_visible(False)
cb.set_label("correct / eligible", fontsize=7.5, color="#555")

for a, tag in ((ax_a, "a"), (ax_b, "b"), (ax_c, "c")):
    a.text(-0.10, 1.045, tag, transform=a.transAxes, fontsize=15,
           fontweight="bold", va="bottom")

fig.savefig("fig5_embodied.png", dpi=300, bbox_inches="tight", facecolor="white")
print("saved fig5_embodied.png")
