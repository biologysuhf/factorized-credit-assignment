# -*- coding: utf-8 -*-
"""dump_interference_overlap_v3.py  Fig 5d interference metrics (v3: density correction + z-distribution overlap)

v2 finding: under expert primitives the step-level observation streams are still fully
separable (NN=0), but reach=1.000 is a density artefact (peg 30846 steps vs push 12613;
nearest neighbours are density-sensitive, denser streams always win). v3 corrections:

  A. Observation-stream overlap (density-corrected): subsample each stream to COMMON_N
     points before NN-confusion, average both directions; same for reach segments and trial signatures.
  B. New: outcome-distribution (z-space) overlap - read per-task safe/risky z values
     from gt_out/*.npz (z = success - 0.3 t/t_ref - 0.02 e/e_ref - 0.5 i/i_ref, as in mvp),
     compute pairwise task overlap (OVL / Wasserstein / KS) and within-task safe/risky
     separability (AUC, thin-margin metric). This directly measures the "contamination"
     when credit is written to the wrong compartment: the larger |z_A - z_B|, the worse

Run (in the benchmark directory):
    python dump_interference_overlap_v3.py
Output:
    task_overlap_dump_v3.json
"""
import json
import os
import numpy as np

from primitives import make_env, Primitive, PHYS_RAND
import mujoco

TASKS = ["push", "peg_insert", "sweep"]
EPISODES_PER_STYLE = 100
REACH_K = 30
SEED = 0
COMMON_N = 12000        # per-stream subsample size (step level)
COMMON_N_REACH = 6000
OUT = "task_overlap_dump_v3.json"
def _gt_paths(t):
    return f"gt_out/{t}_safe.npz", f"gt_out/{t}_risky.npz"


# ---------------------------------------------------------------- A. observation streams
def physics_rand(env, rng):
    model = env.unwrapped.model
    body_id = -1
    for cand in ("obj", "drawer_link", "window", "btn"):
        bid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, cand)
        if bid >= 0:
            body_id = bid
            break
    if body_id < 0:
        return
    base = getattr(env, "_base_mass", None)
    if base is None:
        base = env._base_mass = {}
    if body_id not in base:
        base[body_id] = float(model.body_mass[body_id])
        gid0 = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_GEOM, "objGeom")
        if gid0 >= 0:
            base[("fric", gid0)] = float(model.geom_friction[gid0][0])
    model.body_mass[body_id] = base[body_id] * float(rng.uniform(*PHYS_RAND["mass_range"]))
    gid0 = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_GEOM, "objGeom")
    if gid0 >= 0:
        model.geom_friction[gid0][0] = base[("fric", gid0)] * float(rng.uniform(*PHYS_RAND["friction_range"]))


def rollout_trial(env, train_tasks, rng, prim):
    task = train_tasks[int(rng.integers(len(train_tasks)))]
    env.set_task(task)
    obs, _ = env.reset()
    if hasattr(prim, "reset"):
        prim.reset()
    physics_rand(env, rng)
    buf = [obs.copy()]
    for _ in range(int(env.max_path_length)):
        a = prim.act(obs)
        obs, r, term, trunc, info = env.step(a)
        buf.append(obs.copy())
        if term or trunc or info.get("success", 0) > 0:
            break
    O = np.atleast_2d(np.asarray(buf, dtype=np.float32))
    return O[0], O.mean(axis=0), O[-1], O


def collect(task_key):
    env, train_tasks, _ = make_env(task_key, SEED + 7)
    rng = np.random.default_rng(SEED * 1000 + 7)
    inits, means, lasts, steps = [], [], [], []
    for style in ("safe", "risky"):
        for ep in range(EPISODES_PER_STYLE):
            prim = Primitive(task_key, style, SEED * 100000 + ep)
            i0, m0, l0, S = rollout_trial(env, train_tasks, rng, prim)
            inits.append(i0); means.append(m0); lasts.append(l0); steps.append(S)
    env.close()
    return (np.asarray(inits), np.asarray(means), np.asarray(lasts), steps)


def subsample(X, n, seed):
    rng = np.random.default_rng(seed)
    if len(X) <= n:
        return X
    return X[rng.choice(len(X), n, replace=False)]


def standardize(streams):
    pooled = np.concatenate(streams, axis=0)
    mu = pooled.mean(axis=0)
    sd = pooled.std(axis=0)
    sd = np.where(sd < 1e-6, 1.0, sd)
    return [(s - mu) / sd for s in streams]


def nn_confusion_sym(Xa, Xb, seed=0):
    """Density-corrected NN-confusion: equal-size subsampling + bidirectional mean. Same distribution -> 0.5."""
    n = min(len(Xa), len(Xb))
    Xa = subsample(Xa, n, seed)
    Xb = subsample(Xb, n, seed + 1)
    def one_way(A, B, s):
        rng = np.random.default_rng(s)
        d_self = np.empty(len(A)); d_cross = np.empty(len(A))
        for i in range(0, len(A), 100):
            j = min(i + 100, len(A))
            Da = np.linalg.norm(A[i:j, None, :] - A[None, :, :], axis=2)
            for k, ii in enumerate(range(i, j)):
                Da[k, ii] = np.inf
            d_self[i:j] = Da.min(axis=1)
            d_cross[i:j] = np.linalg.norm(A[i:j, None, :] - B[None, :, :], axis=2).min(axis=1)
        return float(np.mean(d_cross < d_self))
    ab = one_way(Xa, Xb, seed + 2)
    ba = one_way(Xb, Xa, seed + 3)
    return (ab + ba) / 2.0, ab, ba


# ---------------------------------------------------------------- B. z distributions
def load_z(task):
    """Read gt_out/<t>_safe.npz and <t>_risky.npz (fields success/time/energy/impact),
    compute z = success - 0.3 t/t_ref - 0.02 e/e_ref - 0.5 i/i_ref as in mvp.
    Reference values taken from the safe stream (consistent with mvp.run refs)."""
    ps, pr = _gt_paths(task)
    if not (os.path.exists(ps) and os.path.exists(pr)):
        return None
    S, R = np.load(ps, allow_pickle=True), np.load(pr, allow_pickle=True)
    succ = S["success"].astype(float)
    t_ref = max(float(np.median(S["time"][S["success"] == 1])), 1e-6)
    e_ref = max(float(np.median(S["energy"][S["success"] == 1])), 1e-6)
    i_ref = max(float(np.quantile(S["impact"], 0.9)), 1.0)
    def z_of(a):
        return (a["success"].astype(float)
                - 0.3 * a["time"] / t_ref
                - 0.02 * a["energy"] / e_ref
                - 0.5 * a["impact"] / i_ref)
    return dict(safe=z_of(S), risky=z_of(R))


def ovl(x, y, gridsize=2000):
    """Overlap coefficient OVL = integral of min(p(x), q(x)) via histogram density estimate."""
    lo = min(x.min(), y.min()); hi = max(x.max(), y.max())
    gx = np.linspace(lo, hi, gridsize)
    px = np.histogram(x, bins=gx, density=True)[0]
    py = np.histogram(y, bins=gx, density=True)[0]
    binw = gx[1] - gx[0]
    return float(np.sum(np.minimum(px, py)) * binw)


def wasserstein_1d(x, y):
    xs = np.sort(x); ys = np.sort(y)
    n = min(len(xs), len(ys))
    qs = np.linspace(0, 1, n)
    return float(np.mean(np.abs(np.quantile(xs, qs) - np.quantile(ys, qs))))


def ks_stat(x, y):
    xs = np.sort(x); ys = np.sort(y)
    allv = np.sort(np.concatenate([xs, ys]))
    fx = np.searchsorted(xs, allv, side="right") / len(xs)
    fy = np.searchsorted(ys, allv, side="right") / len(ys)
    return float(np.max(np.abs(fx - fy)))


def auc_safe_risky(zs, zr):
    """P(z_risky > z_safe): within-task safe/risky separability (thin-margin metric)."""
    gt = (zr[:, None] > zs[None, :]).mean()
    return float(gt)


# ---------------------------------------------------------------- main
def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--z-only", action="store_true",
                    help="compute only z-distribution overlap (skip observation-stream rollouts; requires part A already run)")
    z_only = ap.parse_args().z_only
    print("[v3.1] dump_interference_overlap_v3" + (" (z-only)" if z_only else ""))
    out = {"config": dict(episodes_per_style=EPISODES_PER_STYLE, reach_k=REACH_K,
                          seed=SEED, common_n=COMMON_N, policy="expert_safe+risky")}

    # ---- A. observation-stream overlap (density-corrected)
    if not z_only:
        _part_a(out)
    else:
        try:
            with open(OUT, encoding="utf-8") as f:
                prev = json.load(f)
            out["summary_stream"] = prev.get("summary_stream", {})
        except FileNotFoundError:
            pass
    _part_b_z(out)

    print("\n===== Summary =====")
    if "summary_stream" in out:
        for t in TASKS:
            s = out["summary_stream"][t]
            print(f"  [stream] {t:10s} I_step={s['I_step']:.3f}  I_reach={s['I_reach']:.3f}  I_sig={s['I_signature']:.3f}")
    if "summary_z" in out:
        for t in TASKS:
            s = out["summary_z"][t]
            print(f"  [z]      {t:10s} I_OVL={s['I_OVL']:.3f}  safe/risky AUC={s['safe_risky_AUC']:.3f}")
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    print(f"\nwrote {OUT}")


def _part_a(out):
        data = {}
        for t in TASKS:
            i0, m0, l0, steps = collect(t)
            data[t] = dict(init=i0, mean=m0, last=l0, steps=steps)
            print(f"[collect] {t:10s} trials={len(steps)} steps={sum(len(s) for s in steps)}")

        I_step, I_reach, I_sig = ({t: [] for t in TASKS} for _ in range(3))
        for a in range(len(TASKS)):
            for b in range(a + 1, len(TASKS)):
                A, B = TASKS[a], TASKS[b]
                tag = f"{A}__{B}"
                stepA = np.concatenate(data[A]["steps"])
                stepB = np.concatenate(data[B]["steps"])
                (XsA, XsB) = standardize([subsample(stepA, COMMON_N, 1), subsample(stepB, COMMON_N, 2)])
                sym, ab, ba = nn_confusion_sym(XsA, XsB, seed=hash(tag) % (2**31))

                rA = np.concatenate([s[:REACH_K] for s in data[A]["steps"]])
                rB = np.concatenate([s[:REACH_K] for s in data[B]["steps"]])
                (XrA, XrB) = standardize([subsample(rA, COMMON_N_REACH, 3), subsample(rB, COMMON_N_REACH, 4)])
                rsym, rab, rba = nn_confusion_sym(XrA, XrB, seed=hash(tag + "_r") % (2**31))

                SA = np.concatenate([data[A]["init"], data[A]["mean"], data[A]["last"]], axis=1)
                SB = np.concatenate([data[B]["init"], data[B]["mean"], data[B]["last"]], axis=1)
                (XsA2, XsB2) = standardize([SA, SB])
                ssym, sab, sba = nn_confusion_sym(XsA2, XsB2, seed=hash(tag + "_sig") % (2**31))

                out[f"stream_{tag}"] = dict(step_sym=sym, step_ab=ab, step_ba=ba,
                                            reach_sym=rsym, reach_ab=rab, reach_ba=rba,
                                            sig_sym=ssym, sig_ab=sab, sig_ba=sba)
                print(f"[pair] {A:10s} vs {B:10s} step={sym:.3f} reach={rsym:.3f} sig={ssym:.3f}")
                for t, v1, v2, v3 in ((A, sym, rsym, ssym), (B, sym, rsym, ssym)):
                    I_step[t].append(v1); I_reach[t].append(v2); I_sig[t].append(v3)

        out["summary_stream"] = {t: dict(I_step=float(np.mean(I_step[t])),
                                         I_reach=float(np.mean(I_reach[t])),
                                         I_signature=float(np.mean(I_sig[t]))) for t in TASKS}


def _part_b_z(out):
    """z-distribution overlap (GT): cross-task OVL/W1/KS + within-task safe/risky AUC."""
    Z = {}
    for t in TASKS:
        z = load_z(t)
        if z is None:
            print(f"[warn] GT npz not found for {t} (expected {_gt_paths(t)}); skipping z part")
            return
        Z[t] = z
    Zov, Zwd, Zks, AUC = {}, {}, {}, {}
    for a in range(len(TASKS)):
        for b in range(a + 1, len(TASKS)):
            A, B = TASKS[a], TASKS[b]
            tag = f"{A}__{B}"
            x = np.concatenate([Z[A]["safe"], Z[A]["risky"]])
            y = np.concatenate([Z[B]["safe"], Z[B]["risky"]])
            Zov[tag] = ovl(x, y)
            Zwd[tag] = wasserstein_1d(x, y)
            Zks[tag] = ks_stat(x, y)
            print(f"[z] {A:10s} vs {B:10s} OVL={Zov[tag]:.3f} W1={Zwd[tag]:.3f} KS={Zks[tag]:.3f}")
    for t in TASKS:
        AUC[t] = auc_safe_risky(Z[t]["safe"], Z[t]["risky"])
        print(f"[z] {t:10s} safe/risky AUC={AUC[t]:.3f}")
    out["z_overlap"] = dict(OVL=Zov, W1=Zwd, KS=Zks, safe_risky_AUC=AUC)
    out["summary_z"] = {t: dict(
        I_OVL=float(np.mean([Zov[f"{t}__{o}"] if f"{t}__{o}" in Zov else Zov[f"{o}__{t}"]
                             for o in TASKS if o != t])),
        safe_risky_AUC=AUC[t]) for t in TASKS}


if __name__ == "__main__":
    main()
