"""Standalone re-render of Fig 5b (corrected version, 2026-10-20).
 Fix: a previously circulated render of panel b had values (joint~0.92/comp~0.49/
 oracle~0.97/replay~0.65/ewc~0.63/si~0.62) matching no archived round; source unknown.
 This script reads only the final archived round data/gate_*.json (2026-09 calibration round).
 Recomputed values: scalar/dist/comp/random-gate/si = 0.667 (constant), joint 0.983 +/- 0.017 (SD),
oracle 1.0，replay/ewc 0.683。
 Plotting identical to panel b of make_fig5.py (mean +/- SD, per-seed scatter).
 Usage: python3 make_fig5b.py  (run in the fig5 directory; reads ./data/)
 Output: fig5b_panel.png
"""
import json, glob, re
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

COL = {"scalar": "#7f7f7f", "dist-only": "#1f77b4", "comp-only": "#ff9f1a",
       "random-gate": "#9467bd", "joint": "#d62728", "oracle": "#111111",
       "replay": "#8c564b", "ewc": "#8c564b", "si": "#8c564b"}
LBL = {"scalar": "Scalar", "dist-only": "Dist-only", "comp-only": "Comp-only",
       "random-gate": "Random-gate", "joint": "Joint", "oracle": "Oracle",
       "replay": "Replay", "ewc": "EWC", "si": "SI"}

main = {}
for f in glob.glob("data/gate_*.json"):
    m = re.match(r"gate_(\w+(?:-\w+)*)_s(\d+)\.json$", f.split("/")[-1])
    main.setdefault(m.group(1), {})[int(m.group(2))] = json.load(open(f))

abl = ["scalar", "dist-only", "comp-only", "random-gate", "joint", "oracle"]
cl = ["replay", "ewc", "si"]
order = abl + cl

fig, ax_b = plt.subplots(figsize=(5.6, 3.4), dpi=300)
means, pts = [], []
for v in order:
    R = [main[v][s]["R_reval"] for s in sorted(main[v])]
    means.append(float(np.mean(R))); pts.append(R)
x = np.arange(len(order))
for i, v in enumerate(order):
    m = means[i]; c = COL[v]
    sd = float(np.std(pts[i]))
    ax_b.errorbar([x[i]], [m], yerr=[sd], fmt="none", ecolor="#333",
                  elinewidth=1.1, capsize=3.5, zorder=2)
    ax_b.plot([x[i] - 0.14, x[i] + 0.14], [m, m], color="black", lw=1.7,
              zorder=4, solid_capstyle="butt")
    ax_b.scatter([x[i]] * len(pts[i]), pts[i], color=c, edgecolor="black",
                 s=26, zorder=3, linewidth=0.7)
ax_b.axvline(len(abl) - 0.5, color="black", ls=":", lw=1)
ax_b.text(np.mean(x[:len(abl)]), 1.045, "Removing factorization",
          ha="center", fontsize=9.5, style="italic")
ax_b.text(np.mean(x[len(abl):]), 1.045, "Conventional CL strategies",
          ha="center", fontsize=9.5, style="italic")
ax_b.set_xticks(x)
ax_b.set_xticklabels([LBL[v] for v in order], rotation=28, ha="right",
                     fontsize=9)
ax_b.set_ylim(0, 1.09); ax_b.set_ylabel("Revaluation accuracy $R$")
ax_b.set_title("Factorization is necessary", fontsize=11)
ax_b.axhline(0.5, color="gray", lw=0.6, ls="--")
ax_b.spines[["top", "right"]].set_visible(False)
ax_b.text(-0.16, 1.06, "b", transform=ax_b.transAxes, fontsize=15,
          fontweight="bold", va="top")
fig.text(0.5, -0.06, "b: mean +/- SD, n = 5 seeds; dots = individual seeds. "
         "Data: final calibration round (data/gate_*.json, 2026-09).",
         ha="center", fontsize=8, color="#444")
fig.tight_layout()
fig.savefig("fig5b_panel.png", bbox_inches="tight")
print("saved fig5b_panel.png")
print({v: round(means[i], 4) for i, v in enumerate(order)})
