"""Phase III gatekeeper - one question only: does the Joint variant, frozen,
reliably recover the optimal primitive for each announced utility?

Variants (terminology):
    dist-only  = expectile channels x single shared compartment (no routing)
    comp-only  = mean channel x compartment routing (no distribution)
    joint      = channels x routing (full model)
    oracle     = joint + ground-truth task id

Training: utility-blind, round-robin primitive exploration (c = t % 2, avoiding
tail-sample starvation from max-mean selection); 2 epochs x 3 tasks x N trials
per task in fixed-sequence blocks; latent variants receive no task ID and
route from observation belief.

Primary GO: R_reval(joint) >= 0.75 and d_syn = R_joint - max(R_dist, R_comp) > 0.10.
Secondary GO: same-direction advantage in >=2/3 of tasks.
Usage: python3 gatekeeper_v116.py --seed 0 --trials 600 --variants dist-only,comp-only,joint,oracle
"""
import sys, os, json, argparse
import numpy as np
sys.path.insert(0, ".")
sys.path.insert(0, ".")

import mvp
from mvp import (TASK_ORDER, SAFE, RISKY, TAUS, prim_instance, trial,
                 load_gt, z_of_gt, utility_vals, UTILITIES, make_env, TASKS)
from p2_agent import make_selector

MARGIN_FLOOR = 0.02  # v1.3: preregistered exclusion of ambiguous pairs, |margin| >= max(floor, 2*SE)

def margins_and_eligibility(gt, refs, rng, n_boot=400, chunk=1000,
                            task_list=None):
    task_list = task_list or TASK_ORDER
    """v1.4 dual gating. For each (task, utility):
    (a) pooled |margin| >= max(0.02, 2xSE_boot);
    (b) chunk stability: split GT by generation chunk (1000 each, independent seed streams);
        all chunk margins share a sign and |median chunk margin| >= 0.02.
    A probe counts only if both hold. Returns {task: {u: (margin, se, eligible, chunk_median)}}"""
    out = {}
    for tk in task_list:
        zr = {st: np.array([mvp._z(r, *refs[tk]) for r in z_of_gt(gt, tk, st)])
              for st in ("safe", "risky")}
        out[tk] = {}
        n = min(len(zr["safe"]), len(zr["risky"]))
        n_chunk = n // chunk
        for u in UTILITIES:
            vs, vr = utility_vals(zr["safe"], u), utility_vals(zr["risky"], u)
            margin = float(vs - vr)
            boots = []
            ns, nr = len(zr["safe"]), len(zr["risky"])
            for _ in range(n_boot):
                bs = zr["safe"][rng.integers(0, ns, ns)]
                br = zr["risky"][rng.integers(0, nr, nr)]
                boots.append(utility_vals(bs, u) - utility_vals(br, u))
            se = float(np.std(boots))
            ok_a = abs(margin) >= max(MARGIN_FLOOR, 2 * se)
            if n_chunk >= 2:
                cs = zr["safe"][:n_chunk*chunk].reshape(n_chunk, chunk)
                cr = zr["risky"][:n_chunk*chunk].reshape(n_chunk, chunk)
                cm = np.array([utility_vals(cs[i], u) - utility_vals(cr[i], u)
                               for i in range(n_chunk)])
                sign_ok = (cm > 0).all() or (cm < 0).all()
                ok_b = sign_ok and abs(float(np.median(cm))) >= MARGIN_FLOOR
                cmed = float(np.median(cm))
            else:
                ok_b, cmed = True, margin   # skip the stability test when GT is too short (fallback)
            out[tk][u] = (margin, se, bool(ok_a and ok_b), cmed)
    return out
VARIANT_MAP = {"dist-only": "shared", "comp-only": "mean",
               "joint": "joint", "oracle": "oracle",
               # v1.15: scalar baseline (no routing x no distribution)
               "scalar": "scalar",
               # v1.15 fix: random-gate raised KeyError when run via CLI -
               # VARIANT_MAP never registered that key (the GO-round four variants
               # do not include it and the smoke test missed it); exposed by the Exp1 rerun
               "random-gate": "random-gate",
               "explicit-ID": "explicit-ID",
               # v1.16 classic CL baselines (online adaptive versions; SI section) - same
               # skeleton as dist-only (single shared compartment, all tau channels); the only
               # difference is the interference-protection mechanism itself. Preregistered
               # prediction: ~dist-only (0.667) or lower, because classic CL addresses
               "replay": "replay", "ewc": "ewc", "si": "si"}

def run_variant(name, seed, trials_per_task, epochs, out_path,
                tasks=None, gate_radius=None):
    style = VARIANT_MAP[name]
    # v1.15 Exp2 groundwork: --tasks for multiple tasks (default push/peg/sweep)
    task_list = list(tasks) if tasks else list(TASK_ORDER)
    n_tasks = len(task_list)
    rng = np.random.default_rng(seed)
    phys_rng = np.random.default_rng(seed + 999)
    import pickle, hashlib
    # v1.15 fix: with multiple tasks the GT cache must be keyed per task set - the original
    # shared _gt_cache.pkl let the default three-task cache be reused for N=3/N=6, missing
    # new task keys (KeyError in Exp2 N=3 with drawer_open); load_gt now takes tasks
    tl_key = hashlib.md5(",".join(task_list).encode()).hexdigest()[:8]
    cache_path = f"gt_out/_gt_cache_{tl_key}.pkl"
    if os.path.exists(cache_path):
        with open(cache_path, "rb") as f:
            gt = pickle.load(f)
    else:
        gt = load_gt(tasks=task_list)
        os.makedirs("gt_out", exist_ok=True)
        with open(cache_path, "wb") as f:
            pickle.dump(gt, f)
    refs, gt_best, gt_margins = {}, {}, {}
    # v1.9: eligible-utility determination (denominator n_eligible) is an intrinsic property
    # of the GT and must use a fixed seed - per-run seeding let the same GT yield 10 vs 13
    # eligible probes across seeds, making denominators inconsistent across seeds
    boot_rng = np.random.default_rng(20240601)
    for tk in task_list:
        srows = z_of_gt(gt, tk, "safe")
        succ = [r for r in srows if r.success]
        t_ref = float(np.median([r.time for r in succ])) or 1.0
        e_ref = float(np.median([r.energy for r in succ])) or 1.0
        i_ref = max(float(np.quantile([r.impact_max for r in srows], 0.9)), 1.0)
        refs[tk] = (t_ref, e_ref, i_ref)
        zr = {st: np.array([mvp._z(r, *refs[tk]) for r in z_of_gt(gt, tk, st)])
              for st in ("safe", "risky")}
        gt_best[tk] = {u: ("safe" if utility_vals(zr["safe"], u) >= utility_vals(zr["risky"], u)
                           else "risky") for u in UTILITIES}
    gt_margins = margins_and_eligibility(gt, refs, boot_rng,
                                         task_list=task_list)
    envs = {tk: make_env(tk, seed + 7) for tk in task_list}
    cfg = {"seed": seed}
    # v1.15 Exp3: seeding-radius sweep (seed_radius injected into BeliefGate via cfg)
    if gate_radius is not None:
        cfg["gate"] = {"seed_radius": gate_radius}
    sel = make_selector(style, n_primitives=2, taus=TAUS,
                        n_contexts=n_tasks, cfg=cfg)
    votes = np.zeros((max(sel.n_comp, 1), n_tasks))
    rstats = {"active": np.zeros(max(sel.n_comp, 1)), "none": 0}
    # v1.8: task order randomized per seed - with a fixed push->peg->sweep order, an identity
    # comp_task could be a first-come-first-served ordering artefact; different seeds get
    # different permutations and comp_task is computed by Hungarian alignment of votes
    perm = np.random.default_rng(seed + 31337).permutation(n_tasks)
    task_order = [task_list[i] for i in perm]
    tno = 0
    for ep in range(epochs):
        for tk in task_order:
            env, tt, erng = envs[tk]
            ci = task_list.index(tk)
            for t in range(trials_per_task):
                task = tt[int(erng.integers(len(tt)))]
                env.set_task(task)
                obs, _ = env.reset()
                sig0 = np.concatenate([obs[:6], obs[:6]])   # signature v3 (start-point approximation)
                sel.begin_episode(ci, sig0)
                _ = sel.select_primitive(sig0)         # refresh last_belief
                c = tno % 2                             # round-robin exploration
                prim = prim_instance(tk, c, seed * 100000 + tno)
                r, init_obs, mean_obs, last_obs = trial(env, task, erng, prim, phys_rng)
                sig = np.concatenate([mean_obs[:6], last_obs[:6]])  # signature v3
                t_ref, e_ref, i_ref = refs[tk]
                z = (r["success"] - 0.3 * r["time"] / t_ref
                     - 0.02 * r["energy"] / e_ref - 0.5 * r["impact_max"] / i_ref)
                sel.update(sig, c, z)   # v1.6b: signature v3 routing
                if style not in ("oracle", "shared"):
                    b = sel.last_belief
                    votes[int(np.argmax(b)), ci] += 1
                    rstats["active"][int(np.argmax(b))] += 1
                    rstats["none"] += int((sel._upd_b <= 0.5).all()
                                          if sel._upd_b is not None else False)
                tno += 1
    # ---- freeze + zero-update revaluation ----
    sel.freeze()
    comp_task = {}
    purity = None
    k_discovered = None
    if style not in ("oracle", "shared"):
        k_discovered = int(sum(p is not None for p in sel.gate.proto))
        if votes.shape[0] == n_tasks and votes.sum() > 0:
            # v1.8: Hungarian alignment (maximize total votes), removing order-seeding artefacts
            from scipy.optimize import linear_sum_assignment
            r_ind, c_ind = linear_sum_assignment(-votes)
            comp_task = {int(r): int(c) for r, c in zip(r_ind, c_ind)}
            purity = float(sum(votes[r, comp_task[r]] for r in range(n_tasks))
                           / votes.sum())
        else:
            comp_task = {k: int(np.argmax(votes[k])) for k in range(votes.shape[0])}
    pred, per_task_correct, per_task_raw = {}, {}, {}
    for tk in task_list:
        ci = task_list.index(tk)
        if style == "oracle":
            sel._true_ctx = ci
            sel.last_belief = np.eye(sel.n_comp)[ci]
        elif style == "shared":
            sel.last_belief = np.ones(1)
        else:
            # v1.11 key fix: comp_task is a comp->task map (v1.8 Hungarian); revaluation must
            # invert it to task->comp. The original comp_task.get(ci) treated task indices as
            # compartment indices - identity/involution permutations masked the bug, but with a
            # 3-cycle (e.g. seed0 {0:2,1:0,2:1}) every task was scored on the wrong compartment
            # (root cause of the v1.10 artefact where sweep was all-right or all-wrong by order).
            task2comp = {t: k for k, t in comp_task.items()}
            k = task2comp.get(ci, ci)
            b = np.zeros(sel.n_comp); b[min(k, sel.n_comp - 1)] = 1.0
            sel.last_belief = b
        pred[tk] = {}
        per_task_correct[tk] = 0
        per_task_raw[tk] = 0
        for u in UTILITIES:
            if u.startswith("unseen_"):
                tau = 1.0 - float(u.split("_")[1])
            elif u == "cvar_lo": tau = 0.1
            elif u == "cvar_hi": tau = 0.9
            else: tau = 0.5
            vals = sel.revalue(tau=tau)
            pred[tk][u] = "safe" if vals[0] >= vals[1] else "risky"
            per_task_raw[tk] += int(pred[tk][u] == gt_best[tk][u])
            if gt_margins[tk][u][2]:          # v1.4 dual gating: only eligible utilities count
                per_task_correct[tk] += int(pred[tk][u] == gt_best[tk][u])
    nU = len(UTILITIES)
    n_elig = sum(int(gt_margins[tk][u][2]) for tk in task_list for u in UTILITIES)
    R_raw = sum(per_task_raw.values()) / (n_tasks * nU)
    R = sum(per_task_correct.values()) / max(n_elig, 1)
    results = dict(variant=name, style=style, seed=seed,
                   trials_per_task=trials_per_task, epochs=epochs,
                   tasks=task_list,                      # v1.15: record task list
                   gate_radius=gate_radius,              # v1.15: record Exp3 sweep setting
                   gt_best=gt_best, comp_task=comp_task, pred=pred,
                   per_task_raw={k: f"{v}/{nU}" for k, v in per_task_raw.items()},
                   per_task_correct={k: f"{v}/{sum(int(gt_margins[k][u][2]) for u in UTILITIES)}"
                                     for k, v in per_task_correct.items()},
                   R_reval_raw=round(R_raw, 4),
                   R_reval=round(R, 4),
                   n_utilities=nU, n_eligible=int(n_elig),
                   votes=votes.astype(int).tolist(),
                   route_stats={"active_updates": rstats["active"].astype(int).tolist(),
                                "no_gate_open": int(rstats["none"])} if style == "joint" else None,
                   ch_values={k: {f"{c}|{tau}": round(tr.v, 4)
                                  for (c, tau), tr in comp.ch.items()}
                              for k, comp in enumerate(sel.compartments)},
                   margins={tk: {u: [round(m, 4), round(s, 4), bool(e), round(c, 4)]
                                 for u, (m, s, e, c) in gt_margins[tk].items()}
                            for tk in task_list},
                   task_R={tk: round(per_task_correct[tk]
                                     / max(sum(int(gt_margins[tk][u][2]) for u in UTILITIES), 1),
                                     3) for tk in task_list},   # v1.8: denominator = eligible utilities of that task
                   task_order=task_order, purity=purity,
                   k_discovered=k_discovered,
                   update_counts=[int(c.visit_count) for c in sel.compartments]
                   if style not in ("oracle", "shared") else None,
                   gate_open_frac=round(float(rstats["active"].sum()) / max(tno, 1), 4)
                   if style == "joint" else None)
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w") as f:
        json.dump(results, f, indent=1, default=str)
    if getattr(sel, "dump", None) is not None:
        with open(out_path.replace(".json", "_dump.json"), "w") as f:
            json.dump(sel.dump, f)
    print(json.dumps({k: results[k] for k in ("variant", "R_reval_raw", "R_reval",
                                              "n_eligible", "task_R",
                                              "per_task_correct",
                                              "task_order", "purity",
                                              "k_discovered", "update_counts",
                                              "gate_open_frac")}, indent=1), flush=True)
    return R

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--trials", type=int, default=600)  # v1.5: the asymmetric estimator needs 4x data
    ap.add_argument("--epochs", type=int, default=2)
    ap.add_argument("--variants", default="dist-only,comp-only,joint,oracle")
    # v1.15: Exp2 multiple tasks (comma-separated; overrides default push/peg/sweep)
    ap.add_argument("--tasks", default=None,
                    help="comma-separated task keys, e.g. push,peg,sweep,door_open")
    # v1.15: Exp3 seeding-radius sweep (--gate-radius 0.25 etc.; default 0.3)
    ap.add_argument("--gate-radius", type=float, default=None)
    a = ap.parse_args()
    tasks = a.tasks.split(",") if a.tasks else None
    for v in a.variants.split(","):
        gr_tag = f"_gr{a.gate_radius}" if a.gate_radius is not None else ""
        # v1.15: non-default task sets carry an N tag in the filename to prevent N=2/N=3 overwrites
        nt_tag = f"_n{len(tasks)}" if tasks else ""
        run_variant(v, a.seed, a.trials, a.epochs,
                    f"mvp_out/gate_{v}_s{a.seed}{nt_tag}{gr_tag}.json",
                    tasks=tasks, gate_radius=a.gate_radius)
    print("GATEKEEPER DONE", flush=True)
