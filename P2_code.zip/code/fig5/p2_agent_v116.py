"""P2 strategy-selection layer for the Meta-World primitive benchmark.

Implements the manuscript model at the primitive-selection level, faithful to
the paper's equations:

    Channel value   V^{(c)}_tau(t)  — expectile-τ estimate of outcome z for
                                       primitive c under current context
    Update          ΔW ∝ −η · g_c(t) · M_c(t) · ē           (compartment gated)
                    expectile update with forgetting factor λ per compartment
    Routing         g_c(t) = σ(w · b_t)  — compartment gate from context belief
    Selection       a_t = argmax_c  U(V^{(c)}_{τ*}(t))      (utility-blind in
                                       Phases I–II: τ* fixed neutral 0.5)

Variants (MVP, design doc §5):
    joint      — expectile channels × compartment routing (full P2)
    shared     — channels, single shared compartment (no routing ablation)
    mean       — single mean channel × routing (no distributional ablation)
    oracle     — joint + true context id given
    random-gate— joint with gating replaced by random gate
    explicit-ID— compartments indexed by given id (upper reference, not a claim)

All variants share the same interface:
    sel = make_selector(variant, n_primitives, taus, cfg)
    sel.begin_episode(obs)          -> nothing (belief from obs stream)
    sel.select_primitive(obs)       -> primitive index
    sel.update(obs, c_idx, z)       -> gated plasticity update after rollout
    sel.end_phase()                 -> freeze (Phase III: no further updates)
"""
import numpy as np
import os


class ExpectileTracker:
    """Online expectile estimate with forgetting (per compartment)."""

    def __init__(self, tau, lr=0.06, lam=0.999, init=0.0):
        self.tau = tau
        self.lr = lr
        self.lam = lam          # per-trial memory retention (compartment-protected)
        self.v = init
        self.n = 0

    def update(self, z):
        # expectile loss: |τ − 1{z<v}| (z−v)² ; online Newton-ish step
        # v1.14: harmonic learning-rate annealing lr0*50/(50+n) (the sqrt anneal of v1.12f still left
        # an SGD residual of ~0.05 > the push high-tau margin 0.036; seed0/2 dissection showed the
        # tau0.9 channel ordering inverted vs the batch ground truth). The harmonic step satisfies
        # sum(a)=inf, sum(a^2)<inf, the standard stochastic-approximation condition, converging to
        # the true expectile of the written distribution; plasticity is unchanged early on
        # (lr ~ 0.06 for the first ~50 writes). With a fixed lr the effective window was ~17-33 writes.
        self.n += 1
        lr_eff = self.lr * 50.0 / (50.0 + self.n)
        diff = z - self.v
        w = self.tau if diff > 0 else (1 - self.tau)
        # decay toward neutral pulls old mass out only when compartment revisited
        self.v = self.v + lr_eff * w * diff

    def decay(self):
        """Compartment dormancy: slow drift to prior (memory protection knob)."""
        self.v *= self.lam


class Compartment:
    """One context compartment: per-primitive expectile channels."""

    def __init__(self, n_primitives, taus):
        self.ch = {(c, tau): ExpectileTracker(tau) for c in range(n_primitives)
                   for tau in taus}
        self.visit_count = 0

    def value(self, c, tau):
        if (c, tau) in self.ch:
            return self.ch[(c, tau)].v
        # v1.14: linear interpolation between adjacent trained tau channels (the correct way to read
        # unseen utilities - the old nearest-channel rounding read tau=0.85 as the 0.8 channel and
        # 0.95 as the 0.9 channel, which misjudged seed0 push unseen_0.15; interpolation is the
        # point of heterogeneous channels). Outside the trained range, extrapolate one step with the endpoint slope.
        avail = sorted({t for (cc, t) in self.ch if cc == c})
        if len(avail) == 1:
            return self.ch[(c, avail[0])].v
        lo = max([t for t in avail if t < tau], default=None)
        hi = min([t for t in avail if t > tau], default=None)
        if lo is None:
            lo, hi = avail[0], avail[1]
        elif hi is None:
            lo, hi = avail[-2], avail[-1]
        vlo, vhi = self.ch[(c, lo)].v, self.ch[(c, hi)].v
        if hi == lo:
            return vlo
        return vlo + (vhi - vlo) * (tau - lo) / (hi - lo)

    def update(self, c, z):
        for tau in {t for (_, t) in self.ch}:
            self.ch[(c, tau)].update(z)
        self.visit_count += 1


class BeliefGate:
    """Latent-context belief b_t(c) from observation stream (Phase II).

    MVP: exponential-kernel similarity between current obs summary and per-
    compartment stored prototypes, normalized; no task IDs available.
    """

    def __init__(self, n_compartments, kappa=8.0, seed_radius=0.3):  # v1.6d: 0.3 is a safe gap between push inliers (max 0.24) and peg-block distances (>= 0.5)
        self.n = n_compartments
        self.kappa = kappa
        self.seed_radius = seed_radius   # novelty-threshold lower bound (upper bound adaptive)
        self.proto = [None] * n_compartments   # obs summary per compartment
        self.counts = np.zeros(n_compartments)
        self.radius = [None] * n_compartments  # v1.7: per-prototype inlier-radius EMA
        self.md_mu = None      # EMA of the minimum distance (statistics)
        self.md_var = 0.0

    def dists(self, obs):
        s = self.summary(obs)
        return np.array([np.inf if p is None else np.linalg.norm(s - p)
                         for p in self.proto])

    def min_dist(self, obs):
        s = self.summary(obs)
        ds = [np.linalg.norm(s - p) for p in self.proto if p is not None]
        return (min(ds) if ds else np.inf), (int(np.argmin(ds)) if ds else -1)

    def novelty_threshold(self):
        if self.md_mu is None:
            return self.seed_radius
        return max(self.seed_radius, self.md_mu + 3 * np.sqrt(self.md_var))

    def update_novelty_ema(self, obs):
        d, _ = self.min_dist(obs)
        if not np.isfinite(d):
            return
        if self.md_mu is None:
            self.md_mu, self.md_var = d, 0.0
        else:
            diff = d - self.md_mu
            self.md_mu += 0.02 * diff
            self.md_var = max(0.0, 0.98 * self.md_var + 0.02 * diff * diff)

    def summary(self, obs):
        # Signature v3 (12-dim): concat(first 6 dims of trajectory mean, first 6 dims of final obs).
        # Callers always pass the 12-dim signature; the old 39-dim raw-obs path is truncated/deprecated.
        a = np.asarray(obs, float)
        return a[:12] if a.size >= 12 else np.concatenate([a[:6], a[:6]])

    def observe(self, comp_id, obs, weight=1.0):
        if weight < 0.05:
            return                     # zero responsibility: neither seed nor correct
        s = self.summary(obs)
        if self.proto[comp_id] is None:
            self.proto[comp_id] = s.copy()
        else:
            # v1.6d: prototype correction capped at 0.2 - the old cap of 0.5 let a single out-of-range
            # inlier drag the prototype half a task space away
            lr = min(0.2, 0.04 + 0.16 * weight)
            self.proto[comp_id] = (1 - lr) * self.proto[comp_id] + lr * s
        self.counts[comp_id] += weight

    def belief(self, obs):
        s = self.summary(obs)
        d = np.array([1e6 if p is None else np.linalg.norm(s - p)
                      for p in self.proto])
        if np.all(d > 1e5):            # no prototype yet: uniform
            return np.ones(self.n) / self.n
        logits = -self.kappa * d
        logits[d > 1e5] = -1e9
        e = np.exp(logits - logits.max())
        return e / e.sum()


def make_selector(variant, n_primitives, taus, n_contexts, cfg=None):
    cfg = cfg or {}
    return Selector(variant, n_primitives, taus, n_contexts, cfg)


class Selector:
    NEUTRAL_TAU = 0.5   # utility-blind Phase I–II selection

    def __init__(self, variant, n_primitives, taus, n_contexts, cfg):
        assert variant in ("joint", "shared", "mean", "oracle", "scalar",
                           "random-gate", "explicit-ID",
                           # v1.16 CL baselines (online adaptive versions; SI section)
                           "replay", "ewc", "si")
        self.variant = variant
        self.n_primitives = n_primitives
        # v1.15: scalar baseline = no routing x no distribution: single channel, single tau=0.5
        # (a required control: otherwise the claim that the gain comes from routing rather
        # than distributional prediction cannot be falsified)
        self.taus = list(taus) if variant not in ("mean", "scalar") else [0.5]
        # v1.16: replay buffer (per-arm reservoir, capacity 2000) + CL importance table
        if variant == "replay":
            self._rbuf = {}
            self._rbuf_n = 0
        if variant in ("ewc", "si"):
            self._omega = {}
            self._cl_lam = cfg.get("cl_lambda", 1.0)  # protection strength
        # v1.12d diagnostics: with GK_DUMP=1, log every channel write (comp, arm, z, lr, tag)
        self.dump = [] if os.environ.get("GK_DUMP") == "1" else None
        self.n_contexts = n_contexts
        self.n_comp = 1 if variant in ("shared", "scalar") else n_contexts
        self.compartments = [Compartment(n_primitives, self.taus)
                             for _ in range(self.n_comp)]
        # v1.8: the main benchmark freezes dormant compartments (lambda_dormant=1, no write,
        # no decay). The old 0.999/trial decay left inactive memories at ~2.7% over 3600 trials,
        # turning "protected from interference" into "systematically erased by time" and
        # confounding interference with passive decay (external review comment, adopted).
        # The decay path is kept only for supplementary robustness: pass
        # {"dormant_decay": True} in cfg to restore the old dynamics.
        self.dormant_decay = cfg.get("dormant_decay", False)
        self.gate = BeliefGate(self.n_comp, **cfg.get("gate", {}))
        self.rng = np.random.default_rng(cfg.get("seed", 0))
        self._upd_b = None
        self.frozen = False
        self.last_belief = np.ones(self.n_comp) / self.n_comp

    def _write(self, k, c_idx, z, b, tag, half=False):
        comp = self.compartments[k]
        lr = 0.06 * b * (0.5 if half else 1.0)
        for tau in self.taus:
            comp.ch[(c_idx, tau)].lr = lr
        if self.dump is not None:
            self.dump.append([int(k), int(c_idx), float(z), float(lr), tag,
                              int(self._upd_count)])
        comp.update(c_idx, z)
        for tau in self.taus:
            comp.ch[(c_idx, tau)].lr = 0.06

    # ---------- context handling ----------
    def _resolve_comp(self, true_ctx, obs):
        if self.variant == "oracle":
            return true_ctx
        if self.variant == "explicit-ID":
            return true_ctx
        if self.variant == "shared":
            return 0
        # latent: belief-determined mixture; write updates into all comps
        # weighted by belief (soft routing); observation recorded for future
        return None  # soft mixture path

    def begin_episode(self, true_ctx, obs):
        if self.variant in ("oracle", "explicit-ID"):
            self.gate.observe(min(true_ctx, self.n_comp - 1), obs)
        self._true_ctx = true_ctx
        self._obs = obs

    # ---------- action ----------
    def select_primitive(self, obs):
        if self.variant == "random-gate":
            return int(self.rng.integers(self.n_primitives)) \
                if self.rng.random() < 0.2 else self._greedy(obs)
        return self._greedy(obs)

    def _comp_values(self, comp, c):
        return {tau: comp.value(c, tau) for tau in self.taus}

    def _greedy(self, obs):
        if self.variant == "shared":
            comp = self.compartments[0]
            return int(np.argmax([comp.value(c, self.NEUTRAL_TAU)
                                  for c in range(self.n_primitives)]))
        if self.variant in ("oracle", "explicit-ID"):
            comp = self.compartments[min(self._true_ctx, self.n_comp - 1)]
            return int(np.argmax([comp.value(c, self.NEUTRAL_TAU)
                                  for c in range(self.n_primitives)]))
        # joint / mean / random-gate: belief-weighted mixture over compartments
        if self.variant == "random-gate":
            # v1.15: the readout side is likewise de-gated (uniform mixture), together with the
            # write-side Dirichlet weights forming the complete random-gate control
            b = np.ones(self.n_comp) / self.n_comp
        else:
            b = self.gate.belief(obs)
        self.last_belief = b
        scores = []
        for c in range(self.n_primitives):
            v = sum(b[k] * self.compartments[k].value(c, self.NEUTRAL_TAU)
                    for k in range(self.n_comp))
            scores.append(v)
        return int(np.argmax(scores))

    # ---------- learning ----------
    def update(self, obs, c_idx, z):
        if self.frozen:
            return
        self._upd_b = None
        self._upd_count = getattr(self, "_upd_count", 0) + 1
        true_ctx = self._true_ctx
        if self.variant in ("oracle", "explicit-ID"):
            self._write(min(true_ctx, self.n_comp - 1), c_idx, z, 1.0, "oracle")
            return
        if self.variant == "shared":
            self._write(0, c_idx, z, 1.0, "shared")
            return
        # v1.15 scalar baseline: the same channel written in full (no routing, no distributional
        # separation); differs from shared only in the tau set (shared uses all trained tau channels)
        if self.variant == "scalar":
            self._write(0, c_idx, z, 1.0, "scalar")
            return
        # ---- v1.16 classic CL baselines (online adaptive versions; skeleton = single shared
        # compartment with all tau channels; the only difference from dist-only is the
        if self.variant == "replay":
            # interference-protection mechanism itself) ----
            # reservoir replay: current z written at full weight + 4 historical z replayed per step
            buf = self._rbuf.setdefault(c_idx, [])
            self._rbuf_n += 1
            if len(buf) < 2000:
                buf.append(float(z))
            elif self.rng.random() < 2000.0 / self._rbuf_n:
                buf[int(self.rng.integers(2000))] = float(z)
            self._write(0, c_idx, z, 1.0, "cl")
            for _ in range(4):
                if buf:
                    self._write(0, c_idx, float(buf[int(self.rng.integers(len(buf)))]),
                                0.5, "rep", half=True)
            return
        if self.variant in ("ewc", "si"):
            # (half weight). The replay pool is task-mixed - not expected to rescue tail probes.
            # Online EWC/SI-style protection: effective lr divided by (1 + lambda * Omega).
            # EWC signal: Omega += |dv| (parameter sensitivity); SI signal: Omega += lr|z - v|
            # (contribution proxy). Protection preserves old knowledge but produces no
            comp = self.compartments[0]
            # utility-conditioned ordering - a different problem from factorized credit assignment.
            # The protection factor averages importance over all tau channels of the arm (the b in _write scales lr uniformly across tau, so the mean is taken).
            om_mean = float(np.mean([self._omega.get((c_idx, t), 0.0)
                                     for t in self.taus]))
            v_before = {tau: comp.ch[(c_idx, tau)].v for tau in self.taus}
            self._write(0, c_idx, z, 1.0 / (1.0 + self._cl_lam * om_mean), "cl")
            for tau in self.taus:
                key = (c_idx, tau)
                tr = comp.ch[key]
                if self.variant == "ewc":
                    self._omega[key] = self._omega.get(key, 0.0) \
                        + abs(tr.v - v_before[tau])
                else:
                    self._omega[key] = self._omega.get(key, 0.0) \
                        + 0.06 * abs(z - v_before[tau])
            return
        # ---- latent routing: novelty-seeded online clustering ----
        if self.variant == "random-gate":
            # v1.15 fix: the original implementation let random-gate carry only write order/frequency,
            # not the full ablation in which random gating misallocates plasticity exposure across
            # channels - the old code still used the real gate routing at the if/else join, making
            # random-gate not worthy of its name. Current implementation: Dirichlet weights write
            # directly into all compartments, fully bypassing gate/proto/seeding logic; the value
            # readout in _greedy also uses a uniform-belief mixture (see _greedy).
            b = self.rng.dirichlet(np.ones(self.n_comp))
            self.last_belief = b
            self._upd_b = b
            for k in range(self.n_comp):
                self._write(k, c_idx, z, b[k], "rand")
            return
        else:
            empty = [i for i, p in enumerate(self.gate.proto) if p is None]
            ds = self.gate.dists(obs)
            nearest = int(np.argmin(ds))
            d = ds[nearest]
            # v1.12 provisional confirm/retract: a newly seeded prototype must be confirmed by subsequent
            # trials, otherwise it is retracted and the slot freed. Targets within-block mis-seeding in
            # the peg-first order (peg within-class spread 0.42 +/- 0.29 inflates the EMA threshold, so
            # peg far-success outliers were misjudged as new contexts - the only failure mode of v1.11 seeds 1/3/4).
            pv = getattr(self, "_provisional", None)
            if pv is not None and np.isfinite(ds[pv]):
                if ds[pv] < 0.35:                    # true task switch: subsequent trials are same-task,
                    self._confirm_ok += 1            # at distance 0.06-0.24 from the new prototype
                    if self._confirm_ok >= 3:
                        self._provisional = None     # confirmed: promote to regular
                else:                                # mis-seeded outlier: subsequent trials
                    self._confirm_bad += 1           # sit at distance 0.3-0.6 from it
                    if self._confirm_bad >= 2:
                        self.gate.proto[pv] = None   # retract, freeing the slot
                        self.gate.counts[pv] = 0.0
                        self.gate.radius[pv] = None
                        self._provisional = None
                        empty = [i for i, p in enumerate(self.gate.proto)
                                 if p is None]
            if not np.isfinite(d):
                # NaN/infinite signatures (physically blown-up rollouts): stay silent; never
                # overwrite an existing prototype (v1.9 hardening: the original code called observe(0)
                # unconditionally here, so a NaN trial rewrote proto0 to NaN and locked it)
                if all(p is None for p in self.gate.proto):
                    # first trial: seed comp0 only and return (v1.6b fix: the original fell into the
                    # uniform-belief branch and seeded 3 prototypes at once).
                    self.gate.observe(0, obs, weight=1.0)
                    self._far_hist = []
                    self._far_sigs = []
                return
            # v1.7c: global threshold (validated in v1.6e/f/g) + success-gated seeding (v1.7b).
            # Per-proto radii (v1.7) were falsified experimentally: the chicken-and-egg problem - before
            # calibration upd_thr=0.15 rejects whole clusters (sweep d~0.24); after calibration it locks
            # the prototype so it cannot migrate to the cluster centre.
            far = d > self.gate.novelty_threshold()
            # v1.7b: seeding evidence counts only threshold-crossing AND successful trials (z>0 implies
            # success; rare high-impact successes with z<=0 are negligible). Final signatures of failed
            # trials are physically randomized with huge spread (far-fail mean d = 0.51) and are the only
            # source of mis-seeding (the tno=75 push failure-streak mis-seed, measured by diag_route);
            # failed trials still update channels via normal inlier routing (cvar learning needs them).
            hist = getattr(self, "_far_hist", [])
            hist = (hist + [int(far and z > 0)])[-5:]
            self._far_hist = hist
            if far:
                if z > 0:
                    sig_arr = self.gate.summary(obs)
                    fs = getattr(self, "_far_sigs", [])
                    fs = (fs + [sig_arr])[-5:]
                    self._far_sigs = fs
                if empty and z > 0 and sum(hist) >= 4 and \
                   self.gate.counts[nearest] >= 50 and \
                   self._upd_count - getattr(self, "_last_seed_count", -10**9) >= 25 \
                   and getattr(self, "_provisional", None) is None:
                    # New context: seed with the current successful trial (v1.7d single-point seeding; the v1.6g
                    # threshold-window mean was falsified). The seeding trial does not write channels.
                    # v1.12: after seeding, enter the provisional pending-confirmation state; re-seeding is
                    # forbidden during confirmation (prevents slot stacking).
                    self.gate.observe(empty[0], obs, weight=1.0)
                    self._provisional = empty[0]
                    self._confirm_ok = 0
                    self._confirm_bad = 0
                    self._far_hist = []
                    self._far_sigs = []
                    self._last_seed_count = self._upd_count
                    return
                # Out-of-threshold silence: do not touch prototype/EMA/threshold. v1.12b far-distance write-
                # starvation fix - peg within-class spread is 0.42 +/- 0.29; after prototype convergence half
                # of the trials fall in the far band and were fully silenced (epoch-1 peg block far_hist stuck
                # at 5/5; comp0 total writes only 444/1200, so revaluation was noise-dominated). Value is
                # written at half weight to the nearest high-belief channel; leakage risk bounded by the b>0.5 gate.
                b = self.gate.belief(obs)
                self.last_belief = b
                self._upd_b = b
                if b[nearest] > 0.5:
                    self._write(nearest, c_idx, z, b[nearest], "far", half=True)
                return
            mu, var = self.gate.md_mu, self.gate.md_var
            upd_thr = max(0.15, (mu + 2 * np.sqrt(var)) if mu is not None else 0.15)
            if d > upd_thr:
                # Intermediate trials outside the inlier band (e.g. peg to push prototype d~0.25): leave
                # prototype/EMA untouched; write value at half weight to the nearest high-belief channel
                # (v1.12b, same far-band fix; only last_belief is refreshed for votes).
                b = self.gate.belief(obs)
                self.last_belief = b
                self._upd_b = b
                if b[nearest] > 0.5:
                    self._write(nearest, c_idx, z, b[nearest], "mid", half=True)
                return
            # True inlier: update the global EMA (statistics) then route normally.
            self.gate.update_novelty_ema(obs)
            # v1.13 hard prototype routing (WTA): a prototype is updated only by its argmax owner.
            # v1.12g routing dissection: soft-responsibility updates let adjacent push-peg clusters
            # (signature distance 0.33) drag each others prototypes - comp0(peg) was dragged into the push
            # cluster during the epoch-0 push block (b~0.45/lr~0.11), and by the epoch-1 push block
            # d0=0.098=d1. Double consequence: (1) epoch-1 peg block saw comp0 as all-far (far frac=1.0);
            # (2) vote ambiguity led Hungarian to score peg on the push compartment (direct cause of
            # seed1 peg 2/6). Value writing still uses soft belief (b>0.5 gate); only prototype
            # correction is hardened.
            b = self.gate.belief(obs)
            self.last_belief = b
            self._upd_b = b
            kstar = int(np.argmax(b))
            self.gate.observe(kstar, obs, weight=float(b[kstar]))
            for k in range(self.n_comp):
                if b[k] > 0.5 and np.isfinite(ds[k]):
                    rk = self.gate.radius[k]
                    self.gate.radius[k] = float(ds[k]) if rk is None \
                        else rk + 0.05 * (float(ds[k]) - rk)
        # Gated plasticity: compartments with b>0.5 receive updates; the rest stay dormant and decay
        for k in range(self.n_comp):
            comp = self.compartments[k]
            if b[k] > 0.5:
                self._write(k, c_idx, z, b[k], "in")
            elif b[k] < 0.3:
                if self.dormant_decay:      # v1.8: frozen by default in the main benchmark
                    for key, tr in comp.ch.items():
                        tr.decay()

    # ---------- Phase III ----------
    def freeze(self):
        self.frozen = True

    def revalue(self, utility="mean", tau=None):
        """Zero-update revaluation: rank primitives under announced utility."""
        tau = tau or self.NEUTRAL_TAU
        if self.variant in ("oracle", "explicit-ID"):
            comp = self.compartments[min(self._true_ctx, self.n_comp - 1)]
            vals = [comp.value(c, tau) for c in range(self.n_primitives)]
        elif self.variant == "random-gate":
            # v1.15: random-gate revaluation uses a uniform-mixture readout (de-gated,
            # matching the write-side Dirichlet weights)
            b = np.ones(self.n_comp) / self.n_comp
            vals = [sum(b[k] * self.compartments[k].value(c, tau)
                        for k in range(self.n_comp))
                    for c in range(self.n_primitives)]
        else:
            b = self.last_belief
            vals = [sum(b[k] * self.compartments[k].value(c, tau)
                        for k in range(self.n_comp))
                    for c in range(self.n_primitives)]
        return vals
