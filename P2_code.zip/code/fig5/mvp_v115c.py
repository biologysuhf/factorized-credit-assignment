"""MVP three-phase runner - P2 selection layer x Meta-World primitive benchmark.

Usage:
    python3 mvp.py --variant joint --seed 0 --phaseI 200 --phaseII 300

Phase I   fixed sequence push -> peg_insert -> sweep, N trials per task, no task ID.
Phase II  Markov switching (p_stay=0.97), only (s_t, a_t, o_t).
Phase III freeze all parameters, announce utilities {mean, CVaR-_0.1, CVaR+_0.9} plus
          unseen {CVaR+_alpha: alpha in 0.05, 0.15, 0.20}, zero-update revaluation,
          scored against GT empirical-distribution rankings (R_reval).

GT: preferably read gt_out/*.npz (production); otherwise generate a temporary n=600 GT (seed 910000).
"""
import sys, os, json, argparse
import numpy as np
sys.path.insert(0, ".")
sys.path.insert(0, ".")

from step0_v12_final import SAFE, run_cand, znew
from step0_final import TASKS, make_env
import primitives
from metaworld.policies import SawyerPegInsertionSideV3Policy, SawyerSweepV3Policy
TASKS.setdefault("peg_insert", ("peg-insert-side-v3", SawyerPegInsertionSideV3Policy))
TASKS.setdefault("sweep", ("sweep-v3", SawyerSweepV3Policy))
from p2_agent import make_selector
import mujoco

TASK_ORDER = ["push", "peg_insert", "sweep"]
# v1.15 Exp2 groundwork: new tasks (door_open/button_press/drawer_open etc.) get no
# per-task tuning; all use the generic arm parametrization (a generic multiplicative arm
# is cleaner than hand tuning, and the eligibility audit automatically filters out tasks with no safe/risky separation - by design)
SAFE_GENERIC = dict(speed=0.8, delay=0, overshoot=1.0)
RISKY_GENERIC = dict(speed=1.0, delay=0, overshoot=1.5)

def arm_of(d, tk, generic):
    """Arm parameters keyed by task; new tasks fall back to the generic arm (no hand tuning)."""
    return d.get(tk, generic)

RISKY = {"push": dict(speed=1.0, delay=0, overshoot=1.5),
         "peg_insert": dict(speed=1.0, delay=0, overshoot=1.5),  # v1.4 retuned: chunk-stable
         "sweep": dict(speed=1.0, delay=0, overshoot=2.0)}  # v1.4 retuned: chunk-stable
TAUS = [0.1, 0.2, 0.3, 0.5, 0.7, 0.8, 0.9]
DT = 0.0125
PHYS = dict(mass_range=(0.2, 5.0), friction_range=(0.1, 0.8))

def prim_instance(tk, style, seed):
    _, pc = TASKS[tk]
    p = arm_of(SAFE, tk, SAFE_GENERIC) if style == 0 \
        else arm_of(RISKY, tk, RISKY_GENERIC)
    class P:
        def __init__(s):
            s.pol = pc(); s.rng = np.random.default_rng(seed); s.buf = []
        def reset(s): s.buf = []
        def act(s, obs):
            s.buf.append(obs.copy())
            o = s.buf[max(0, len(s.buf) - 1 - p["delay"])]
            a = np.asarray(s.pol.get_action(o), float)
            a[:3] *= p["speed"] * p["overshoot"]
            return np.clip(a + s.rng.normal(0, 0.02, a.shape), -1, 1)
    return P()

def contact_pairs(env):
    m, d = env.unwrapped.model, env.unwrapped.data
    out = set()
    for c in d.contact:
        g1 = mujoco.mj_id2name(m, mujoco.mjtObj.mjOBJ_GEOM, c.geom1)
        g2 = mujoco.mj_id2name(m, mujoco.mjtObj.mjOBJ_GEOM, c.geom2)
        if g1 and g2:
            out.add(frozenset((g1, g2)))
    return out

def trial(env, task, rng, prim, phys_rng):
    """Single rollout; the obs before primitive selection is also returned (for selector gating)."""
    env.set_task(task)
    obs, _ = env.reset()
    if hasattr(prim, "reset"):
        prim.reset()
    init_obs = obs.copy()
    resting = contact_pairs(env)
    model = env.unwrapped.model
    body_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "obj")
    gid0 = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_GEOM, "objGeom")
    base_mass = None
    if body_id >= 0:
        base_mass = float(model.body_mass[body_id])
        model.body_mass[body_id] = base_mass * float(phys_rng.uniform(*PHYS["mass_range"]))
    base_fric = None
    if gid0 >= 0:
        base_fric = float(model.geom_friction[gid0][0])
        model.geom_friction[gid0][0] = base_fric * float(phys_rng.uniform(*PHYS["friction_range"]))
    data = env.unwrapped.data
    energy, impact_max, steps, success = 0.0, 0.0, 0, 0
    obs_sum = np.zeros_like(obs, dtype=float)
    EE = ("leftpad_geom", "rightpad_geom", "leftclaw_it", "rightclaw_it")
    SURF = ("floor", "rail")
    for t in range(500):
        a = prim.act(obs)
        obs, r, term, trunc, info = env.step(a)
        steps += 1
        obs_sum += obs
        energy += float(np.sum(a[:3] ** 2))
        for i, c in enumerate(data.contact):
            g1 = mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_GEOM, c.geom1)
            g2 = mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_GEOM, c.geom2)
            if not (g1 and g2) or frozenset((g1, g2)) in resting:
                continue
            if (g1.startswith(EE) and g2 not in SURF) or (g2.startswith(EE) and g1 not in SURF):
                continue
            f = np.zeros(6)
            mujoco.mj_contactForce(model, data, i, f)
            impact_max = max(impact_max, float(np.linalg.norm(f[:3])))
        if info.get("success", 0) > 0:
            success = 1
            break
        if term or trunc:
            break
    if base_mass is not None:
        model.body_mass[body_id] = base_mass
    if base_fric is not None:
        model.geom_friction[gid0][0] = base_fric
    mean_obs = obs_sum / max(steps, 1)   # trajectory mean (first half of signature v3)
    return (dict(success=success, time=steps * DT, steps=steps,
                 energy=energy, impact_max=impact_max), init_obs, mean_obs,
            obs.copy())                # v1.6b: final-frame obs (second half of signature v3)

# ---------------- GT ----------------
def _rows_to_gt(rows):
    return dict(success=np.array([r["success"] for r in rows], float),
                time=np.array([r["time"] for r in rows]),
                energy=np.array([r["energy"] for r in rows]),
                impact=np.array([r["impact_max"] for r in rows]))

def load_gt(n_fallback=600, tasks=None):
    # v1.15: tasks parametrized (Exp2 multi-task GT audit); default remains TASK_ORDER
    task_list = tasks if tasks else TASK_ORDER
    gt = {}
    for tk in task_list:
        path = f"gt_out/{tk}_safe.npz"
        if os.path.exists(path):
            d = np.load(path)
            if len(d["success"]) >= 2000:
                gt[(tk, "safe")] = dict(success=d["success"], time=d["time"],
                                        energy=d["energy"], impact=d["impact"])
        path = f"gt_out/{tk}_risky.npz"
        if os.path.exists(path):
            d = np.load(path)
            if len(d["success"]) >= 2000:
                gt[(tk, "risky")] = dict(success=d["success"], time=d["time"],
                                         energy=d["energy"], impact=d["impact"])
    for tk in task_list:
        if (tk, "safe") not in gt:
            gt[(tk, "safe")] = _rows_to_gt(run_cand(
                tk, arm_of(SAFE, tk, SAFE_GENERIC), n_fallback, 910000))
        if (tk, "risky") not in gt:
            gt[(tk, "risky")] = _rows_to_gt(run_cand(
                tk, arm_of(RISKY, tk, RISKY_GENERIC), n_fallback, 910000))
    return gt

def z_of_gt(gt, tk, style):
    g = gt[(tk, style)]
    class R: pass
    rows = []
    for i in range(len(g["success"])):
        r = R(); r.success = g["success"][i]; r.time = g["time"][i]
        r.energy = g["energy"][i]; r.impact_max = g["impact"][i]
        rows.append(r)
    return rows

def utility_vals(z, name):
    if name == "mean": return float(np.mean(z))
    if name in ("cvar_lo",):
        k = max(1, int(0.1 * len(z))); return float(np.mean(np.sort(z)[:k]))
    if name.startswith("unseen_"):
        a = float(name.split("_")[1])
        k = max(1, int(a * len(z))); return float(np.mean(np.sort(z)[-k:]))
    if name == "cvar_hi":
        k = max(1, int(0.1 * len(z))); return float(np.mean(np.sort(z)[-k:]))
    raise ValueError(name)

UTILITIES = ["mean", "cvar_lo", "cvar_hi", "unseen_0.05", "unseen_0.15", "unseen_0.20"]

def run(variant, seed, nI, nII, out_path):
    rng = np.random.default_rng(seed)
    phys_rng = np.random.default_rng(seed + 999)
    gt = load_gt()
    refs, gt_best = {}, {}
    for tk in TASK_ORDER:
        srows = z_of_gt(gt, tk, "safe")
        succ = [r for r in srows if r.success]
        t_ref = float(np.median([r.time for r in succ])) or 1.0
        e_ref = float(np.median([r.energy for r in succ])) or 1.0
        i_ref = max(float(np.quantile([r.impact_max for r in srows], 0.9)), 1.0)
        refs[tk] = (t_ref, e_ref, i_ref)
        zr = {st: np.array([_z(r, *refs[tk]) for r in z_of_gt(gt, tk, st)])
              for st in ("safe", "risky")}
        gt_best[tk] = {u: ("safe" if utility_vals(zr["safe"], u) >= utility_vals(zr["risky"], u)
                           else "risky") for u in UTILITIES}

    envs = {tk: make_env(tk, seed + 7) for tk in TASK_ORDER}
    sel = make_selector(variant, n_primitives=2, taus=TAUS,
                        n_contexts=3, cfg={"seed": seed})

    log = []            # (phase, tk, choice, z, belief_correct)
    votes = np.zeros((max(sel.n_comp, 1), 3))

    def one_trial(ph, tk, tno):
        env, tt, erng = envs[tk]
        ci = TASK_ORDER.index(tk)
        task = tt[int(erng.integers(len(tt)))]
        prim0 = prim_instance(tk, 0, seed * 100000 + tno)
        prim1 = prim_instance(tk, 1, seed * 100000 + tno)
        # take the initial obs first (placeholder reset with the safe primitive instance; selection happens before the step)
        env.set_task(task)
        obs, _ = env.reset()
        env_reset_ok = obs
        sel.begin_episode(ci, obs)
        c = sel.select_primitive(obs)
        prim = prim0 if c == 0 else prim1
        r, init_obs, mean_obs, last_obs = trial(env, task, erng, prim, phys_rng)
        obs_use = init_obs
        t_ref, e_ref, i_ref = refs[tk]
        z = (r["success"] - 0.3 * r["time"] / t_ref - 0.02 * r["energy"] / e_ref
             - 0.5 * r["impact_max"] / i_ref)
        sel.update(obs_use, c, z)
        bc = None
        if variant not in ("oracle", "explicit-ID", "shared"):
            b = sel.last_belief
            bc = int(np.argmax(b)) == ci
            votes[int(np.argmax(b)), ci] += 1
        log.append((ph, tk, c, float(z), bc))

    tno = 0
    for tk in TASK_ORDER:
        for t in range(nI):
            one_trial("I", tk, tno); tno += 1
    ctx = 0
    switches = []
    for t in range(nII):
        if rng.random() > 0.97:
            ctx = int(rng.integers(3)); switches.append(tno)
        one_trial("II", TASK_ORDER[ctx], tno); tno += 1

    # ---- Phase III ----
    sel.freeze()
    comp_task = {}
    if variant not in ("oracle", "explicit-ID", "shared"):
        comp_task = {k: int(np.argmax(votes[k])) for k in range(votes.shape[0])}
    pred = {}
    for tk in TASK_ORDER:
        ci = TASK_ORDER.index(tk)
        if variant in ("oracle", "explicit-ID"):
            sel._true_ctx = ci
            sel.last_belief = np.eye(sel.n_comp)[ci]
        elif variant == "shared":
            sel.last_belief = np.ones(1)
        else:
            k = comp_task.get(ci, ci)
            b = np.zeros(sel.n_comp); b[min(k, sel.n_comp - 1)] = 1.0
            sel.last_belief = b
        pred[tk] = {}
        for u in UTILITIES:
            if u.startswith("unseen_"):
                tau = 1.0 - float(u.split("_")[1])
            elif u == "cvar_lo": tau = 0.1
            elif u == "cvar_hi": tau = 0.9
            else: tau = 0.5
            vals = sel.revalue(tau=tau)
            pred[tk][u] = "safe" if vals[0] >= vals[1] else "risky"

    def choice_quality(entries):
        ok = sum(1 for (_, tk, c, z, _) in entries
                 if ("safe" if c == 0 else "risky") == gt_best[tk]["mean"])
        return ok / max(len(entries), 1)

    phI = [e for e in log if e[0] == "I"]
    phII = [e for e in log if e[0] == "II"]
    per_task_I = {}
    for tk in TASK_ORDER:
        ent = [e for e in phI if e[1] == tk]
        per_task_I[tk] = round(choice_quality(ent[-60:]), 3) if len(ent) >= 10 else None
    # T80: trials needed for belief accuracy to return to 80% after a switch (latent variants only)
    t80 = None
    if switches and any(e[4] is not None for e in phII):
        rec = []
        bcs = [e[4] for e in phII]
        for s in switches:
            if s >= len(bcs): continue
            cnt = 0; good = 0
            for j in range(s, min(s + 60, len(bcs))):
                if bcs[j] is None: continue
                cnt += 1; good += bcs[j]
                if cnt >= 10 and good / cnt >= 0.8:
                    rec.append(j - s); break
        if rec:
            t80 = float(np.mean(rec))
    reval_ok = sum(1 for tk in TASK_ORDER for u in UTILITIES
                   if pred[tk][u] == gt_best[tk][u])
    results = dict(variant=variant, seed=seed, gt_best=gt_best, comp_task=comp_task,
                   phaseIII_pred=pred,
                   metrics=dict(
                       R_ret=round(choice_quality(phI[-180:]), 3),
                       per_task_I_final=per_task_I,
                       II_belief_acc=(round(float(np.mean([e[4] for e in phII if e[4] is not None])), 3)
                                      if any(e[4] is not None for e in phII) else None),
                       II_choice_quality=round(choice_quality(phII), 3),
                       T80=t80,
                       R_reval=round(reval_ok / (3 * len(UTILITIES)), 3)))
    with open(out_path, "w") as f:
        json.dump(results, f, indent=1)
    print(json.dumps(results["metrics"], indent=1), flush=True)
    print("saved:", out_path, flush=True)

def _z(r, t_ref, e_ref, i_ref):
    return (r.success - 0.3 * r.time / t_ref - 0.02 * r.energy / e_ref
            - 0.5 * r.impact_max / i_ref)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--variant", default="joint")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--phaseI", type=int, default=200)
    ap.add_argument("--phaseII", type=int, default=300)
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    out = a.out or f"mvp_out/{a.variant}_s{a.seed}.json"
    os.makedirs(os.path.dirname(out), exist_ok=True)
    run(a.variant, a.seed, a.phaseI, a.phaseII, out)
