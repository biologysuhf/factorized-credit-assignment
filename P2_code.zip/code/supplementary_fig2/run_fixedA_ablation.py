"""Fixed-uniform A_cq ablation (generates the data for SI Fig. 2d).
Joint（learned A）vs Joint-fixedA（learn_A=False → A = ones(C,Q)/Q），
 Same FactorizedModel code version, seed-paired, n=20, T=3000, cue_noise=0.35.
 Output: exp3_fixedA_ablation.npy
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))   # directory of p2_exp3_emergent / p2_model
import numpy as np
from p2_exp3_emergent import arm_rewards, gen_schedule, risk_value, OPT
from p2_model import FactorizedModel, make_states

NSEEDS = 20
res = {"joint": [], "fixedA": []}
for v in ["joint", "fixedA"]:
    for s in range(NSEEDS):
        rng = np.random.default_rng(3000 + s)
        C, Q = 3, 7
        m = FactorizedModel(nfeat=16, Q=Q, C=C, seed=s,
                            eta_c=np.linspace(0.35, 0.15, C), lr_chan=0.2,
                            learn_A=(v == "joint"), learn_gate=True)
        arms = make_states(2, 16, seed=5)
        cf = make_states(3, 16, seed=9)
        ctx = gen_schedule(rng, 3000, 25)
        correct = np.zeros(3000); gate_rec = np.zeros((3000, C))
        for t in range(3000):
            c = ctx[t]
            o = cf[c] + 0.35 * rng.standard_normal(16); o /= np.linalg.norm(o)
            g = m.gate(o, context=c)
            if rng.random() < 0.10:
                a = rng.integers(0, 2)
            else:
                v0 = risk_value(m, arms[0]) + 0.02 * rng.standard_normal()
                v1 = risk_value(m, arms[1]) + 0.02 * rng.standard_normal()
                a = int(v1 > v0)
            r = arm_rewards(c, a, rng)
            m.learn(arms[a], r, context=c, g_pre=g, obs=o)
            correct[t] = float(a == OPT[c]); gate_rec[t] = g
        k = 50
        qual = float(np.convolve(correct, np.ones(k)/k, "same")[k:-k].mean())
        late = np.arange(3000) > 2600
        qbc = {c: float(correct[late & (ctx == c)].mean()) for c in range(3)}
        assign = gate_rec.argmax(1)
        purity = float(sum((assign == j).mean()
                           * max((ctx[assign == j] == c).mean() for c in range(3))
                           for j in range(C) if (assign == j).any()))
        res[v].append(dict(qual=qual, q_by_ctx=qbc, purity=purity))
        print(v, s, round(qual, 3), flush=True)

np.save(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                     "exp3_fixedA_ablation.npy"), res, allow_pickle=True)

from scipy.stats import wilcoxon
for tag, get in [("qual", lambda r: r["qual"]),
                 ("ctx2-safe", lambda r: r["q_by_ctx"][2]),
                 ("purity", lambda r: r["purity"])]:
    a = [get(r) for r in res["joint"]]; b = [get(r) for r in res["fixedA"]]
    print(f"{tag}: joint {np.mean(a):.3f}  fixedA {np.mean(b):.3f}  "
          f"Wilcoxon p = {wilcoxon(a, b).pvalue}")
