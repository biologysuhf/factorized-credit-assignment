"""Supplementary Fig. 2: context-routing robustness (4 panels), supports Fig. 3.
 Data:
     a/b : exp3_switch_sweep_seeds.npy (per-seed switch-rate sweep arrays,
                 n=20 seeds per point, error bars = std(ddof=1)/sqrt(20))
     c   : A matrix of joint from exp3_results.npy (20-seed mean)
     d   : exp3_fixedA_ablation.npy (paired ablation with the current code version, n=20)
 Output: supplementary_fig2.png
"""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.stats import wilcoxon
from matplotlib.patches import Patch

HERE = os.path.dirname(os.path.abspath(__file__))
CODE = os.path.dirname(os.path.abspath(__file__))   # adjust to the actual path if needed
res3 = np.load(os.path.join(CODE, "exp3_results.npy"), allow_pickle=True).item()
swseeds = np.load(os.path.join(HERE, "exp3_switch_sweep_seeds.npy"),
                  allow_pickle=True).item()
res_ab = np.load(os.path.join(HERE, "exp3_fixedA_ablation.npy"),
                 allow_pickle=True).item()

colors = {"scalar": "#888888", "comp": "#e8a33d", "joint": "#c0392b"}
sw = [20, 60, 150]


def ms(arr):
    """arr: (n_seeds,) -> mean, SEM"""
    return np.mean(arr), np.std(arr, ddof=1) / np.sqrt(len(arr))


fig = plt.figure(figsize=(14.5, 4.9), dpi=150)
gs = fig.add_gridspec(1, 4, wspace=0.45, width_ratios=[1, 1, 1.05, 1.15])
AXES = []

# ---------- a: choice quality vs switch rate ----------
ax = fig.add_subplot(gs[0, 0]); AXES.append(ax)
for v, mk, lb in [("joint", "o", "Joint"), ("comp", "s", "Comp-only")]:
    m = [ms(swseeds[("switch", L, v)]["qual"]) for L in sw]
    ax.errorbar(sw, [x[0] for x in m], yerr=[x[1] for x in m],
                fmt="-" + mk, c=colors[v], ms=6, lw=2, capsize=3,
                elinewidth=1, label=lb)
scalar_q = np.mean([r["qual"] for r in res3["scalar"]])
ax.axhline(scalar_q, ls=":", c=colors["scalar"], lw=1.5)
ax.text(148, scalar_q + 0.012, f"Scalar = {scalar_q:.2f}", fontsize=8.5,
        color=colors["scalar"], ha="right")
ax.set_xlabel("Mean block length (trials)")
ax.set_ylabel("Choice quality (learning off)")
ax.set_xticks(sw); ax.set_ylim(0.55, 0.95)
ax.set_title("Robustness to context-switch rate", fontsize=10.5,
             loc="left", fontweight="bold")
ax.legend(fontsize=8.5, frameon=False)
ax.spines[["top", "right"]].set_visible(False)

# ---------- b: gate purity vs switch rate ----------
ax = fig.add_subplot(gs[0, 1]); AXES.append(ax)
for v, mk, lb in [("joint", "o", "Joint"), ("comp", "s", "Comp-only")]:
    m = [ms(swseeds[("switch", L, v)]["purity"]) for L in sw]
    ax.errorbar(sw, [x[0] for x in m], yerr=[x[1] for x in m],
                fmt="-" + mk, c=colors[v], ms=6, lw=2, capsize=3,
                elinewidth=1, label=lb)
ax.set_xlabel("Mean block length (trials)"); ax.set_ylabel("Gate purity")
ax.set_xticks(sw); ax.set_ylim(0.75, 1.0)
ax.set_title("Routing fidelity vs switch rate", fontsize=10.5,
             loc="left", fontweight="bold")
ax.legend(fontsize=8.5, frameon=False)
ax.spines[["top", "right"]].set_visible(False)

# ---------- c: learned A matrix ----------
Amean = np.mean([r["A"] for r in res3["joint"]], 0)
colspread = (Amean.max(0) - Amean.min(0)).max()
ax = fig.add_subplot(gs[0, 2]); AXES.append(ax)
ax.set_title("Learned binding is\ncontext-generic", fontsize=9.5,
             fontweight="bold", pad=8, loc="left")
im = ax.imshow(Amean, cmap="viridis", vmin=0.05, vmax=0.2)
for i in range(3):
    for j in range(7):
        ax.text(j, i, f"{Amean[i, j]:.2f}", ha="center", va="center",
                fontsize=8, color="white" if Amean[i, j] < 0.12 else "black")
ax.set_xticks(range(7))
ax.set_xticklabels(["0.1", "0.25", "0.4", "0.5", "0.6", "0.75", "0.9"], fontsize=7.5)
ax.set_yticks(range(3)); ax.set_yticklabels(["ctx0", "ctx1", "ctx2"])
ax.set_xlabel(r"channel $\tau$")
cb = fig.colorbar(im, ax=ax, shrink=0.55, pad=0.02, anchor=(0, 0.15))
cb.set_label("A (mean)", fontsize=8); cb.ax.tick_params(labelsize=7)

# ---------- d: learned A vs fixed uniform ablation ----------
ax = fig.add_subplot(gs[0, 3]); AXES.append(ax)
xj = [0.8, 1.8]; xf = [1.2, 2.2]
for k, mk in enumerate(["qual", "q2"]):
    a = ([r["qual"] for r in res_ab["joint"]] if mk == "qual"
         else [r["q_by_ctx"][2] for r in res_ab["joint"]])
    b = ([r["qual"] for r in res_ab["fixedA"]] if mk == "qual"
         else [r["q_by_ctx"][2] for r in res_ab["fixedA"]])
    p = wilcoxon(a, b).pvalue
    ax.bar(xj[k], np.mean(a), 0.32, yerr=np.std(a, ddof=1)/np.sqrt(20),
           color=colors["joint"], capsize=3, error_kw=dict(lw=1))
    ax.bar(xf[k], np.mean(b), 0.32, yerr=np.std(b, ddof=1)/np.sqrt(20),
           color="#7fb3d5", capsize=3, error_kw=dict(lw=1))
    for s in range(20):
        ax.plot([xj[k], xf[k]], [a[s], b[s]], c="#ddd", lw=0.6, zorder=0)
    ax.text((xj[k] + xf[k]) / 2, max(np.mean(a), np.mean(b)) + 0.1,
            f"p = {p:.2f}" if p >= 0.01 else f"p = {p:.1e}",
            ha="center", fontsize=8.5)
ax.set_xticks([1, 2]); ax.set_xticklabels(["Overall\nquality", "Safe-arm\n(ctx2)"])
ax.set_ylim(0.4, 1.02); ax.set_ylabel("Score (learning off)")
ax.set_title(r"Learned $A$ vs fixed uniform $A_{cq}$", fontsize=10.5,
             loc="left", fontweight="bold")
ax.legend(handles=[Patch(fc=colors["joint"], label="Joint (learned $A$)"),
                   Patch(fc="#7fb3d5", label="Joint (fixed uniform $A_{cq}$)")],
          fontsize=7.5, frameon=False, loc="upper left")
ax.spines[["top", "right"]].set_visible(False)

for axx, L in zip(AXES, "abcd"):
    axx.text(-0.14, 1.06, L, transform=axx.transAxes, fontsize=15,
             fontweight="bold", va="bottom", ha="right")
fig.text(0.5, -0.03,
         f"c: across-context spread per channel ≤ {colspread:.3f} (20 seeds);"
         "   a/b/d: mean ± SEM, n = 20 seeds;   d: paired Wilcoxon",
         fontsize=8, color="#444", ha="center", va="top")
out = os.path.join(HERE, "supplementary_fig2.png")
fig.savefig(out, bbox_inches="tight")
print("saved:", os.path.abspath(out))
