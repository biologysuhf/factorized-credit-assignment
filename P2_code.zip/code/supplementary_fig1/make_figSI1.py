"""Supplementary Fig. 1: component analyses and channel-design controls (6 panels, supports Fig. 2).
    a) fidelity x retention scatter (scalar/comp have no expectile channels; fidelity undefined, noted only)
    b) mean V(s) stable throughout (exp2, n=10, mean +/- SEM)
    c) comp-0 channels after ctx B: joint retained / dist overwritten (exp1, n=10)
    d) matched-decoder controls, 9 variants (exp6b, n=20)
    e) 3 joint variants x 3 unseen utilities (exp6b, n=20)
    f) matched-decoder fidelity R2 (single held-out decode, no per-seed, no error bars)
 Data: exp1_results.npy / exp2_results.npy / exp6b_distributional_controls.npy
 Output: supplementary_fig1.png
"""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
e1 = np.load(os.path.join(HERE, "exp1_results.npy"), allow_pickle=True).item()
e2r = np.load(os.path.join(HERE, "exp2_results.npy"), allow_pickle=True).item()
d6 = np.load(os.path.join(HERE, "exp6b_distributional_controls.npy"),
             allow_pickle=True).item()
res6, r2 = d6["res"], d6["decoder_r2"]

C = {"scalar": "#888888", "dist": "#2176AE", "comp": "#E8A33D",
     "joint": "#C0392B", "oracle": "#2B2B2B"}

fig = plt.figure(figsize=(13, 7.4), dpi=150)
gs = fig.add_gridspec(2, 3, wspace=0.34, hspace=0.55)

# ---------- a: fidelity x retention ----------
ax = fig.add_subplot(gs[0, 0])
for v, lab in [("dist", "Distributional only"), ("joint", "Joint (full)")]:
    fid = [1 - r["dist_L1"] for r in e1[v]]
    ret = [r["retention"] for r in e1[v]]
    ax.errorbar(np.mean(fid), np.mean(ret),
                xerr=np.std(fid, ddof=1) / np.sqrt(len(fid)),
                yerr=np.std(ret, ddof=1) / np.sqrt(len(ret)),
                fmt="o", color=C[v], ms=9, mec="black", capsize=3, lw=1,
                label=lab, zorder=3)
    ax.scatter(fid, ret, color=C[v], s=14, alpha=0.45, zorder=2,
               edgecolor="none")
ax.set_xlim(-0.05, 1.08); ax.set_ylim(-0.05, 1.08)
ax.set_xlabel("Distributional fidelity (1 - L1)"); ax.set_ylabel("Retention")
ax.set_title("Only the joint model keeps both", fontsize=10, loc="left",
             fontweight="bold")
ax.legend(fontsize=8, frameon=False, loc="lower right")
ax.spines[["top", "right"]].set_visible(False)
ax.text(0.02, 0.60, "Scalar / comp-only:\nno expectile channels,\n"
        "fidelity undefined\n(retention 0.07 / 0.98)", fontsize=7.5,
        color="#555")

# ---------- b: mean value stable ----------
ax = fig.add_subplot(gs[0, 1])
t = np.arange(600)
for v, lab in [("joint", "Joint (full)"), ("dist", "Distributional only")]:
    tr = np.array([r["value_traj"] for r in e2r[v]])
    m = tr.mean(0); s = tr.std(0, ddof=1) / np.sqrt(len(tr))
    ax.plot(t, m, color=C[v], lw=1.2, label=lab)
    ax.fill_between(t, m - s, m + s, color=C[v], alpha=0.18, lw=0)
for xx in (200, 400):
    ax.axvline(xx, ls=":", c="k", lw=0.9)
ax.axhline(0.5, ls=":", c="gray", lw=0.8)
ax.text(100, 0.97, "A: Ber(.5)\nhigh var", ha="center", fontsize=7.5)
ax.text(300, 0.97, "A: r=0.5\nlow var", ha="center", fontsize=7.5)
ax.text(500, 0.97, "B: Ber(.5)\nnew ctx", ha="center", fontsize=7.5)
ax.set_ylim(0, 1.08); ax.set_xlabel("Trial"); ax.set_ylabel("Behavioral value V(s)")
ax.set_title("Mean value stable throughout", fontsize=10, loc="left",
             fontweight="bold")
ax.legend(fontsize=8, frameon=False, loc="lower right")
ax.spines[["top", "right"]].set_visible(False)

# ---------- c: comp-0 channels after ctx-B ----------
ax = fig.add_subplot(gs[0, 2])
ch = np.arange(1, 8)
for v, lab in [("dist", "Dist-only comp (overwritten)"),
               ("joint", "Joint comp-0 (preserved)")]:
    Y = np.array([r["ch0"] for r in e1[v]])
    ax.errorbar(ch, Y.mean(0), yerr=Y.std(0, ddof=1) / np.sqrt(len(Y)),
                fmt="o-", color=C[v], ms=5, lw=1.4, capsize=3, label=lab)
ax.set_xlabel("Channel (sorted by value)"); ax.set_ylabel("Channel value")
ax.set_ylim(0, 1.08)
ax.set_title("Comp-0 channels after ctx-B episode", fontsize=10, loc="left",
             fontweight="bold")
ax.legend(fontsize=8, frameon=False, loc="upper left")
ax.spines[["top", "right"]].set_visible(False)

# ---------- d/e/f: channel design controls (exp6b) ----------
TEST_UTILS = ["concave", "convex", "tail"]
UTIL_LABELS = {"concave": "Risk-averse", "convex": "Risk-seeking",
               "tail": "Lower-tail"}
variants = ["scalar", "moment", "expectile_dist", "expectile_joint",
            "quantile_dist", "quantile_joint", "categorical_dist",
            "categorical_joint", "oracle"]
xlabels = ["scal", "mom", "exp\ndist", "exp\njoint", "quan\ndist",
           "quan\njoint", "cat\ndist", "cat\njoint", "oracle"]
vcolors = ["#888888", "#aaaaaa", "#b7c9e2", "#2c5fa0", "#c3d9c0", "#2e7d43",
           "#e2c4b7", "#a04a2c", "#2B2B2B"]

def ms6(v, key=None, u=None):
    xs = np.array([r[key] for r in res6[v]] if key else
                  [r["per_utility"][u] for r in res6[v]], float)
    return xs.mean(), xs.std(ddof=1) / np.sqrt(len(xs))

ax = fig.add_subplot(gs[1, 0])
m = [ms6(v, "reval_acc") for v in variants]
ax.bar(range(9), [x[0] for x in m], yerr=[x[1] for x in m], color=vcolors,
       capsize=3, error_kw=dict(lw=1), width=0.68)
ax.axhline(0.5, ls=":", c="k", lw=0.9)
ax.set_xticks(range(9)); ax.set_xticklabels(xlabels, fontsize=7.5)
ax.set_ylabel("Zero-update revaluation acc."); ax.set_ylim(0.4, 1.03)
ax.set_title("Matched decoders (9 variants)", fontsize=10,
             loc="left", fontweight="bold")
ax.spines[["top", "right"]].set_visible(False)

ax = fig.add_subplot(gs[1, 1])
x = np.arange(3); w = 0.25
for i, (v, lab, c) in enumerate([("expectile_joint", "expectile", "#2c5fa0"),
                                 ("quantile_joint", "quantile", "#2e7d43"),
                                 ("categorical_joint", "categorical",
                                  "#a04a2c")]):
    m = [ms6(v, u=u) for u in TEST_UTILS]
    ax.bar(x + (i - 1) * w, [y[0] for y in m], w, yerr=[y[1] for y in m],
           label=lab, color=c, capsize=3, error_kw=dict(lw=1))
ax.axhline(0.5, ls=":", c="k", lw=0.9)
ax.set_xticks(x)
ax.set_xticklabels([UTIL_LABELS[u] for u in TEST_UTILS], fontsize=8.5)
ax.set_ylabel("Accuracy"); ax.set_ylim(0.4, 1.03)
ax.set_title("Joint variants per utility", fontsize=10, loc="left",
             fontweight="bold")
ax.legend(fontsize=8, frameon=False)
ax.spines[["top", "right"]].set_visible(False)

ax = fig.add_subplot(gs[1, 2])
reps = ["scalar", "moment", "expectile", "quantile", "categorical"]
x = np.arange(5); w = 0.25
for i, u in enumerate(TEST_UTILS):
    ax.bar(x + (i - 1) * w, [r2[(rep, u)] for rep in reps], w,
           label=UTIL_LABELS[u])
ax.set_xticks(x); ax.set_xticklabels(reps, fontsize=8, rotation=12)
ax.set_ylabel(r"Decoder $R^2$ (held-out)"); ax.set_ylim(0.85, 1.005)
ax.set_title("Matched-decoder fidelity", fontsize=10, loc="left",
             fontweight="bold")
ax.legend(fontsize=8, frameon=False)
ax.spines[["top", "right"]].set_visible(False)

for axx, L in zip(fig.axes, "abcdef"):
    axx.text(-0.14, 1.06, L, transform=axx.transAxes, fontsize=15,
             fontweight="bold", va="bottom", ha="right")
# the bottom statistics note has been moved to the figure caption:
# a-c: mean +/- SEM, n = 10 seeds; dots in a = individual seeds.
# d/e: mean +/- SEM, n = 20 seeds; f: single held-out decode.
out = os.path.join(HERE, "supplementary_fig1.png")
fig.savefig(out, bbox_inches="tight")
print("saved:", os.path.abspath(out))
