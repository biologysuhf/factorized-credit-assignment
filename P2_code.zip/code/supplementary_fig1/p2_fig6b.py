"""Figure for Exp6b matched-decoder distributional controls."""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from p2_exp6b_distributional_controls import TEST_UTILS

HERE = os.path.dirname(os.path.abspath(__file__))
d = np.load(os.path.join(HERE, 'exp6b_distributional_controls.npy'),
            allow_pickle=True).item()
res, r2 = d['res'], d['decoder_r2']

variants = ['scalar', 'moment',
            'expectile_dist', 'expectile_joint',
            'quantile_dist', 'quantile_joint',
            'categorical_dist', 'categorical_joint',
            'oracle']
labels = ['scal', 'mom',
          'exp\ndist', 'exp\njoint',
          'quan\ndist', 'quan\njoint',
          'cat\ndist', 'cat\njoint',
          'oracle']
colors = ['#888888', '#aaaaaa',
          '#b7c9e2', '#2c5fa0',
          '#c3d9c0', '#2e7d43',
          '#e2c4b7', '#a04a2c',
          '#333333']

fig, axes = plt.subplots(1, 3, figsize=(13, 4.2))

# (a) overall revaluation accuracy
ax = axes[0]
means = [np.mean([r['reval_acc'] for r in res[v]]) for v in variants]
sems = [np.std([r['reval_acc'] for r in res[v]]) / np.sqrt(len(res[v]))
        for v in variants]
ax.bar(range(len(variants)), means, yerr=sems, color=colors,
       capsize=3, edgecolor='k', linewidth=0.5)
ax.axhline(0.5, ls='--', c='r', lw=1)
ax.set_xticks(range(len(variants)))
ax.set_xticklabels(labels, fontsize=8)
ax.set_ylabel('zero-update revaluation acc.')
ax.set_ylim(0.4, 1.03)
ax.set_title('(a) distributional controls, matched decoders')

# (b) per-utility accuracy of the three joint variants
ax = axes[1]
x = np.arange(len(TEST_UTILS))
w = 0.25
for i, (v, lab, c) in enumerate([('expectile_joint', 'expectile', '#2c5fa0'),
                                 ('quantile_joint', 'quantile', '#2e7d43'),
                                 ('categorical_joint', 'categorical', '#a04a2c')]):
    mvals = [np.mean([r['per_utility'][u] for r in res[v]]) for u in TEST_UTILS]
    svals = [np.std([r['per_utility'][u] for r in res[v]])
             / np.sqrt(len(res[v])) for u in TEST_UTILS]
    ax.bar(x + (i - 1) * w, mvals, w, yerr=svals, label=lab, color=c,
           capsize=3, edgecolor='k', linewidth=0.5)
ax.axhline(0.5, ls='--', c='r', lw=1)
ax.set_xticks(x)
ax.set_xticklabels(TEST_UTILS)
ax.set_ylabel('accuracy')
ax.set_ylim(0.4, 1.03)
ax.legend(fontsize=8, frameon=False)
ax.set_title('(b) joint variants per utility')

# (c) matched-decoder held-out R^2
ax = axes[2]
reps = ['scalar', 'moment', 'expectile', 'quantile', 'categorical']
x = np.arange(len(reps))
w = 0.25
for i, u in enumerate(TEST_UTILS):
    ax.bar(x + (i - 1) * w, [r2[(rep, u)] for rep in reps], w, label=u,
           capsize=2, edgecolor='k', linewidth=0.5)
ax.set_xticks(x)
ax.set_xticklabels(reps, fontsize=8, rotation=15)
ax.set_ylabel(r'decoder $R^2$ (held-out)')
ax.set_ylim(0.85, 1.005)
ax.legend(fontsize=8, frameon=False)
ax.set_title('(c) matched-decoder fidelity')

fig.tight_layout()
fig.savefig(os.path.join(HERE, 'exp6b_distributional_controls.png'), dpi=200)
print('saved exp6b_distributional_controls.png')
