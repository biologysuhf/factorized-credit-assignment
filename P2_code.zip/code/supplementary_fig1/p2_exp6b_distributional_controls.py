"""
P2 Exp6b: matched-decoder distributional controls.

Exp6 showed that a 7-expectile joint (distribution x compartment) memory
supports zero-update revaluation.  A reviewer could object that this is
specific to expectiles, or that the distributional variants won because they
were given a privileged readout.  This experiment controls both:

  * The SAME task, acquisition phase and gate machinery as Exp6.
  * THREE nonlinear utility objectives (concave sqrt(r), convex r^2,
    lower-tail r - 3*(0.4-r)_+) instead of expectile-weight readouts, so no
    representation is aligned with the utility parameterisation.
  * Every representation -- scalar, moment, expectile, quantile, categorical
    (C51-like histogram) -- receives its own MATCHED ridge decoder
    representation-features -> E[u(r)], fitted on a shared analytic
    calibration set of random discrete reward distributions (no environment
    experience used for decoder fitting).
  * Decoder fidelity (held-out R^2) is reported so decoder privilege can be
    checked directly.

Prediction: joint (distribution x compartment) variants win for ALL THREE
distributional representations, with no systematic expectile advantage;
scalar/moment memories fail despite matched decoders.
"""
import numpy as np
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from p2_model import TAUS7, make_states
from p2_exp6_revaluation import (NCTX, NSEEDS, T, SWITCH, CUE_NOISE,
                                 DISTS, CTX_ARMS, sample_reward,
                                 expectile, gen_schedule)

TAUS = np.array(TAUS7)
NBINS = 7
BIN_LO = np.arange(NBINS) / NBINS            # bin lower edges over [0,1]
NCAL_TRAIN, NCAL_TEST = 6000, 2000
RIDGE_LAM = 1e-4

# Nonlinear utility objectives, deliberately NOT aligned with any
# representation's parameterisation.
UTIL_FUNCS = {
    'concave': lambda r: np.sqrt(r),
    'convex':  lambda r: r ** 2,
    'tail':    lambda r: r - 3.0 * np.maximum(0.4 - r, 0.0),
}
TEST_UTILS = list(UTIL_FUNCS)

# ---------------------------------------------------------------- true values
def true_quantiles(vals, probs, taus=TAUS):
    cdf = np.cumsum(probs)
    return np.array([vals[np.searchsorted(cdf, t)] for t in taus])

def hist_probs(vals, probs, nbins=NBINS):
    idx = np.clip((vals * nbins).astype(int), 0, nbins - 1)
    h = np.zeros(nbins)
    np.add.at(h, idx, probs)
    return h

TRUE_U = {u: np.zeros((NCTX, 2)) for u in TEST_UTILS}
for c in range(NCTX):
    for a in range(2):
        vals, probs = DISTS[CTX_ARMS[c][a]]
        for u, f in UTIL_FUNCS.items():
            TRUE_U[u][c, a] = float(probs @ f(vals))
OPT = {u: TRUE_U[u].argmax(axis=1) for u in TEST_UTILS}

# ------------------------------------------------- representation extraction
def rep_features(rep, vals, probs):
    """Analytic representation of a discrete reward distribution."""
    if rep == 'scalar':
        return np.array([probs @ vals])
    if rep == 'moment':
        r = vals
        return np.array([probs @ r, probs @ r**2, probs @ r**3,
                         probs @ np.maximum(r - 0.5, 0.0),
                         probs @ np.maximum(0.5 - r, 0.0)])
    if rep == 'expectile':
        return np.array([expectile(vals, probs, t) for t in TAUS])
    if rep == 'quantile':
        return true_quantiles(vals, probs)
    if rep == 'categorical':
        return hist_probs(vals, probs)
    raise ValueError(rep)

REPS = ['scalar', 'moment', 'expectile', 'quantile', 'categorical']

# ------------------------------------------- matched decoder (shared by all)
def sample_calibration_dists(n, rng):
    """Random discrete reward distributions: support size 1-4, uniform
    support values in [0,1], Dirichlet(1) probabilities."""
    out = []
    for _ in range(n):
        k = int(rng.integers(1, 5))
        vals = np.sort(rng.uniform(0.0, 1.0, k))
        probs = rng.dirichlet(np.ones(k))
        out.append((vals, probs))
    return out

def fit_matched_decoders(seed=0):
    """One ridge decoder per (representation, utility), fitted on the same
    analytic calibration set.  Returns decoders and held-out R^2."""
    rng = np.random.default_rng(777000 + seed)
    train = sample_calibration_dists(NCAL_TRAIN, rng)
    test = sample_calibration_dists(NCAL_TEST, rng)
    decoders, r2 = {}, {}
    for rep in REPS:
        Xtr = np.stack([rep_features(rep, v, p) for v, p in train])
        Xte = np.stack([rep_features(rep, v, p) for v, p in test])
        Xtr_b = np.hstack([np.ones((len(Xtr), 1)), Xtr])
        Xte_b = np.hstack([np.ones((len(Xte), 1)), Xte])
        for u, f in UTIL_FUNCS.items():
            ytr = np.array([p @ f(v) for v, p in train])
            yte = np.array([p @ f(v) for v, p in test])
            A = Xtr_b.T @ Xtr_b + RIDGE_LAM * np.eye(Xtr_b.shape[1])
            beta = np.linalg.solve(A, Xtr_b.T @ ytr)
            pred = Xte_b @ beta
            ss_res = float(((yte - pred) ** 2).sum())
            ss_tot = float(((yte - yte.mean()) ** 2).sum())
            decoders[(rep, u)] = beta
            r2[(rep, u)] = 1.0 - ss_res / ss_tot
    return decoders, r2

DECODERS, DECODER_R2 = fit_matched_decoders()

# ------------------------------------------------------------------- model
class GenericMemory:
    """Compartmented memory with a learnable prototype gate, storing any one
    of the five reward representations.  Gate machinery matches Exp6."""
    def __init__(self, rep, nfeat=16, C=4, seed=0, lr=0.1, learn_gate=True):
        self.rep = rep
        self.rng = np.random.default_rng(seed)
        self.N, self.C = nfeat, C
        self.lr = lr
        self.learn_gate = learn_gate
        self.K = len(rep_features(rep, np.array([0.5]), np.array([1.0])))
        self.W = np.zeros((C, self.K, nfeat))
        self.proto = np.zeros((C, nfeat))
        self.proto_n = np.zeros(C)
        if learn_gate and C > 1:
            P0 = self.rng.normal(0, 1, (C, nfeat))
            self.proto = P0 / np.linalg.norm(P0, axis=1, keepdims=True)
            self.proto_n = np.ones(C)
        self.gate_calls = 0
        self.last_g = np.zeros(C)

    @staticmethod
    def _cos(a, b):
        n = np.linalg.norm(a) * np.linalg.norm(b)
        return float(a @ b / n) if n > 0 else 0.0

    def gate(self, x, context=None):
        if not self.learn_gate or self.C == 1:
            g = np.zeros(self.C)
            g[(context or 0) % self.C] = 1.0
        else:
            self.gate_calls += 1
            temp = min(4.0 + self.gate_calls / 200.0, 12.0)
            sims = np.array([self._cos(x, self.proto[c]) for c in range(self.C)])
            usage = self.proto_n / self.proto_n.sum()
            util = temp * sims - 1.0 * np.log(usage + 1e-6)
            g = np.exp(util - util.max())
            g /= g.sum()
        self.last_g = g
        return g

    def target(self, r):
        """Per-sample regression target for the stored representation."""
        v = np.array([r])
        p = np.array([1.0])
        if self.rep == 'quantile':
            return v                      # handled by pinball update below
        return rep_features(self.rep, v, p)

    def learn(self, x, r, g_pre=None, obs=None):
        g = g_pre if g_pre is not None else self.gate(x)
        for c in range(self.C):
            if g[c] < 1e-3:
                continue
            pred = self.W[c] @ x
            if self.rep == 'quantile':
                # subgradient of the pinball loss: converges to quantiles
                err = TAUS - (r < pred).astype(float)
                self.W[c] += self.lr * g[c] * err[:, None] * x[None, :]
            elif self.rep == 'expectile':
                d = r - pred
                self.W[c] += (self.lr * g[c]
                              * np.where(d >= 0, TAUS, 1 - TAUS)[:, None]
                              * d[:, None] * x[None, :])
            else:
                err = self.target(r) - pred
                self.W[c] += self.lr * g[c] * err[:, None] * x[None, :]
        if self.learn_gate and self.C > 1:
            xg = obs if obs is not None else x
            win = int(g.argmax())
            self.proto[win] = ((self.proto[win] * self.proto_n[win] + xg)
                               / (self.proto_n[win] + 1))
            self.proto_n[win] += 1
        return g

    def features(self, x, g):
        """Gate-weighted representation of the distribution at state x."""
        f = np.einsum('c,ck->k', g, self.W @ x)
        if self.rep == 'categorical':
            f = np.clip(f, 0.0, None)
            s = f.sum()
            if s > 1e-9:
                f /= s
        return f

def make_model(variant, seed):
    if variant == 'scalar':                       # shared scalar memory
        return GenericMemory('scalar', C=1, seed=seed, learn_gate=False)
    if variant == 'moment':
        return GenericMemory('moment', C=1, seed=seed, learn_gate=False)
    rep, joint = variant.rsplit('_', 1)
    if joint == 'dist':                           # shared distributional memory
        return GenericMemory(rep, C=1, seed=seed, learn_gate=False)
    if joint == 'joint':                          # distribution x compartments
        return GenericMemory(rep, C=4, seed=seed, learn_gate=True)
    raise ValueError(variant)

# ---------------------------------------------------------------------- run
def run(variant, seed, cue_noise=CUE_NOISE):
    rng = np.random.default_rng(32000 + seed)
    if variant == 'oracle':
        per_utility = {u: 1.0 for u in TEST_UTILS}
        choices = {u: OPT[u].copy() for u in TEST_UTILS}
        return dict(variant=variant, seed=seed, reval_acc=1.0,
                    per_utility=per_utility, choices=choices,
                    purity=1.0, neff=float(NCTX))
    m = make_model(variant, seed)
    arms = make_states(2, 16, seed=5)
    ctx_feats = make_states(NCTX, 16, seed=9)
    ctx = gen_schedule(rng, T, SWITCH)
    gate_rec = np.zeros((T, m.C))

    # ---- acquisition: raw rewards only, random policy ----
    for t in range(T):
        c = ctx[t]
        o = ctx_feats[c] + cue_noise * rng.standard_normal(16)
        o /= np.linalg.norm(o)
        g = m.gate(o) if m.C > 1 else np.ones(1)
        a = int(rng.integers(0, 2))
        r = sample_reward(c, a, rng)
        m.learn(arms[a], r, g_pre=g, obs=o)
        gate_rec[t] = g

    # ---- freeze: matched decoders, zero updates ----
    per_utility, choices = {}, {}
    for u in TEST_UTILS:
        ch = np.zeros(NCTX, dtype=int)
        co = np.zeros(NCTX)
        for c in range(NCTX):
            o = ctx_feats[c] / np.linalg.norm(ctx_feats[c])
            g = m.gate(o) if m.C > 1 else np.ones(1)
            beta = DECODERS[(m.rep, u)]
            vals = np.zeros(2)
            for a in range(2):
                f = m.features(arms[a], g)
                vals[a] = beta[0] + beta[1:] @ f
            ch[c] = int(vals[1] > vals[0])
            co[c] = float(np.isclose(TRUE_U[u][c, ch[c]],
                                     TRUE_U[u][c].max()))
        choices[u] = ch
        per_utility[u] = float(co.mean())

    purity = neff = np.nan
    if m.C > 1:
        assign = gate_rec.argmax(1)
        usage = np.array([(assign == j).mean() for j in range(m.C)])
        neff = float(np.exp(-(usage[usage > 1e-9]
                              * np.log(usage[usage > 1e-9])).sum()))
        purity = float(sum((assign == j).mean()
                           * max((ctx[assign == j] == c).mean()
                                 for c in range(NCTX))
                           for j in range(m.C) if (assign == j).any()))
    acc = float(np.mean([per_utility[u] for u in TEST_UTILS]))
    return dict(variant=variant, seed=seed, reval_acc=acc,
                per_utility=per_utility, choices=choices,
                purity=purity, neff=neff)


if __name__ == '__main__':
    variants = ['scalar', 'moment',
                'expectile_dist', 'quantile_dist', 'categorical_dist',
                'expectile_joint', 'quantile_joint', 'categorical_joint',
                'oracle']

    print('Matched-decoder held-out R^2 (calibration set):')
    print(f"{'rep':12s} " + ' '.join(f"{u:>9s}" for u in TEST_UTILS))
    for rep in REPS:
        print(f"{rep:12s} " + ' '.join(f"{DECODER_R2[(rep, u)]:9.3f}"
                                       for u in TEST_UTILS))
    print('\nTrue utility-optimal arms per context:')
    for u in TEST_UTILS:
        print(f'  {u:9s}: {OPT[u].tolist()}')

    res = {v: [] for v in variants}
    for v in variants:
        for s in range(NSEEDS):
            res[v].append(run(v, s))
            print(f'  done {v} seed {s}', flush=True)

    HERE = os.path.dirname(os.path.abspath(__file__))
    np.save(os.path.join(HERE, 'exp6b_distributional_controls.npy'),
            dict(res=res, decoder_r2=DECODER_R2), allow_pickle=True)

    print('\nSummary (zero-update revaluation accuracy):')
    print(f"{'variant':18s} {'reval':>7s} {'purity':>7s} {'neff':>5s}")
    for v in variants:
        acc = np.array([r['reval_acc'] for r in res[v]])
        pur = np.array([r['purity'] for r in res[v]])
        nef = np.array([r['neff'] for r in res[v]])
        print(f"{v:18s} {acc.mean():7.3f} {np.nanmean(pur):7.3f} "
              f"{np.nanmean(nef):5.2f}")

    print('\nPer-utility accuracy:')
    for v in variants:
        vals = [np.mean([r['per_utility'][u] for r in res[v]])
                for u in TEST_UTILS]
        print(f"{v:18s} " + ' '.join(f"{u}={x:.3f}"
                                     for u, x in zip(TEST_UTILS, vals)))

    from scipy import stats
    print('\nPaired tests (n=%d):' % NSEEDS)
    for rep in ['expectile', 'quantile', 'categorical']:
        j = np.array([r['reval_acc'] for r in res[f'{rep}_joint']])
        d_only = np.array([r['reval_acc'] for r in res[f'{rep}_dist']])
        best_base = np.maximum(
            d_only,
            np.maximum(np.array([r['reval_acc'] for r in res['scalar']]),
                       np.array([r['reval_acc'] for r in res['moment']])))
        dd = j - best_base
        tt, pp = stats.ttest_1samp(dd, 0)
        dz = dd.mean() / (dd.std() + 1e-12)
        print(f"  {rep:12s} joint - max(dist,scalar,moment): "
              f"{dd.mean():+.4f} t={tt:.2f} p={pp:.3e} dz={dz:.2f}")

    # Representation parity among joint variants
    e = np.array([r['reval_acc'] for r in res['expectile_joint']])
    q = np.array([r['reval_acc'] for r in res['quantile_joint']])
    c51 = np.array([r['reval_acc'] for r in res['categorical_joint']])
    for name, a, b in [('exp-quan', e, q), ('exp-cat', e, c51),
                       ('quan-cat', q, c51)]:
        tt, pp = stats.ttest_rel(a, b)
        print(f"  joint {name}: diff={(a - b).mean():+.4f} t={tt:.2f} p={pp:.3e}")
