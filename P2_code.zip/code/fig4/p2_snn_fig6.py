"""Figure for P2 Exp6-SNN replication."""
import numpy as np
import matplotlib.pyplot as plt
import os
from p2_exp6_revaluation import TEST_UTILS

HERE = os.path.dirname(os.path.abspath(__file__))
res = np.load(os.path.join(HERE, 'snn_exp6_revaluation.npy'), allow_pickle=True).item()
colors = {'scalar': '#8c8c8c', 'dist': '#2176ae', 'comp': '#e8a33d',
          'randgate': '#7a5195', 'joint': '#c0392b', 'oracle': '#2b2b2b'}
labels = {'scalar': 'Scalar', 'dist': 'Dist-only', 'comp': 'Comp-only',
          'randgate': 'Rand-gate', 'joint': 'Joint', 'oracle': 'Oracle-gate'}
variants = ['scalar', 'dist', 'comp', 'randgate', 'joint', 'oracle']
util_labels = {'risk_averse': 'Risk-averse', 'risk_seeking': 'Risk-seeking',
               'lower_tail': 'Lower-tail'}

fig, axes = plt.subplots(1, 3, figsize=(10.8, 3.4))

ax = axes[0]
means = [np.mean([r['reval_acc'] for r in res[v]]) for v in variants]
sems = [np.std([r['reval_acc'] for r in res[v]]) / np.sqrt(len(res[v]))
        for v in variants]
ax.bar(np.arange(len(variants)), means, yerr=sems, capsize=3,
       color=[colors[v] for v in variants], width=0.68)
ax.axhline(0.5, color='k', ls=':', lw=0.9)
ax.set_xticks(np.arange(len(variants)))
ax.set_xticklabels([labels[v] for v in variants], rotation=25, ha='right', fontsize=7)
ax.set_ylim(0, 1.05); ax.set_ylabel('Zero-update accuracy')
ax.set_title('a  AC-SNN revaluation', loc='left', fontsize=9.5,
             fontweight='bold')

ax = axes[1]
show = ['scalar', 'dist', 'comp', 'joint', 'oracle']
x = np.arange(len(TEST_UTILS)); width = 0.15
for i, v in enumerate(show):
    vals = [np.mean([r['per_utility'][u] for r in res[v]]) for u in TEST_UTILS]
    ax.bar(x + (i - 2) * width, vals, width * 0.9, color=colors[v],
           label=labels[v])
ax.axhline(0.5, color='k', ls=':', lw=0.9)
ax.set_xticks(x); ax.set_xticklabels([util_labels[u] for u in TEST_UTILS], fontsize=8)
ax.set_ylim(0, 1.08); ax.set_ylabel('Accuracy')
ax.set_title('b  Frozen utility readouts', loc='left', fontsize=9.5,
             fontweight='bold')
ax.legend(fontsize=6, frameon=False, ncol=2)

ax = axes[2]
shown = ['dist', 'randgate', 'joint', 'oracle']
means = [np.mean([r['dist_l1'] for r in res[v]]) for v in shown]
sems = [np.std([r['dist_l1'] for r in res[v]]) / np.sqrt(len(res[v]))
        for v in shown]
ax.bar(np.arange(len(shown)), means, yerr=sems, capsize=3,
       color=[colors[v] for v in shown], width=0.62)
ax.set_xticks(np.arange(len(shown)))
ax.set_xticklabels([labels[v] for v in shown], rotation=20, ha='right', fontsize=7)
ax.set_ylabel('Expectile L1 error')
ax.set_ylim(0, 0.1)
pur = np.mean([r['purity'] for r in res['joint']])
ax.text(0.03, 0.92, f'Joint purity = {pur:.2f}', transform=ax.transAxes,
        fontsize=8)
ax.set_title('c  Spiking memory retention', loc='left', fontsize=9.5,
             fontweight='bold')

for a in axes:
    a.spines[['top', 'right']].set_visible(False)
fig.tight_layout()
fig.savefig(os.path.join(HERE, 'snn_exp6_revaluation.png'), dpi=220)
print('saved snn_exp6_revaluation.png')
