"""
P2 Phase 3: minimal spiking implementation of factorized credit assignment
on the AC-SNN substrate, reproducing the Exp1 reversal result.

Substrate (from AC-SNN / P1):
  PN (40) -> KC (200, k-WTA 20) spiking LIF; odor presentation gives
  eligibility traces e_hat (synapse-local) and KC rates r.
  Context cue gates the compartment (gate input only, as in P1).

New (P2): the teaching signal is a POPULATION of Q distributional DAN
channels per compartment:
  V_{q,c}(odor) = u_{q,c} . r        (channel value readout)
  delta_q = r_rew - V_{q,c}
  d_q = alpha_q^+ delta_q (>=0) / alpha_q^- delta_q (<0)   -> expectiles
  M_c = sum_q A_cq d_q               (broadcast, heterogeneous)
Three-factor plasticity at KC->MBON synapses:
  dW_c = -eta_c * g_c * M_c * e_hat  (+ P1 decay toward W0)

Task: reversal contextual bandit on two odors (arms).
  ctx A: odor0 -> Ber(0.8), odor1 -> Ber(0.2)
  ctx B: reversed
  phases: A (250) -> B (250) -> probe A (20, learning off)
Variants: scalar (Q=1,C=1), dist (Q=7,C=1), comp (Q=1,C=2), joint (Q=7,C=2).
"""
import numpy as np
import sys, os
sys.path.insert(0, '.')
from acsnn_model import (make_stimuli, run_odor, N_KC, W0, W_CLIP,
                         ETA_PUN, LAM_AP, ETA_REW, LAM_AV, KAPPA)

TAUS7 = (0.1, 0.25, 0.4, 0.5, 0.6, 0.75, 0.9)

# task / training parameters
N1, N2, N3 = 250, 250, 20
EPS = 0.10
NSEEDS = 8
LR_CHAN = 0.4          # channel (DAN input) learning rate
KAPPA_Q = 0.4          # channel value scale
P_REW = {(0, 0): 0.8, (0, 1): 0.2, (1, 0): 0.2, (1, 1): 0.8}
N_NOISE = 4            # Poisson realizations per odor


def channel_alphas(Q):
    if Q == 7:
        taus = np.array(TAUS7)
    elif Q == 1:
        taus = np.array([0.5])
    else:
        taus = np.linspace(0.1, 0.9, Q)
    return taus, 1.0 - taus


class SpikingFactorized:
    """KC->MBON compartments driven by Q distributional DAN channels."""

    def __init__(self, Q=7, C=2, seed=0):
        self.Q, self.C = Q, C
        self.a_pos, self.a_neg = channel_alphas(Q)
        # MBON weights per compartment (approach-readout, P1 style)
        self.W = [np.full(N_KC, W0) for _ in range(C)]
        self.eta = [ETA_REW] * C
        self.lam = [LAM_AV] * C
        # DAN channel input weights per compartment: u[q][c]
        self.U = np.zeros((C, Q, N_KC))
        self.A = np.ones((C, Q)) / Q

    def chan_values(self, r_raw, c):
        return KAPPA_Q * (self.U[c] @ r_raw)          # (Q,)

    def learn(self, e_hat, r_raw, rew, ctx):
        c = ctx % self.C
        Vq = self.chan_values(r_raw, c)
        d = rew - Vq
        dq = np.where(d >= 0, self.a_pos * d, self.a_neg * d)
        # channel (DAN input) plasticity: expectile convergence, gated
        step = LR_CHAN * np.where(d >= 0, self.a_pos, self.a_neg) * d
        self.U[c] += step[:, None] * r_raw[None, :]
        # teaching signal broadcast; three-factor KC->MBON update
        M = float(self.A[c] @ dq)
        self.W[c] -= self.eta[c] * M * e_hat
        np.clip(self.W[c], *W_CLIP, out=self.W[c])

    def decay(self):
        for c in range(self.C):
            self.W[c] = W0 + (self.W[c] - W0) * self.lam[c]

    def behavior_value(self, r_raw, ctx):
        """value from the distributional channels (mean over channels)."""
        c = ctx % self.C
        return float(self.chan_values(r_raw, c).mean())


def true_expectiles(p, taus=TAUS7):
    t = np.asarray(taus, float)
    return t * p / (t * p + (1 - t) * (1 - p))


def run(variant, seed):
    rng = np.random.default_rng(7000 + seed)
    Q = 7 if variant in ('dist', 'joint') else 1
    C = 2 if variant in ('comp', 'joint') else 1
    stim = make_stimuli(seed=100 + seed, n_odor=2, n_critical=2)
    # cache a few Poisson realizations per odor
    cache = {o: [run_odor(stim, o, poisson_seed=seed * 100 + o * 10 + k)
                 for k in range(N_NOISE)] for o in range(2)}
    m = SpikingFactorized(Q=Q, C=C, seed=seed)

    acc1 = np.zeros(N1); acc2 = np.zeros(N2); acc3 = np.zeros(N3)
    dist_l1 = np.nan

    def trial(ctx, t_rec, acc, learn_on=True):
        # choose arm
        if rng.random() < EPS:
            a = rng.integers(0, 2)
        else:
            vals = []
            for o in range(2):
                _, _, rr = cache[o][rng.integers(0, N_NOISE)]
                vals.append(m.behavior_value(rr, ctx))
            a = int(vals[1] > vals[0])
        e_hat, _, r_raw = cache[a][rng.integers(0, N_NOISE)]
        r = float(rng.random() < P_REW[(ctx, a)])
        if learn_on:
            m.learn(e_hat, r_raw, r, ctx)
            m.decay()
        acc[t_rec] = float(a == (0 if ctx == 0 else 1))
        return a

    for t in range(N1):
        trial(0, t, acc1)
    if Q == 7:
        dist_l1 = 0.0
        for arm, p in ((0, 0.8), (1, 0.2)):
            _, _, rr = cache[arm][0]
            pred = np.sort(m.chan_values(rr, 0))
            dist_l1 += np.abs(pred - true_expectiles(p)).mean()
        dist_l1 /= 2
    for t in range(N2):
        trial(1, t, acc2)
    for t in range(N3):
        trial(0, t, acc3, learn_on=False)

    out = dict(a1_end=float(acc1[-20:].mean()),
               a2_start=float(acc2[:10].mean()),
               a2_end=float(acc2[-20:].mean()),
               retention=float(acc3[:10].mean()),
               curve=np.concatenate([acc1, acc2, acc3]))
    if Q == 7:
        out['dist_L1'] = float(dist_l1)
        ch = {}
        for arm in (0, 1):
            _, _, rr = cache[arm][0]
            ch[arm] = np.sort(m.chan_values(rr, 0))
        out['ch'] = ch
    return out


if __name__ == '__main__':
    variants = ['scalar', 'dist', 'comp', 'joint']
    res = {v: [] for v in variants}
    for v in variants:
        for s in range(NSEEDS):
            res[v].append(run(v, s))
            print(f'  {v} seed {s} done', flush=True)
    HERE = os.path.dirname(os.path.abspath(__file__))
    np.save(os.path.join(HERE, 'snn_exp1_results.npy'), res, allow_pickle=True)
    for v in variants:
        line = f"{v:8s}"
        for k in ('a1_end', 'a2_start', 'a2_end', 'retention', 'dist_L1'):
            if k in res[v][0]:
                vals = [r[k] for r in res[v]]
                line += f"  {k} {np.mean(vals):.3f}±{np.std(vals):.3f}"
        print(line)
