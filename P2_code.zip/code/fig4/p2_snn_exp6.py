"""
P2 Exp6-SNN: deferred-utility zero-update revaluation on the AC-SNN substrate.

Odors 0/1 are the two actions; odors 2..5 are latent context cues. Context
spike representations drive only the compartment gate. Action KC rates drive
per-compartment distributional channel learning:
    V_{q,c}(odor) = kappa_q * u_{q,c} . r_KC(odor)
    d_q = alpha_q^+/- (r - V_{q,c})
    M_c = sum_q A_cq d_q,   A fixed uniform
    Delta W_c = -eta_c g_c M_c e_hat

Training receives raw rewards only. At test, W/U/gate prototypes are frozen;
risk readouts are changed without synaptic updates.
"""
import numpy as np
import sys, os
sys.path.insert(0, '.')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from acsnn_model import make_stimuli, run_odor, N_KC, W0, W_CLIP, ETA_REW, LAM_AV
from p2_exp6_revaluation import (NCTX, CTX_ARMS, sample_reward,
                                 TRUE_EXPECTILES, UTILITIES, TEST_UTILS)

TAUS7 = np.array([0.1, 0.25, 0.4, 0.5, 0.6, 0.75, 0.9])
NSEEDS = 20
T = 4800
SWITCH = 40
N_NOISE = 4
LR_CHAN = 0.35
KAPPA_Q = 0.4


def channel_alphas(Q):
    if Q == 7:
        taus = TAUS7
    elif Q == 1:
        taus = np.array([0.5])
    else:
        taus = np.linspace(0.1, 0.9, Q)
    return taus, 1.0 - taus


class SpikingDistributionalMemory:
    def __init__(self, Q=7, C=4, seed=0, learn_gate=True):
        self.Q, self.C = Q, C
        self.learn_gate = learn_gate
        self.a_pos, self.a_neg = channel_alphas(Q)
        self.W = np.tile(np.full(N_KC, W0), (C, 1))
        self.U = np.zeros((C, Q, N_KC))
        self.A = np.ones((C, Q)) / Q
        self.eta = ETA_REW
        self.lam = LAM_AV
        rng = np.random.default_rng(seed)
        if learn_gate:
            P0 = rng.normal(0, 1, (C, N_KC))
            self.proto = P0 / np.linalg.norm(P0, axis=1, keepdims=True)
            self.proto_n = np.ones(C)
        self.gate_calls = 0

    @staticmethod
    def _cos(a, b):
        n = np.linalg.norm(a) * np.linalg.norm(b)
        return float(a @ b / n) if n > 0 else 0.0

    def gate(self, cue_r, context=None):
        if not self.learn_gate:
            g = np.zeros(self.C); g[(context or 0) % self.C] = 1.0
            return g
        self.gate_calls += 1
        temp = min(4.0 + self.gate_calls / 200.0, 12.0)
        sims = np.array([self._cos(cue_r, self.proto[c]) for c in range(self.C)])
        usage = self.proto_n / self.proto_n.sum()
        util = temp * sims - np.log(usage + 1e-6)
        g = np.exp(util - util.max()); g /= g.sum()
        return g

    def learn(self, e_hat, arm_r, cue_r, reward, g):
        # Channel learning is gated by the context compartment.
        for c in range(self.C):
            if g[c] < 1e-3:
                continue
            Vq = KAPPA_Q * (self.U[c] @ arm_r)
            d = reward - Vq
            step = LR_CHAN * g[c] * np.where(d >= 0, self.a_pos, self.a_neg) * d
            self.U[c] += step[:, None] * arm_r[None, :]
            dq = np.where(d >= 0, self.a_pos * d, self.a_neg * d)
            M = float(self.A[c] @ dq)
            self.W[c] -= self.eta * g[c] * M * e_hat
        np.clip(self.W, *W_CLIP, out=self.W)
        if self.learn_gate:
            win = int(g.argmax())
            self.proto[win] = ((self.proto[win] * self.proto_n[win] + cue_r)
                               / (self.proto_n[win] + 1))
            self.proto_n[win] += 1
        # Preserve P1's slow compartment decay for the MBON synapses.
        self.W = W0 + (self.W - W0) * self.lam

    def values(self, arm_rs, g, utility):
        w = UTILITIES[utility] if self.Q == 7 else np.ones(self.Q) / self.Q
        Vq = np.stack([KAPPA_Q * (self.U[c] @ arm_rs[a])
                       for a in range(2) for c in range(self.C)])
        Vq = Vq.reshape(2, self.C, self.Q)
        return Vq @ w @ g


def gen_schedule(rng, T, switch_every):
    ctx = np.zeros(T, dtype=int)
    t, cur = 0, rng.integers(0, NCTX)
    while t < T:
        if t > 0:
            cur = (cur + rng.integers(1, NCTX)) % NCTX
        L = int(rng.exponential(switch_every)) + 10
        ctx[t:t + L] = cur
        t += L
    return ctx


def run(variant, seed):
    rng = np.random.default_rng(33000 + seed)
    Q = 7 if variant in ('dist', 'joint', 'randgate', 'oracle') else 1
    C = 1 if variant in ('scalar', 'dist') else 4
    learn_gate = variant in ('comp', 'joint')
    stim = make_stimuli(seed=200 + seed, n_odor=6, n_critical=2)
    # odors 0/1 = actions; odors 2..5 = context cues
    cache = {o: [run_odor(stim, o, poisson_seed=seed * 1000 + o * 20 + k)
                 for k in range(N_NOISE)] for o in range(6)}
    m = SpikingDistributionalMemory(Q=Q, C=C, seed=seed,
                                    learn_gate=learn_gate)
    ctx = gen_schedule(rng, T, SWITCH)
    gate_rec = np.zeros((T, C))

    for t in range(T):
        c = ctx[t]
        cue_r = cache[2 + c][rng.integers(0, N_NOISE)][2]
        cue_r = cue_r / (np.linalg.norm(cue_r) + 1e-12)
        if variant == 'randgate':
            g = np.eye(C)[rng.integers(0, C)]
        else:
            g = m.gate(cue_r, context=c if variant == 'oracle' else None)
        a = int(rng.integers(0, 2))
        e_hat, _, arm_r = cache[a][rng.integers(0, N_NOISE)]
        r = sample_reward(c, a, rng)
        m.learn(e_hat, arm_r, cue_r, r, g)
        gate_rec[t] = g

    # Frozen zero-update revaluation.
    choices = {}; correct = {}; regret = {}; per_utility = {}
    arm_rs_clean = [cache[a][0][2] for a in range(2)]
    for u in TEST_UTILS:
        ch = np.zeros(NCTX, dtype=int); co = np.zeros(NCTX); re = np.zeros(NCTX)
        for c in range(NCTX):
            cue_r = cache[2 + c][0][2]
            cue_r = cue_r / (np.linalg.norm(cue_r) + 1e-12)
            if variant == 'randgate':
                g = np.eye(C)[rng.integers(0, C)]
            else:
                g = m.gate(cue_r, context=c if variant == 'oracle' else None)
            vals = m.values(arm_rs_clean, g, u)
            a = int(vals[1] > vals[0])
            true_v = TRUE_EXPECTILES[c] @ UTILITIES[u]
            ch[c] = a
            co[c] = float(np.isclose(true_v[a], true_v.max()))
            re[c] = float(true_v.max() - true_v[a])
        choices[u] = ch; correct[u] = co; regret[u] = re
        per_utility[u] = float(co.mean())

    dist_l1 = np.nan; per_ctx_l1 = {}
    if Q == 7:
        l1s = []
        for c in range(NCTX):
            cue_r = cache[2 + c][0][2]
            cue_r = cue_r / (np.linalg.norm(cue_r) + 1e-12)
            if variant == 'randgate':
                g = np.eye(C)[rng.integers(0, C)]
            else:
                g = m.gate(cue_r, context=c if variant == 'oracle' else None)
            j = int(g.argmax())
            pred = np.stack([KAPPA_Q * (m.U[j] @ arm_rs_clean[a])
                             for a in range(2)])
            l1 = float(np.abs(pred - TRUE_EXPECTILES[c]).mean())
            per_ctx_l1[c] = l1; l1s.append(l1)
        dist_l1 = float(np.mean(l1s))

    purity = neff = np.nan
    if C > 1 and variant != 'randgate':
        assign = gate_rec.argmax(1)
        usage = np.array([(assign == j).mean() for j in range(C)])
        neff = float(np.exp(-(usage[usage > 1e-9]
                              * np.log(usage[usage > 1e-9])).sum()))
        purity = float(sum((assign == j).mean()
                           * max((ctx[assign == j] == c).mean()
                                 for c in range(NCTX))
                           for j in range(C) if (assign == j).any()))
    acc = float(np.mean([per_utility[u] for u in TEST_UTILS]))
    reg = float(np.mean([regret[u].mean() for u in TEST_UTILS]))
    return dict(variant=variant, seed=seed, reval_acc=acc, reval_regret=reg,
                per_utility=per_utility, choices=choices, correct=correct,
                regret=regret, dist_l1=dist_l1, per_ctx_l1=per_ctx_l1,
                purity=purity, neff=neff, gate_rec=gate_rec, ctx=ctx)


if __name__ == '__main__':
    variants = ['scalar', 'dist', 'comp', 'randgate', 'joint', 'oracle']
    res = {v: [] for v in variants}
    for v in variants:
        for s in range(NSEEDS):
            res[v].append(run(v, s))
            print(f'{v} seed {s} done', flush=True)
    HERE = os.path.dirname(os.path.abspath(__file__))
    np.save(os.path.join(HERE, 'snn_exp6_revaluation.npy'), res,
            allow_pickle=True)
    print('\nSummary:')
    for v in variants:
        acc = np.array([r['reval_acc'] for r in res[v]])
        reg = np.array([r['reval_regret'] for r in res[v]])
        l1 = np.array([r['dist_l1'] for r in res[v]], float)
        pur = np.array([r['purity'] for r in res[v]], float)
        print(f"{v:8s} acc {acc.mean():.3f}±{acc.std():.3f} "
              f"reg {reg.mean():.3f} L1 {np.nanmean(l1):.3f} "
              f"purity {np.nanmean(pur):.3f}")
        print('  ', {u: round(np.mean([r['per_utility'][u] for r in res[v]]), 3)
                     for u in TEST_UTILS})
    from scipy import stats
    j = np.array([r['reval_acc'] for r in res['joint']])
    best = np.maximum(np.array([r['reval_acc'] for r in res['dist']]),
                      np.array([r['reval_acc'] for r in res['comp']]))
    d = j - best
    tt, pp = stats.ttest_1samp(d, 0)
    print(f"\nsynergy joint-max(dist,comp): {d.mean():+.4f}±{d.std():.4f} "
          f"t={tt:.2f} p={pp:.6f} dz={d.mean()/(d.std()+1e-12):.2f}")
