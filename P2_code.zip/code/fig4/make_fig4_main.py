"""Fig 4 main figure (spiking instantiation, 4 panels) plotting script.
Panels: a = reversal learning curves; b = DAN channel expectiles;
              c = frozen utility readouts; d = spiking memory retention (expectile L1).
Data:
  a/b : snn_exp1_results.npy (8 seeds; curves are 8-seed means, 15-trial moving average)
  c/d : snn_exp6_revaluation.npy (20 seeds; error bars = std(ddof=1)/sqrt(20))
Output: fig4_spiking.png
"""
import os
import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
CODE = os.path.dirname(os.path.abspath(__file__))   # adjust to the actual path if needed
sys.path.insert(0, CODE)
from p2_snn_exp1 import true_expectiles  # noqa: E402
from p2_model import TAUS7  # noqa: E402
res1 = np.load(os.path.join(CODE, "snn_exp1_results.npy"), allow_pickle=True).item()
res6 = np.load(os.path.join(CODE, "snn_exp6_revaluation.npy"), allow_pickle=True).item()
TAUS7 = tuple(TAUS7)
N1, N2, N3 = 250, 250, 20
TEST_UTILS = ['risk_averse', 'risk_seeking', 'lower_tail']


colors = {"scalar": "#888888", "dist": "#2176AE", "comp": "#E8A33D",
          "joint": "#C0392B", "oracle": "#2B2B2B", "randgate": "#7A5195"}
labels = {"scalar": "Scalar RPE", "dist": "Distributional only",
          "comp": "Compartment only", "joint": "Joint (full)",
          "oracle": "Oracle-gate", "randgate": "Rand-gate"}
V1 = ["scalar", "dist", "comp", "joint"]


def smooth(x, k=15):
    h = k // 2
    xp = np.concatenate([np.full(h, x[0]), x, np.full(h, x[-1])])
    return np.convolve(xp, np.ones(k) / k, "valid")


fig = plt.figure(figsize=(13.6, 3.5), dpi=150)
gs = fig.add_gridspec(1, 4, wspace=0.38, width_ratios=[1.35, 1, 1, 1])

# ---------- a: reversal learning curves ----------
ax = fig.add_subplot(gs[0, 0])
T = N1 + N2 + N3
for v in V1:
    m = np.stack([r["curve"] for r in res1[v]]).mean(0)
    ax.plot(np.arange(T), smooth(m), color=colors[v], lw=1.8, label=labels[v])
for x in (N1, N1 + N2):
    ax.axvline(x, color="k", ls=":", lw=0.8)
ax.text(N1 / 2, 1.24, "Ctx A", ha="center", fontsize=8.5)
ax.text(N1 + N2 / 2, 1.24, "Ctx B (reversed)", ha="center", fontsize=8.5)
ax.text(N1 + N2 + N3 / 2, 1.24, "Probe\nA", ha="center", fontsize=8)
ax.set_ylim(-0.02, 1.32)
ax.set_xlabel("Trial"); ax.set_ylabel("Accuracy")
ax.set_title("Spiking AC-SNN: reversal & retention", fontsize=10,
             loc="left", fontweight="bold")
ax.legend(fontsize=7.5, frameon=False, loc="lower left")
ax.spines[["top", "right"]].set_visible(False)

# ---------- b: DAN channel expectiles ----------
ax = fig.add_subplot(gs[0, 1])
taus = np.array(TAUS7)
ax.plot(taus, true_expectiles(0.8), "o--", color="0.25", ms=4, lw=1,
        label="True: arm0 (p=.8)")
ax.plot(taus, true_expectiles(0.2), "s--", color="0.55", ms=4, lw=1,
        label="True: arm1 (p=.2)")
cj0 = np.mean([r["ch"][0] for r in res1["joint"]], axis=0)
cj1 = np.mean([r["ch"][1] for r in res1["joint"]], axis=0)
cd0 = np.mean([r["ch"][0] for r in res1["dist"]], axis=0)
ax.plot(taus, cj0, "o-", color=colors["joint"], ms=5, lw=1.6, mfc="none",
        label="Joint: arm0 (preserved)")
ax.plot(taus, cj1, "o-", color=colors["joint"], ms=5, lw=1.6, mfc="none",
        alpha=0.4, label="Joint: arm1 (undersampled)")
ax.plot(taus, cd0, "^-", color=colors["dist"], ms=5, lw=1.6, mfc="none",
        label="Dist-only: arm0 (overwritten)")
ax.set_xlabel(r"Expectile level $\tau$"); ax.set_ylabel("Channel value")
ax.set_title("DAN channel expectiles (spiking)", fontsize=10, loc="left",
             fontweight="bold")
ax.legend(fontsize=6.3, frameon=False, loc="upper left")
ax.set_ylim(-0.03, 1.03)
ax.spines[["top", "right"]].set_visible(False)

# ---------- c: frozen utility readouts ----------
ax = fig.add_subplot(gs[0, 2])
show = ["scalar", "dist", "comp", "joint", "oracle"]
util_labels = {"risk_averse": "Risk-averse", "risk_seeking": "Risk-seeking",
               "lower_tail": "Lower-tail"}
x = np.arange(len(TEST_UTILS)); w = 0.15
for i, v in enumerate(show):
    vals = np.array([[r["per_utility"][u] for r in res6[v]] for u in TEST_UTILS])
    ax.bar(x + (i - 2) * w, vals.mean(1), w * 0.9, color=colors[v],
           yerr=vals.std(1, ddof=1) / np.sqrt(vals.shape[1]), capsize=2,
           error_kw=dict(lw=0.8), label=labels[v])
ax.axhline(0.5, color="k", ls=":", lw=0.9)
ax.set_xticks(x)
ax.set_xticklabels([util_labels[u] for u in TEST_UTILS], fontsize=7.5,
                   rotation=18)
ax.set_ylim(0, 1.12); ax.set_ylabel("Accuracy")
ax.set_title("Frozen utility readouts", fontsize=10, loc="left",
             fontweight="bold")
ax.legend(fontsize=6.3, frameon=False, loc="upper center",
          bbox_to_anchor=(0.5, -0.15), ncol=5)
ax.spines[["top", "right"]].set_visible(False)

# ---------- d: spiking memory retention (L1) ----------
ax = fig.add_subplot(gs[0, 3])
shown = ["dist", "randgate", "joint", "oracle"]
vals = [np.array([r["dist_l1"] for r in res6[v]]) for v in shown]
ax.bar(np.arange(len(shown)), [v.mean() for v in vals], 0.62,
       color=[colors[v] for v in shown],
       yerr=[v.std(ddof=1) / np.sqrt(len(v)) for v in vals],
       capsize=3, error_kw=dict(lw=1))
ax.set_xticks(np.arange(len(shown)))
ax.set_xticklabels([labels[v] for v in shown], rotation=20, ha="right",
                   fontsize=8)
ax.set_ylabel("Expectile L1 error")
ax.set_ylim(0, 0.105)
pur = np.mean([r["purity"] for r in res6["joint"]])
ax.text(0.03, 0.92, f"Joint purity = {pur:.2f}", transform=ax.transAxes,
        fontsize=8.5)
ax.set_title("Spiking memory retention", fontsize=10, loc="left",
             fontweight="bold")
ax.spines[["top", "right"]].set_visible(False)

for axx, L in zip(fig.axes, "abcd"):
    axx.text(-0.16, 1.06, L, transform=axx.transAxes, fontsize=15,
             fontweight="bold", va="bottom", ha="right")
fig.text(0.5, -0.085,
         "a/b: mean of n = 8 seeds (curves: 15-trial moving average);"
         "   c/d: mean ± SEM, n = 20 seeds",
         fontsize=8, color="#444", ha="center", va="top")
out = os.path.join(HERE, "fig4_spiking.png")
fig.savefig(out, bbox_inches="tight")
print("saved:", os.path.abspath(out))
