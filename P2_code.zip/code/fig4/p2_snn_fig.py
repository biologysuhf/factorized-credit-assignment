"""P2 Phase-3 figure: spiking (AC-SNN substrate) reproduction of Exp1."""
import numpy as np
import matplotlib.pyplot as plt
import os
from p2_snn_exp1 import N1, N2, N3, true_expectiles
from p2_model import TAUS7

HERE = os.path.dirname(os.path.abspath(__file__))
res = np.load(os.path.join(HERE, 'snn_exp1_results.npy'), allow_pickle=True).item()
variants = ['scalar', 'dist', 'comp', 'joint']
labels = {'scalar': 'Scalar RPE', 'dist': 'Distributional only',
          'comp': 'Compartment only', 'joint': 'Joint (full)'}
colors = {'scalar': '#888888', 'dist': '#2176ae', 'comp': '#e8a33d',
          'joint': '#c0392b'}

fig, axes = plt.subplots(1, 4, figsize=(13.2, 3.2))

# (a) learning curves
ax = axes[0]
T = N1 + N2 + N3
for v in variants:
    curves = np.stack([r['curve'] for r in res[v]])
    m0 = curves.mean(0); k = 15; h = k // 2
    mp = np.concatenate([np.full(h, m0[0]), m0, np.full(h, m0[-1])])
    ms = np.convolve(mp, np.ones(k) / k, 'valid')
    ax.plot(np.arange(T), ms, color=colors[v], lw=1.8, label=labels[v])
ax.axvline(N1, color='k', ls=':', lw=0.8)
ax.axvline(N1 + N2, color='k', ls=':', lw=0.8)
ax.text(N1 / 2, 1.10, 'Ctx A', ha='center', fontsize=9)
ax.text(N1 + N2 / 2, 1.10, 'Ctx B (reversed)', ha='center', fontsize=9)
ax.text(N1 + N2 + N3 / 2, 1.10, 'Probe\nA', ha='center', fontsize=8)
ax.set_ylim(-0.02, 1.3)
ax.set_xlabel('Trial'); ax.set_ylabel('Accuracy')
ax.set_title('a  Spiking AC-SNN: reversal & retention', loc='left',
             fontsize=10, fontweight='bold')
ax.legend(fontsize=7, frameon=False, loc='center left')

# (b) retention bars
ax = axes[1]
xs = np.arange(4)
ret = [[r['retention'] for r in res[v]] for v in variants]
ax.bar(xs, [np.mean(x) for x in ret],
       color=[colors[v] for v in variants], width=0.62)
ax.errorbar(xs, [np.mean(x) for x in ret],
            yerr=[np.std(x) / np.sqrt(len(x)) for x in ret], fmt='k.', capsize=3)
ax.axhline(0.5, color='k', ls=':', lw=0.8)
ax.set_xticks(xs)
ax.set_xticklabels(['Scalar', 'Dist', 'Comp', 'Joint'], fontsize=8)
ax.set_ylim(0, 1.05); ax.set_ylabel('Probe accuracy (return to A)')
ax.set_title('b  Memory retention after reversal', loc='left', fontsize=10,
             fontweight='bold')

# (c) channel distributions after phase 1 (learned in spikes)
ax = axes[2]
taus = np.array(TAUS7)
ax.plot(taus, true_expectiles(0.8), 'o--', color='0.25', ms=4, lw=1,
        label='True: arm0 (p=.8)')
ax.plot(taus, true_expectiles(0.2), 's--', color='0.55', ms=4, lw=1,
        label='True: arm1 (p=.2)')
cj0 = np.mean([r['ch'][0] for r in res['joint']], axis=0)
cj1 = np.mean([r['ch'][1] for r in res['joint']], axis=0)
cd0 = np.mean([r['ch'][0] for r in res['dist']], axis=0)
ax.plot(taus, cj0, 'o-', color=colors['joint'], ms=5, lw=1.6, mfc='none',
        label='Joint: arm0 (preserved)')
ax.plot(taus, cj1, 'o-', color=colors['joint'], ms=5, lw=1.6, mfc='none',
        alpha=0.4, label='Joint: arm1 (undersampled)')
ax.plot(taus, cd0, '^-', color=colors['dist'], ms=5, lw=1.6, mfc='none',
        label='Dist-only: arm0 (overwritten)')
ax.set_xlabel(r'Expectile level $\tau$'); ax.set_ylabel('Channel value')
ax.set_title('c  DAN channel expectiles (spiking)', loc='left', fontsize=10,
             fontweight='bold')
ax.legend(fontsize=6.5, frameon=False)

# (d) retention vs fidelity scatter
ax = axes[3]
for v in variants:
    rv = np.mean([r['retention'] for r in res[v]])
    if 'dist_L1' in res[v][0]:
        fid = 1 - np.mean([r['dist_L1'] for r in res[v]]) / 0.5
    else:
        fid = np.nan
    ax.scatter(fid if not np.isnan(fid) else 0.02, rv, s=140,
               color=colors[v], zorder=3, edgecolor='k', lw=0.7)
    ax.annotate(labels[v], (fid if not np.isnan(fid) else 0.02, rv),
                textcoords='offset points', xytext=(8, -4), fontsize=8)
ax.set_xlabel('Distributional fidelity (1 − norm. L1)')
ax.set_ylabel('Retention')
ax.set_xlim(-0.05, 1.1); ax.set_ylim(-0.05, 1.05)
ax.set_title('d  Spiking substrate keeps both', loc='left', fontsize=10,
             fontweight='bold')

for a in axes:
    a.spines[['top', 'right']].set_visible(False)
fig.tight_layout()
fig.savefig(os.path.join(HERE, 'snn_exp1_reversal.png'), dpi=220)
print('saved snn_exp1_reversal.png')
