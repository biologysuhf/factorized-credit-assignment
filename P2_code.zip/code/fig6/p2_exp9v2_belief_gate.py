"""
P2 Exp9-v2: latent-context inference without dedicated context cues.

Upgrade of Exp9 (EMA history gate, marginal GO).  The gate is now driven by
an explicit Bayesian belief state over compartments:

    b_t(c)  ∝  P(r_{t-1} | a_{t-1}, c) * sum_c' T(c|c') b_{t-1}(c')
    g_t     =  sharpen(b_t)

where the emission model P(r|a,c) is the reward histogram LEARNED by each
compartment itself (online EM-like bootstrap, no context labels anywhere).
Causal discipline: the gate at trial t uses only information up to t-1.

Task: 4 hidden contexts x 2 arms, Markov switching (dwell Exp(150)+50).
All arm distributions have mean 0.5 on the shared support {0,.25,.5,.75,1}
(epsilon-mixed toward uniform), so a single (a, r) observation is weakly
informative while ~25 trials of history identify the context.  Verified by
an analytic Bayes identifiability check (supplementary curve).

Pre-registered GO (fixed before formal n=20 run):
  * joint - max(dist, comp) >= 0.10, dz >= 0.8, p < 0.01
  * joint reval acc >= 0.75
  * Hungarian-aligned settled gate accuracy >= 0.80
  * causal gate swap: DeltaAcc <= -0.20 with stored distribution unchanged
Otherwise: stop, downgrade to Supplementary (per protocol).

Usage:  python3 p2_exp9v2_belief_gate.py dev      # n=5 parameter selection
        python3 p2_exp9v2_belief_gate.py formal   # frozen protocol, n=20
"""
import numpy as np
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from p2_model import FactorizedModel, TAUS7, make_states
from p2_exp6_revaluation import expectile

TAUS = np.array(TAUS7)
NCTX = 4
SUPPORT = np.array([0.0, 0.25, 0.5, 0.75, 1.0])
NBINS = len(SUPPORT)
EPS_MIX = 0.50                    # epsilon-mixture toward uniform on support
# (chosen so oracle-Bayes lag-1 acc < 0.45 but lag-25 acc > 0.85:
#  single rewards barely identify the context, ~25-trial history does)

# Base arm distributions (all mean 0.5), epsilon-mixed with uniform.
BASE = {
    'bern':    {0.0: 0.5, 1.0: 0.5},
    'moder':   {0.25: 0.5, 0.75: 0.5},
    'negskew': {0.0: 1/3, 0.75: 2/3},
    'posskew': {0.25: 2/3, 1.0: 1/3},
}
UNIF = np.ones(NBINS) / NBINS

def make_probs(d):
    p = np.zeros(NBINS)
    for v, pr in d.items():
        p[int(np.abs(SUPPORT - v).argmin())] += pr
    p = (1 - EPS_MIX) * p + EPS_MIX * UNIF
    return p / p.sum()

PROBS = {k: make_probs(v) for k, v in BASE.items()}
for k, p in PROBS.items():                      # sanity: means stay 0.5
    assert abs(p @ SUPPORT - 0.5) < 1e-9, k

# Contexts are arm-swapped pairs: single-step evidence is weak, and the
# optimal arm under a fixed utility flips across paired contexts.
CTX_ARMS = {0: ('bern', 'moder'), 1: ('moder', 'bern'),
            2: ('negskew', 'posskew'), 3: ('posskew', 'negskew')}

# ----------------------- true expectiles / utilities / optimal arms --------
_neutral = np.zeros(7); _neutral[3] = 1.0
UTILITIES = {
    'neutral': _neutral,
    'risk_averse': (1 - TAUS) ** 2 / ((1 - TAUS) ** 2).sum(),
    'risk_seeking': TAUS ** 2 / (TAUS ** 2).sum(),
    'lower_tail': (1 - TAUS) ** 10 / ((1 - TAUS) ** 10).sum(),
}
TEST_UTILS = ['risk_averse', 'risk_seeking', 'lower_tail']

def expectiles_of(probs):
    return np.array([expectile(SUPPORT, probs, t) for t in TAUS])

TRUE_EXP = np.zeros((NCTX, 2, 7))
for c in range(NCTX):
    for a in range(2):
        TRUE_EXP[c, a] = expectiles_of(PROBS[CTX_ARMS[c][a]])
TRUE_U = {u: TRUE_EXP @ w for u, w in UTILITIES.items()}
OPT = {u: TRUE_U[u].argmax(axis=1) for u in UTILITIES}

# ----------------------------- schedule: Markov switching ------------------
T = 20000
DWELL_EXP, DWELL_MIN = 150, 50

def gen_markov_ctx(rng, T=T):
    ctx = np.zeros(T, dtype=int)
    cur = int(rng.integers(0, NCTX))
    t = 0
    while t < T:
        L = int(rng.exponential(DWELL_EXP)) + DWELL_MIN
        ctx[t:t + L] = cur
        t += L
        nxt = int(rng.integers(1, NCTX))
        cur = (cur + nxt) % NCTX
    return ctx

def ctx_age(ctx):
    age = np.zeros(len(ctx), dtype=int)
    for t in range(len(ctx)):
        age[t] = 1 if t == 0 or ctx[t] != ctx[t - 1] else age[t - 1] + 1
    return age

# ------------------- analytic Bayes identifiability check ------------------
def identifiability_curve(rng, lags=range(1, 31), n_ep=400, dwell=60):
    """Posterior accuracy of the ORACLE Bayes filter (true emissions, true
    hazard) as a function of history length.  Task is valid if lag-1 is low
    and lag-25 is high."""
    h = 1.0 / (DWELL_EXP + DWELL_MIN)
    Tm = np.full((NCTX, NCTX), h / (NCTX - 1))
    np.fill_diagonal(Tm, 1 - h)
    acc = {L: [] for L in lags}
    for c in range(NCTX):
        for _ in range(n_ep // NCTX):
            b = np.ones(NCTX) / NCTX
            for L in range(0, max(lags) + 1):
                if L > 0:
                    a = int(rng.integers(0, 2))
                    r = float(rng.choice(SUPPORT, p=PROBS[CTX_ARMS[c][a]]))
                    bi = int(np.abs(SUPPORT - r).argmin())
                    lik = np.array([PROBS[CTX_ARMS[cc][a]][bi]
                                    for cc in range(NCTX)])
                    b = (Tm.T @ b) * lik
                    b /= b.sum()
                if L in acc:
                    acc[L].append(float(b.argmax() == c))
    return {L: float(np.mean(v)) for L, v in acc.items()}

# --------- windowed sufficient-statistic belief gate with commitment -------
class BeliefGate:
    """Latent-context inference from the sufficient statistics of recent
    experience.

    The gate input is the per-arm reward histogram over the last W trials
    (a sufficient statistic for the arm-conditional reward distributions).
    Each compartment owns a prototype in this statistic space; context
    belief = prototype matching.  Design principles:

      * COMMITMENT (stability): writes go to one compartment j* until
        another prototype beats it by `margin` (hysteresis);
      * NOVELTY-GATED ALLOCATION: if no prototype matches (sim < theta),
        the least-used compartment is allocated and its prototype is
        initialised from the current statistic, instead of overwriting an
        existing memory;
      * CAUSAL: the gate at trial t uses observations <= t-1 only;
      * no context labels anywhere -- prototypes are pure online clusters.

    (A recursive per-trial Bayesian EM filter was tried first and deadlocks
    in this task: single observations carry too little evidence, so
    emissions collapse to the global mixture.  Windowed sufficient
    statistics are the minimal fix.)
    """
    DIM = 2 * NBINS

    def __init__(self, C, seed, W=25, margin=0.03, theta=0.82,
                 lr_P=0.005, temp=20.0, debounce=8):
        self.C, self.W = C, W
        self.margin, self.theta, self.lr_P, self.temp = margin, theta, lr_P, temp
        self.debounce = debounce
        self.P = np.zeros((C, self.DIM))
        self.allocated = np.zeros(C, dtype=bool)
        self.usage = np.zeros(C)
        self.win_a, self.win_r = [], []
        self.jstar = -1                       # unassigned
        self.novel_count = 0
        self.b = np.ones(C) / C

    def _feat(self):
        h = np.zeros((2, NBINS))
        for a, bi in zip(self.win_a, self.win_r):
            h[a, bi] += 1
        f = h.flatten()
        n = np.linalg.norm(f)
        return f / n if n > 1e-9 else f

    def _sims(self, f):
        return np.array([float(f @ self.P[c]) if self.allocated[c]
                         else -np.inf for c in range(self.C)])

    def gate(self):
        g = np.zeros(self.C)
        if self.jstar >= 0:
            g[self.jstar] = 1.0
        return g

    def belief(self):
        return self.b

    def assign(self):
        """Choose the write compartment from the window statistic (<= t-1)."""
        if len(self.win_a) < 5:
            return
        f = self._feat()
        if not self.allocated.any():
            j = int(np.argmin(self.usage))
            self.P[j], self.allocated[j] = f.copy(), True
            self.jstar = j
            return
        sims = self._sims(f)
        best = int(sims.argmax())
        if sims[best] < self.theta:
            # candidate novelty: debounce so brief transitional windows
            # after a switch do not allocate spurious compartments
            self.novel_count += 1
            if self.novel_count >= self.debounce:
                free = np.where(~self.allocated)[0]
                j = int(free[0]) if len(free) else int(np.argmin(self.usage))
                self.P[j], self.allocated[j] = f.copy(), True
                self.jstar = j
                self.novel_count = 0
        else:
            self.novel_count = 0
            if self.jstar < 0 or sims[best] - sims[self.jstar] > self.margin:
                self.jstar = best
        z = self.temp * (sims - sims.max())
        z = np.where(np.isfinite(z), z, -30.0)
        b = np.exp(z - z.max())
        self.b = b / b.sum()

    def observe(self, a, r, learn=True):
        """Append the trial outcome to the window and (optionally) move the
        committed compartment's prototype toward the new statistic.
        The prototype moves SLOWLY and only while the statistic already
        matches it, so it cannot chase a transitional window across a
        context switch (that chase is what caused contamination)."""
        bi = int(np.abs(SUPPORT - r).argmin())
        self.win_a.append(a)
        self.win_r.append(bi)
        if len(self.win_a) > self.W:
            self.win_a.pop(0)
            self.win_r.pop(0)
        if self.jstar < 0:
            return
        self.usage[self.jstar] += 1
        if learn and len(self.win_a) >= 5:
            f = self._feat()
            j = self.jstar
            if float(f @ self.P[j]) >= self.theta:
                self.P[j] += self.lr_P * (f - self.P[j])
                n = np.linalg.norm(self.P[j])
                if n > 1e-9:
                    self.P[j] /= n

    def reset_belief(self):
        self.win_a, self.win_r = [], []
        self.jstar = -1
        self.b = np.ones(self.C) / self.C

# --------------------------------- EMA gate --------------------------------
CANON = SUPPORT
GATE_DIM = NBINS + 2

class HistoryTracker:
    def __init__(self, decay=0.90):
        self.decay = decay
        self.h = np.zeros(GATE_DIM)
    def update(self, a, r):
        x = np.zeros(GATE_DIM)
        x[int(np.abs(CANON - r).argmin())] = 1.0
        x[NBINS + a] = 1.0
        self.h = self.decay * self.h + (1 - self.decay) * x
    def obs(self):
        n = np.linalg.norm(self.h)
        return self.h / n if n > 1e-9 else self.h

# ---------------------------------- models ---------------------------------
def make_memory(variant, seed, lr_chan=0.1):
    C = 1 if variant in ('scalar', 'dist', 'beliefshared') else NCTX
    Q = 7 if variant in ('dist', 'joint', 'randgate', 'ema', 'oracle',
                         'beliefshared') else 1
    learn_gate = variant == 'ema'
    m = FactorizedModel(nfeat=16, Q=Q, C=C, seed=seed,
                        eta_c=np.linspace(0.35, 0.15, C), lr_chan=lr_chan,
                        learn_A=False, learn_gate=learn_gate, A_readout=False)
    if learn_gate:
        P0 = m.rng.normal(0, 1, (C, GATE_DIM))
        m.proto = P0 / np.linalg.norm(P0, axis=1, keepdims=True)
        m.proto_n = np.ones(C)
    return m

def model_values(m, arms, g, utility):
    w = UTILITIES[utility] if m.Q == 7 else np.ones(m.Q) / m.Q
    Vq = np.stack([m.U[j] @ arms[a] for a in range(2) for j in range(m.C)])
    Vq = Vq.reshape(2, m.C, m.Q)
    return Vq @ w @ g

# ----------------------------------- run -----------------------------------
def run(variant, seed, W=25, margin=0.05, theta=0.80, lr_P=0.005,
        debounce=12, T=T, collect_dynamics=False, collect_forgetting=False):
    rng = np.random.default_rng(51000 + seed)
    m = make_memory(variant, seed)
    arms = make_states(2, 16, seed=5)
    ctx = gen_markov_ctx(rng, T)
    age = ctx_age(ctx)
    # belief machinery: compartmented variants + 'beliefshared' (shared
    # single memory that still receives the full belief state -- the key
    # fairness control: inference without selective plasticity routing)
    has_belief = variant in ('joint', 'beliefshared', 'comp')
    belief = BeliefGate(NCTX, seed, W=W, margin=margin, theta=theta,
                        lr_P=lr_P, debounce=debounce) if has_belief else None
    hist = HistoryTracker() if variant == 'ema' else None

    gate_rec = np.zeros((T, NCTX if variant == 'beliefshared' else m.C))
    snapshots = []                       # (ctx, epoch gate mean, L1 dict)
    ep_start = 0
    # epoch boundaries for the overlap-vs-forgetting analysis
    boundaries = [0] + [t for t in range(1, T) if ctx[t] != ctx[t - 1]] + [T]
    snap_l1 = {}                      # epoch end -> per-context expectile L1

    def current_l1():
        if m.Q != 7:
            return None
        out = {}
        for c in range(NCTX):
            # best-matching compartment by L1 (alignment-free snapshot)
            l1s = []
            for j in range(m.C):
                pred = np.stack([m.U[j] @ arms[a] for a in range(2)])
                l1s.append(float(np.abs(pred - TRUE_EXP[c]).mean()))
            out[c] = min(l1s)
        return out

    def aligned_l1(gate_seq, ctx_seq):
        """Per-context L1 via the variant's OWN routing: each context is
        read from the compartment it was most assigned to (Hungarian on the
        gate sequence so far), so contamination shows up as error."""
        if m.Q != 7 or gate_seq.shape[1] < 2:
            return None
        from scipy.optimize import linear_sum_assignment
        assign = gate_seq.argmax(1)
        conf = np.zeros((NCTX, gate_seq.shape[1]))
        for cc in range(NCTX):
            for j in range(gate_seq.shape[1]):
                conf[cc, j] = ((ctx_seq == cc) & (assign == j)).sum()
        ri, ci = linear_sum_assignment(-conf)
        amap = dict(zip(ri, ci))               # ctx -> compartment
        out = {}
        for c in range(NCTX):
            j = amap.get(c, 0)
            pred = np.stack([m.U[j] @ arms[a] for a in range(2)])
            out[c] = float(np.abs(pred - TRUE_EXP[c]).mean())
        return out

    for t in range(T):
        c = ctx[t]
        if variant == 'oracle':
            g = np.eye(m.C)[c]
        elif variant == 'randgate':
            g = np.eye(m.C)[int(rng.integers(0, m.C))]
        elif variant == 'ema':
            g = m.gate(hist.obs())
        elif belief is not None:
            belief.assign()               # causal: uses trials <= t-1
            if variant == 'beliefshared':
                g = np.ones(1)            # belief available, write shared
            else:
                g = belief.gate()
        else:
            g = np.ones(1)
        a = int(rng.integers(0, 2))
        bi_dist = PROBS[CTX_ARMS[c][a]]
        r = float(rng.choice(SUPPORT, p=bi_dist))
        o = hist.obs() if hist is not None else None
        m.learn(arms[a], r, context=c, g_pre=g, obs=o)
        if belief is not None:
            belief.observe(a, r, learn=True)
        if hist is not None:
            hist.update(a, r)
        gate_rec[t] = belief.b.copy() if variant == 'beliefshared' else g
        if collect_forgetting and (t == T - 1 or ctx[t + 1] != c) \
                and t + 1 - ep_start >= 30:
            snapshots.append((int(c),
                              gate_rec[ep_start:t + 1].mean(axis=0).copy(),
                              aligned_l1(gate_rec[:t + 1], ctx[:t + 1])))
            ep_start = t + 1

    # epoch snapshots for forgetting analysis (joint only)
    pair_data = None
    if variant == 'joint':
        # recompute per-epoch gate means
        ep_ctx, ep_gate = [], []
        for i in range(len(boundaries) - 1):
            s, e = boundaries[i], boundaries[i + 1]
            if e - s >= 30:
                ep_ctx.append(int(ctx[s + 1]))
                ep_gate.append(gate_rec[s:e].mean(axis=0))
        pair_data = (ep_ctx, ep_gate)

    # ---------------- frozen zero-update revaluation ----------------
    NPROBE, SETTLE_PROBE = 3, 60
    per_utility, choices = {}, {}
    for u in TEST_UTILS:
        co, ch = [], np.zeros(NCTX, dtype=int)
        for c in range(NCTX):
            votes = np.zeros(2)
            for _ in range(NPROBE):
                if belief is not None:
                    belief.reset_belief()
                if hist is not None:
                    hist.h = np.zeros(GATE_DIM)
                for _ in range(SETTLE_PROBE):
                    a = int(rng.integers(0, 2))
                    r = float(rng.choice(SUPPORT,
                                         p=PROBS[CTX_ARMS[c][a]]))
                    if belief is not None:
                        belief.assign()
                        belief.observe(a, r, learn=False)
                    if hist is not None:
                        hist.update(a, r)
                if belief is not None:
                    belief.assign()
                if variant == 'oracle':
                    g = np.eye(m.C)[c]
                elif variant == 'randgate':
                    g = np.eye(m.C)[int(rng.integers(0, m.C))]
                elif variant == 'ema':
                    g = m.gate(hist.obs())
                elif variant == 'beliefshared':
                    g = np.ones(1)        # belief known, readout shared
                elif belief is not None:
                    g = belief.gate()
                else:
                    g = np.ones(1)
                vals = model_values(m, arms, g, u)
                votes[int(vals[1] > vals[0])] += 1
            ch[c] = int(votes[1] > votes[0])
            co.append(float(np.isclose(TRUE_U[u][c, ch[c]],
                                       TRUE_U[u][c].max())))
        choices[u] = ch
        per_utility[u] = float(np.mean(co))
    acc = float(np.mean([per_utility[u] for u in TEST_UTILS]))

    # ------------- settled gate accuracy (Hungarian) + NMI --------------
    gate_acc = nmi = np.nan
    SETTLED = 15
    if gate_rec.shape[1] > 1 and variant != 'randgate':
        mask = age >= SETTLED
        assign = gate_rec[mask].argmax(1)
        true = ctx[mask]
        conf = np.zeros((NCTX, m.C))
        for cc in range(NCTX):
            for j in range(m.C):
                conf[cc, j] = ((true == cc) & (assign == j)).sum()
        from scipy.optimize import linear_sum_assignment
        ri, ci = linear_sum_assignment(-conf)
        gate_acc = float(conf[ri, ci].sum() / conf.sum())
        nmi = float(_nmi(true, assign))

    # ----------------- causal gate swap (compartmented only) ------------
    swap_delta = np.nan
    if variant == 'joint':
        perm = np.array([1, 0, 3, 2])          # derangement
        co_swap = []
        for u in TEST_UTILS:
            for c in range(NCTX):
                for _ in range(NPROBE):
                    belief.reset_belief()
                    for _ in range(SETTLE_PROBE):
                        a = int(rng.integers(0, 2))
                        r = float(rng.choice(SUPPORT,
                                             p=PROBS[CTX_ARMS[c][a]]))
                        belief.assign()
                        belief.observe(a, r, learn=False)
                    belief.assign()
                    g = belief.gate()[perm]
                    vals = model_values(m, arms, g, u)
                    aa = int(vals[1] > vals[0])
                    co_swap.append(float(np.isclose(
                        TRUE_U[u][c, aa], TRUE_U[u][c].max())))
        swap_delta = float(np.mean(co_swap)) - acc

    # ------------- switch-aligned dynamics (frozen replay) --------------
    dyn = None
    if collect_dynamics and variant == 'joint':
        LAG = 60
        belief.reset_belief()
        ctx2 = gen_markov_ctx(rng, 6000)
        age2 = ctx_age(ctx2)
        recs = {k: [[] for _ in range(LAG)]
                for k in ('belief_acc', 'entropy', 'choice_acc')}
        # alignment map from training
        mask = age >= SETTLED
        assign = gate_rec[mask].argmax(1)
        conf = np.zeros((NCTX, m.C))
        for cc in range(NCTX):
            for j in range(m.C):
                conf[cc, j] = ((ctx[mask] == cc) & (assign == j)).sum()
        from scipy.optimize import linear_sum_assignment
        ri, ci = linear_sum_assignment(-conf)
        align = dict(zip(ci, ri))              # compartment -> true ctx
        for t in range(len(ctx2)):
            c = ctx2[t]
            belief.assign()
            g = belief.gate()
            if t > 0:
                bg = belief.b.argmax()
                recs['belief_acc'][min(age2[t], LAG) - 1].append(
                    float(align.get(bg, -1) == c))
                recs['entropy'][min(age2[t], LAG) - 1].append(
                    float(-(belief.b * np.log(belief.b + 1e-12)).sum()))
                vals = model_values(m, arms, g, 'risk_averse')
                aa = int(vals[1] > vals[0])
                recs['choice_acc'][min(age2[t], LAG) - 1].append(
                    float(np.isclose(TRUE_U['risk_averse'][c, aa],
                                     TRUE_U['risk_averse'][c].max())))
            a = int(rng.integers(0, 2))
            r = float(rng.choice(SUPPORT, p=PROBS[CTX_ARMS[c][a]]))
            belief.observe(a, r, learn=False)
        dyn = {k: np.array([np.mean(v) if v else np.nan for v in vv])
               for k, vv in recs.items()}

    return dict(variant=variant, seed=seed, reval_acc=acc,
                per_utility=per_utility, choices=choices,
                gate_acc=gate_acc, nmi=nmi, swap_delta=swap_delta,
                dynamics=dyn, pair_data=pair_data, snapshots=snapshots,
                l1_final=current_l1())


def _nmi(x, y):
    """Normalized mutual information (arithmetic mean normalization)."""
    x, y = np.asarray(x), np.asarray(y)
    kx, ky = x.max() + 1, y.max() + 1
    n = len(x)
    joint = np.zeros((kx, ky))
    for i in range(kx):
        for j in range(ky):
            joint[i, j] = ((x == i) & (y == j)).sum()
    p = joint / n
    px, py = p.sum(1), p.sum(0)
    mi = 0.0
    for i in range(kx):
        for j in range(ky):
            if p[i, j] > 0:
                mi += p[i, j] * np.log(p[i, j] / (px[i] * py[j] + 1e-12) + 1e-12)
    hx = -(px[px > 0] * np.log(px[px > 0])).sum()
    hy = -(py[py > 0] * np.log(py[py > 0])).sum()
    return 2 * mi / (hx + hy + 1e-12)


def summarize(res, tag=''):
    variants = list(res)
    print(f'\nSummary {tag}:')
    print(f"{'variant':9s} {'reval':>7s} {'gate_acc':>9s} {'nmi':>6s} "
          f"{'swap_d':>8s}")
    for v in variants:
        acc = np.array([r['reval_acc'] for r in res[v]])
        ga = np.array([r['gate_acc'] for r in res[v]])
        nm = np.array([r['nmi'] for r in res[v]])
        sd = np.array([r['swap_delta'] for r in res[v]])
        print(f"{v:9s} {acc.mean():7.3f} {np.nanmean(ga):9.3f} "
              f"{np.nanmean(nm):6.3f} {np.nanmean(sd):+8.3f}")
    if 'joint' in res:
        from scipy import stats
        j = np.array([r['reval_acc'] for r in res['joint']])
        cands = [np.array([r['reval_acc'] for r in res[v]])
                 for v in ('scalar', 'dist', 'comp') if v in res]
        if cands:
            best = np.maximum.reduce(cands)
            d = j - best
            tt, pp = stats.ttest_1samp(d, 0)
            dz = d.mean() / (d.std() + 1e-12)
            print(f"\nsynergy joint-max(scalar,dist,comp): {d.mean():+.4f} "
                  f"t={tt:.2f} p={pp:.3e} dz={dz:.2f}")
            return dict(delta=float(d.mean()), t=float(tt), p=float(pp),
                        dz=float(dz))
    return None


if __name__ == '__main__':
    mode = sys.argv[1] if len(sys.argv) > 1 else 'dev'
    HERE = os.path.dirname(os.path.abspath(__file__))

    # 0. task sanity -----------------------------------------------------
    print('Utility-optimal arms per context:')
    for u in TEST_UTILS:
        print(f'  {u:12s}: {OPT[u].tolist()}  (true U: '
              + '; '.join(f"c{c}={TRUE_U[u][c].round(3).tolist()}"
                          for c in range(NCTX)) + ')')
    rng = np.random.default_rng(0)
    ident = identifiability_curve(rng)
    print('\nBayes identifiability (oracle filter, true emissions):')
    for L in (1, 2, 5, 10, 15, 20, 25, 30):
        print(f'  lag {L:2d}: {ident[L]:.3f}')

    if mode == 'dev':
        # 1. dev grid on n=5, selection by joint reval acc + gate acc ----
        print('\n--- DEV grid (n=5) ---')
        best = None
        for theta in (0.78, 0.80):
            for debounce in (8, 12):
                for lr_P in (0.003, 0.005):
                    rs = [run('joint', s, theta=theta, debounce=debounce,
                              lr_P=lr_P) for s in range(5)]
                    m_acc = float(np.mean([r['reval_acc'] for r in rs]))
                    m_ga = float(np.mean([r['gate_acc'] for r in rs]))
                    print(f'theta={theta} debounce={debounce} lr_P={lr_P}: '
                          f'joint acc {m_acc:.3f} gate {m_ga:.3f}',
                          flush=True)
                    key = m_acc + m_ga
                    if best is None or key > best[0]:
                        best = (key, theta, debounce, lr_P)
        print(f'\nDEV winner: theta={best[1]} debounce={best[2]} '
              f'lr_P={best[3]}')
        np.save(os.path.join(HERE, 'exp9v2_dev.npy'),
                dict(winner=best, ident=ident), allow_pickle=True)
    else:
        # 2. frozen protocol, formal n=20 --------------------------------
        THETA, DEBOUNCE, LR_P = 0.80, 12, 0.005  # frozen after dev
        variants = ['scalar', 'dist', 'comp', 'randgate', 'ema', 'joint',
                    'oracle']
        res = {v: [] for v in variants}
        for v in variants:
            for s in range(20):
                res[v].append(run(v, 100 + s, theta=THETA,
                                  debounce=DEBOUNCE, lr_P=LR_P,
                                  collect_dynamics=True))
                print(f'  done {v} seed {s}', flush=True)
        np.save(os.path.join(HERE, 'exp9v2_belief_gate.npy'),
                dict(res=res, ident=ident,
                     params=dict(theta=THETA, debounce=DEBOUNCE,
                                 lr_P=LR_P)), allow_pickle=True)
        out = summarize(res, tag='(formal n=20)')
        ga = np.nanmean([r['gate_acc'] for r in res['joint']])
        sd = np.nanmean([r['swap_delta'] for r in res['joint']])
        ja = np.mean([r['reval_acc'] for r in res['joint']])
        go = (out and out['delta'] >= 0.10 and out['dz'] >= 0.8
              and out['p'] < 0.01 and ja >= 0.75 and ga >= 0.80
              and sd <= -0.20)
        print(f"\njoint acc {ja:.3f} | settled gate acc {ga:.3f} | "
              f"swap delta {sd:+.3f}")
        print(f"PRE-REGISTERED GO/NO-GO: {'GO' if go else 'NO-GO'}")
