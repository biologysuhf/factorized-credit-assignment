# -*- coding: utf-8 -*-
"""Figure 7 (v1): causal validation — latent inference -> routing -> memory.
Panels: a history-inference learning curve | b zero-update revaluation bars
        d causal gate swap | e inference-alone control | g overlap->forgetting.
Data: P2 Exp9v2 (exp9v2_belief_gate.npy / exp9v2_closing.npy /
      exp9v2_overlap_forgetting.npy), n = 20 seeds/variant.
Dropped vs old Fig7: c (switch-aligned dynamics, -> SI), f (one-factor robustness, -> SI).
"""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec

plt.rcParams.update({"font.family": "Liberation Sans", "font.size": 9.5,
                     "axes.spines.top": False, "axes.spines.right": False,
                     "pdf.fonttype": 42, "ps.fonttype": 42})

HERE = os.path.dirname(os.path.abspath(__file__))
bg = np.load(os.path.join(HERE, "exp9v2_belief_gate.npy"), allow_pickle=True).item()
cl = np.load(os.path.join(HERE, "exp9v2_closing.npy"), allow_pickle=True).item()
of = np.load(os.path.join(HERE, "exp9v2_overlap_forgetting.npy"),
             allow_pickle=True).item()
res, ident = bg["res"], bg["ident"]

JOINT = "#C0392B"; ORACLE = "#333333"; DIST = "#2176AE"; COMP = "#E8A33D"
GRAY = "#8C8C8C"; LBLUE = "#B7C9E2"; EMA = "#D9D84A"; SWAP = "#A04A2C"

fig = plt.figure(figsize=(13.6, 6.0), dpi=300)
gs = GridSpec(2, 3, figure=fig, height_ratios=[1, 1],
              left=0.055, right=0.99, top=0.86, bottom=0.10,
              hspace=0.55, wspace=0.34)


def tag(ax, s):
    ax.text(-0.14, 1.06, s, transform=ax.transAxes, fontsize=13,
            fontweight="bold", va="bottom")


# ---------- a | history-inference learning curve ----------
ax = fig.add_subplot(gs[0, 0]); tag(ax, "a")
lags = sorted(ident)
ax.plot(lags, [ident[L] for L in lags], "o-", ms=3, lw=1.6, color=DIST)
for y in (0.45, 0.85):
    ax.axhline(y, ls=":", c="gray", lw=1)
ax.axhline(0.25, ls="--", c=JOINT, lw=1)
ax.text(lags[-1], 0.27, "chance", ha="right", fontsize=7.5, color=JOINT)
ax.set_xlabel("history length (trials)")
ax.set_ylabel("oracle-Bayes context acc.")
ax.set_ylim(0.2, 1.02)
ax.set_title("task requires history inference", fontsize=10.5, fontweight="bold")

# ---------- b | zero-update revaluation ----------
ax = fig.add_subplot(gs[0, 1]); tag(ax, "b")
variants = ["scalar", "dist", "comp", "randgate", "ema", "joint", "oracle"]
lab = ["scalar", "dist\nonly", "comp\nonly", "rand\ngate", "EMA\ngate",
       "joint\n(belief)", "oracle"]
col = [GRAY, LBLUE, "#E2C4B7", "#CCCCCC", EMA, JOINT, ORACLE]
means, sems = [], []
for v in variants:
    ys = [r["reval_acc"] for r in res[v]]
    means.append(np.mean(ys)); sems.append(np.std(ys) / np.sqrt(len(ys)))
ax.bar(range(7), means, yerr=sems, color=col, capsize=2.5,
       edgecolor="k", linewidth=0.4)
ax.axhline(0.5, ls="--", c=JOINT, lw=1)
ax.set_xticks(range(7)); ax.set_xticklabels(lab, fontsize=7)
ax.set_ylabel("zero-update revaluation acc.")
ax.set_ylim(0.4, 0.95)
ax.set_title("latent inference $\\rightarrow$ routing $\\rightarrow$ memory",
             fontsize=10.5, fontweight="bold")

# ---------- d | causal gate swap ----------
ax = fig.add_subplot(gs[0, 2]); tag(ax, "d")
sd = np.array([r["swap_delta"] for r in res["joint"]])
acc_j = np.array([r["reval_acc"] for r in res["joint"]])
ax.bar([0, 1], [acc_j.mean(), acc_j.mean() + sd.mean()],
       yerr=[acc_j.std() / np.sqrt(len(acc_j)), sd.std() / np.sqrt(len(sd))],
       color=[JOINT, SWAP], capsize=3, edgecolor="k", linewidth=0.4, width=0.55)
ax.axhline(0.5, ls="--", c=GRAY, lw=1)
ax.set_xticks([0, 1]); ax.set_xticklabels(["correct\ngate", "swapped\ngate"],
                                          fontsize=9)
ax.set_ylabel("revaluation acc.")
ax.set_ylim(0.3, 0.9)
ax.set_title("causal: gate swap, memory intact", fontsize=10.5,
             fontweight="bold")

# ---------- e | inference alone is not sufficient ----------
ax = fig.add_subplot(gs[1, 0]); tag(ax, "e")
j = acc_j
bs = np.array([r["reval_acc"] for r in cl["beliefshared"]])
bs_gate = np.nanmean([r["gate_acc"] for r in cl["beliefshared"]])
ax.bar([0, 1], [bs.mean(), j.mean()],
       yerr=[bs.std() / np.sqrt(len(bs)), j.std() / np.sqrt(len(j))],
       color=[LBLUE, JOINT], capsize=3, edgecolor="k", linewidth=0.4,
       width=0.55)
ax.axhline(0.5, ls="--", c=JOINT, lw=1)
ax.set_xticks([0, 1])
ax.set_xticklabels(["belief +\nshared memory", "belief +\nrouted memory"],
                   fontsize=9)
ax.set_ylabel("zero-update revaluation acc.")
ax.set_ylim(0.4, 0.9)
ax.set_title(f"inference alone is not sufficient\n"
             f"(belief acc. {bs_gate:.2f}, memory shared)", fontsize=10,
             fontweight="bold")

# ---------- g | overlap controls forgetting ----------
ax = fig.add_subplot(gs[1, 1:]); tag(ax, "g")
rng = np.random.default_rng(0)
# each variant has its own colour family: cloud and mean share the hue; legend has 4 entries
styles = [("randgate", "#999999", "s", "rand-gate"),
          ("ema", "#D9B84A", "^", "EMA gate"),
          ("joint", JOINT, "o", "joint"),
          ("oracle", ORACLE, "D", "oracle")]
for v, c, mk, lab in styles:
    pr = np.asarray(of[v]["pairs"])
    sub = pr[rng.choice(len(pr), min(len(pr), 800), replace=False)]
    ax.scatter(sub[:, 0], sub[:, 1], s=4, alpha=0.20, color=c,
               edgecolors="none", zorder=2)
    ax.scatter(of[v]["mean_overlap"], of[v]["mean_forget"], s=95, color=c,
               marker=mk, edgecolor="k", zorder=5, label=lab)
rho, pv = of["joint_spearman"]
ax.text(0.03, 0.06, f"joint pairs: Spearman $\\rho$ = {rho:.2f}",
        transform=ax.transAxes, fontsize=8.5)
ax.set_xlabel("routing overlap $O_{ij}$")
ax.set_ylabel("forgetting $F_{ij}$ / final L1")
ax.legend(fontsize=8, frameon=False, loc="upper right")
ax.set_title("theory: overlap controls interference", fontsize=10.5,
             fontweight="bold")

fig.savefig(os.path.join(HERE, "fig6_causal_routing.png"), dpi=300,
            bbox_inches="tight", facecolor="white")
print("saved fig6_causal_routing.png")
