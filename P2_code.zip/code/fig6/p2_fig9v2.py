"""Figure for Exp9-v2: latent-context inference without dedicated cues."""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

HERE = os.path.dirname(os.path.abspath(__file__))
d = np.load(os.path.join(HERE, 'exp9v2_belief_gate.npy'),
            allow_pickle=True).item()
res, ident = d['res'], d['ident']

fig, axes = plt.subplots(1, 4, figsize=(16, 4))

# (a) Bayes identifiability of the task
ax = axes[0]
lags = sorted(ident)
ax.plot(lags, [ident[L] for L in lags], 'o-', ms=3, color='#2c5fa0')
ax.axhline(0.45, ls=':', c='gray', lw=1)
ax.axhline(0.85, ls=':', c='gray', lw=1)
ax.axhline(0.25, ls='--', c='r', lw=1)
ax.set_xlabel('history length (trials)')
ax.set_ylabel('oracle-Bayes context acc.')
ax.set_title('(a) task requires history inference')

# (b) zero-update revaluation
ax = axes[1]
variants = ['scalar', 'dist', 'comp', 'randgate', 'ema', 'joint', 'oracle']
labels = ['scalar', 'dist\nonly', 'comp\nonly', 'rand\ngate', 'EMA\ngate',
          'joint\n(belief)', 'oracle']
colors = ['#888888', '#b7c9e2', '#e2c4b7', '#cccccc', '#d9d9a0', '#2c5fa0',
          '#333333']
means = [np.mean([r['reval_acc'] for r in res[v]]) for v in variants]
sems = [np.std([r['reval_acc'] for r in res[v]]) / np.sqrt(len(res[v]))
        for v in variants]
ax.bar(range(len(variants)), means, yerr=sems, color=colors, capsize=3,
       edgecolor='k', linewidth=0.5)
ax.axhline(0.5, ls='--', c='r', lw=1)
ax.set_xticks(range(len(variants)))
ax.set_xticklabels(labels, fontsize=8)
ax.set_ylabel('zero-update revaluation acc.')
ax.set_ylim(0.4, 0.95)
ax.set_title('(b) latent inference -> routing -> memory')

# (c) switch-aligned dynamics (joint)
ax = axes[2]
dyn_keys = ['belief_acc', 'entropy', 'choice_acc']
sty = {'belief_acc': ('#2c5fa0', 'belief acc.'),
       'choice_acc': ('#2e7d43', 'choice acc.'),
       'entropy': ('#a04a2c', 'belief entropy')}
for k in dyn_keys:
    arr = np.array([r['dynamics'][k] for r in res['joint']
                    if r['dynamics'] is not None])
    m_, s_ = np.nanmean(arr, axis=0), np.nanstd(arr, axis=0) / np.sqrt(len(arr))
    x = np.arange(1, len(m_) + 1)
    c, lab = sty[k]
    if k == 'entropy':
        ax.plot(x, m_ / np.log(4), color=c, label='entropy (norm.)')
    else:
        ax.plot(x, m_, color=c, label=lab)
ax.set_xlabel('trials since context switch')
ax.set_title('(c) switch-aligned dynamics (joint)')
ax.legend(fontsize=8, frameon=False)
ax.set_ylim(0, 1.05)

# (d) causal gate swap
ax = axes[3]
sd = np.array([r['swap_delta'] for r in res['joint']])
acc_j = np.array([r['reval_acc'] for r in res['joint']])
ax.bar([0, 1], [acc_j.mean(), acc_j.mean() + sd.mean()],
       yerr=[acc_j.std() / np.sqrt(len(acc_j)),
             sd.std() / np.sqrt(len(sd))],
       color=['#2c5fa0', '#a04a2c'], capsize=4, edgecolor='k', linewidth=0.5)
ax.set_xticks([0, 1])
ax.set_xticklabels(['correct\ngate', 'swapped\ngate'], fontsize=9)
ax.set_ylabel('revaluation acc.')
ax.set_title('(d) causal: gate swap, memory intact')
ax.set_ylim(0.3, 0.9)

fig.tight_layout()
fig.savefig(os.path.join(HERE, 'exp9v2_belief_gate.png'), dpi=200)
print('saved exp9v2_belief_gate.png')
