"""
P2 Exp9-v2 closing package (final, then experiments are frozen):

  A. belief-shared fairness control (n=20, formal seeds): the full
     evidence-based inference machinery runs, but plasticity writes into a
     single shared distributional memory.  Tests: "inference alone is not
     sufficient; belief must be converted into selective plasticity routing."
  B. one-factor-at-a-time robustness sweep over the inference
     hyperparameters (W, debounce, lr_P), n=10 fresh seeds each.
  C. switch-count / dwell statistics of the formal streams.
  D. gate-overlap x forgetting theory validation:
     per-context-pair cumulative routing overlap vs measured memory
     degradation, plus variant-level means (random / EMA / belief / oracle)
     on the same axes.
"""
import numpy as np
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import p2_exp9v2_belief_gate as e

HERE = os.path.dirname(os.path.abspath(__file__))
PARAMS = dict(W=25, margin=0.05, theta=0.80, lr_P=0.005, debounce=12)
FORMAL_SEEDS = range(100, 120)

# ------------------- A. belief-shared fairness control (n=20) --------------
def part_A():
    print('--- A. belief-shared control (n=20) ---')
    res = [e.run('beliefshared', s, **PARAMS) for s in FORMAL_SEEDS]
    acc = np.array([r['reval_acc'] for r in res])
    ga = np.array([r['gate_acc'] for r in res])
    print(f'beliefshared: reval {acc.mean():.3f}±{acc.std():.3f} '
          f'(inference gate acc {np.nanmean(ga):.3f})')
    # compare against formal joint / dist
    d = np.load(os.path.join(HERE, 'exp9v2_belief_gate.npy'),
                allow_pickle=True).item()
    j = np.array([r['reval_acc'] for r in d['res']['joint']])
    from scipy import stats
    dd = j - acc
    tt, pp = stats.ttest_1samp(dd, 0)
    print(f'joint - beliefshared: {dd.mean():+.3f} t={tt:.2f} p={pp:.2e} '
          f'dz={dd.mean()/(dd.std()+1e-12):.2f}')
    return res

# ---------------------- B. robustness sweep (n=10) -------------------------
def part_B():
    print('--- B. robustness sweep (n=10 per cell) ---')
    grid = [('W', 15), ('W', 35),
            ('debounce', 6), ('debounce', 18),
            ('lr_P', 0.0025), ('lr_P', 0.01)]
    out = {}
    seeds = range(300, 310)
    for knob, val in grid:
        p = dict(PARAMS); p[knob] = val
        accs = {}
        for v in ('joint', 'dist', 'comp'):
            accs[v] = np.array([e.run(v, s, **p)['reval_acc']
                                for s in seeds])
        delta = accs['joint'] - np.maximum(accs['dist'], accs['comp'])
        out[(knob, val)] = dict(joint=accs['joint'].mean(),
                                delta=delta.mean(),
                                dz=delta.mean() / (delta.std() + 1e-12))
        print(f'{knob}={val}: joint {accs["joint"].mean():.3f} '
              f'Δsynergy {delta.mean():+.3f} (dz {out[(knob,val)]["dz"]:.2f})',
              flush=True)
    return out

# ---------------------- C. switch statistics -------------------------------
def part_C():
    print('--- C. switch statistics (formal seeds) ---')
    nswitch, dwells = [], []
    for s in FORMAL_SEEDS:
        rng = np.random.default_rng(51000 + s)
        ctx = e.gen_markov_ctx(rng, e.T)
        sw = np.where(np.diff(ctx) != 0)[0]
        nswitch.append(len(sw))
        dwells.extend(np.diff(np.concatenate([[0], sw + 1])).tolist())
    print(f'transitions per seed: {np.mean(nswitch):.1f}±{np.std(nswitch):.1f} '
          f'(range {min(nswitch)}-{max(nswitch)})')
    print(f'dwell: median {np.median(dwells):.0f}, '
          f'mean {np.mean(dwells):.0f}')
    return dict(nswitch=nswitch, dwells=dwells)

# ---------------- D. overlap x forgetting theory validation -----------------
def pair_records(res):
    """Per (context i, epoch of context j) pairs: cumulative routing overlap
    O_ij = <g_i_epoch, g_j_epoch> and forgetting F_ij = L1_i(after j epoch)
    - L1_i(after i's own latest epoch)."""
    recs = []
    for r in res:
        snaps = r['snapshots']
        last_seen = {}                 # ctx -> (gate_mean, l1)
        for c, gm, l1 in snaps:
            if l1 is None:
                continue
            for ci, (gmi, l1i) in last_seen.items():
                if ci == c:
                    continue
                O = float(gm @ gmi)
                F = l1[ci] - l1i[ci]
                recs.append((O, F))
            last_seen[c] = (gm, l1)
    return np.array(recs) if recs else np.zeros((0, 2))

def part_D():
    print('--- D. overlap x forgetting ---')
    out = {}
    for v in ('randgate', 'ema', 'joint', 'oracle'):
        res = [e.run(v, s, collect_forgetting=True, **PARAMS)
               for s in FORMAL_SEEDS]
        pr = pair_records(res)
        # forgetting = aligned L1 at the FINAL snapshot (own routing readout)
        l1 = np.array([np.mean(list(r['snapshots'][-1][2].values()))
                       if r['snapshots'] and r['snapshots'][-1][2]
                       else np.nan for r in res])
        out[v] = dict(pairs=pr, l1_final=l1,
                      mean_overlap=float(pr[:, 0].mean()) if len(pr) else 0.0,
                      mean_forget=float(np.nanmean(l1)))
        print(f'{v:9s}: pairs={len(pr):4d} mean overlap '
              f'{out[v]["mean_overlap"]:.3f} mean final L1 '
              f'{out[v]["mean_forget"]:.3f}', flush=True)
    pr = out['joint']['pairs']
    if len(pr):
        from scipy import stats
        rho, pp = stats.spearmanr(pr[:, 0], pr[:, 1])
        print(f'joint per-pair Spearman(O, F): rho={rho:.3f} p={pp:.2e}')
        out['joint_spearman'] = (float(rho), float(pp))
    return out

if __name__ == '__main__':
    mode = sys.argv[1] if len(sys.argv) > 1 else 'all'
    if mode == 'D':
        D = part_D()
        np.save(os.path.join(HERE, 'exp9v2_overlap_forgetting.npy'), D,
                allow_pickle=True)
        print('saved exp9v2_overlap_forgetting.npy')
        sys.exit(0)
    A = part_A()
    C = part_C()
    B = part_B()
    D = part_D()
    np.save(os.path.join(HERE, 'exp9v2_closing.npy'),
            dict(beliefshared=[{k: v for k, v in r.items()
                                if k not in ('snapshots', 'dynamics')}
                               for r in A],
                 robustness=B, switch_stats=C, overlap_forgetting=D),
            allow_pickle=True)
    print('saved exp9v2_closing.npy')
