"""Figure for the Exp9-v2 closing package."""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import os

HERE = os.path.dirname(os.path.abspath(__file__))
d = np.load(os.path.join(HERE, 'exp9v2_closing.npy'), allow_pickle=True).item()
main = np.load(os.path.join(HERE, 'exp9v2_belief_gate.npy'),
               allow_pickle=True).item()

fig, axes = plt.subplots(1, 3, figsize=(14, 4))

# (a) belief-shared fairness control
ax = axes[0]
j = np.array([r['reval_acc'] for r in main['res']['joint']])
bs = np.array([r['reval_acc'] for r in d['beliefshared']])
bs_gate = np.nanmean([r['gate_acc'] for r in d['beliefshared']])
ax.bar([0, 1], [bs.mean(), j.mean()],
       yerr=[bs.std() / np.sqrt(len(bs)), j.std() / np.sqrt(len(j))],
       color=['#b7c9e2', '#2c5fa0'], capsize=4, edgecolor='k', linewidth=0.5)
ax.axhline(0.5, ls='--', c='r', lw=1)
ax.set_xticks([0, 1])
ax.set_xticklabels(['belief +\nshared memory', 'belief +\nrouted memory'],
                   fontsize=9)
ax.set_ylabel('zero-update revaluation acc.')
ax.set_ylim(0.4, 0.9)
ax.set_title(f'(a) inference alone is not sufficient\n'
             f'(belief acc. {bs_gate:.2f}, memory shared)', fontsize=10)

# (b) robustness sweep
ax = axes[1]
rob = d['robustness']
cells = [('W', 15), ('W', 25), ('W', 35),
         ('debounce', 6), ('debounce', 12), ('debounce', 18),
         ('lr_P', 0.0025), ('lr_P', 0.005), ('lr_P', 0.01)]
# formal point uses formal n=20 synergy
formal_delta = 0.2083
labels, vals = [], []
for k, v in cells:
    if (k, v) in rob:
        vals.append(rob[(k, v)]['delta'])
    else:                                    # default cells = formal run
        vals.append(formal_delta)
    lab = f"{k}={v}"
    labels.append(lab.replace('debounce', 'D').replace('lr_P', 'lr'))
cols = ['#888888' if (k, v) not in rob else '#2c5fa0' for k, v in cells]
ax.axhline(0, ls='--', c='r', lw=1)
ax.bar(range(len(cells)), vals, color=cols, edgecolor='k', linewidth=0.5)
ax.set_xticks(range(len(cells)))
ax.set_xticklabels(labels, fontsize=7, rotation=30)
ax.set_ylabel(r'$\Delta$ synergy (joint - best control)')
ax.set_title('(b) one-factor robustness (n=10/cell;\ngray = frozen default, n=20)',
             fontsize=10)

# (c) overlap x forgetting
ax = axes[2]
of = np.load(os.path.join(HERE, 'exp9v2_overlap_forgetting.npy'),
             allow_pickle=True).item()
pr = of['joint']['pairs']
sub = pr[np.random.default_rng(0).choice(len(pr), 800, replace=False)]
ax.scatter(sub[:, 0], sub[:, 1], s=4, alpha=0.25, color='#2c5fa0',
           label='joint pairs')
for v, c, mk in [('randgate', '#888888', 's'), ('ema', '#d9b84a', '^'),
                 ('joint', '#2c5fa0', 'o'), ('oracle', '#333333', 'D')]:
    ax.scatter(of[v]['mean_overlap'], of[v]['mean_forget'], s=80, color=c,
               marker=mk, edgecolor='k', zorder=5, label=f'{v} (mean)')
ax.set_xlabel('routing overlap $O_{ij}$')
ax.set_ylabel('forgetting $F_{ij}$ / final L1')
ax.legend(fontsize=7, frameon=False)
ax.set_title('(c) theory: overlap controls interference', fontsize=10)

fig.tight_layout()
fig.savefig(os.path.join(HERE, 'exp9v2_closing.png'), dpi=200)
print('saved exp9v2_closing.png')
