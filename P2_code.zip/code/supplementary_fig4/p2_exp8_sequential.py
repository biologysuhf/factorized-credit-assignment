"""
P2 Exp8: sequential latent-context benchmark with stochastic transitions.

A two-step decision tree:
  1. choose one of two paths;
  2. the path stochastically transitions to one of two rooms;
  3. choose one of two terminal actions with an equal-mean reward distribution.

The latent context changes both transition probabilities and terminal reward
distributions. Training uses raw terminal rewards only. At test, all synapses,
transition counts, and gate prototypes are frozen; risk readouts are swapped
without new learning. Planning uses the learned transition estimate:
    V(path) = sum_room P_hat(room|path) max_action V_utility(room, action).

This is the sequential extension of Exp6 rather than a bandit repeat.
"""
import numpy as np
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from p2_model import FactorizedModel, make_states
import p2_exp6_revaluation as e6

NCTX = 4
NPATH = 2
NROOM = 2
NACTION = 2
NSEEDS = 20
T = 14400
SWITCH = 40
CUE_NOISE = 0.20
TEST_UTILS = ['risk_averse', 'risk_seeking', 'lower_tail']

# Context-specific stochastic transitions TRANS[c, path, room].
TRANS = np.array([
    [[0.9, 0.1], [0.1, 0.9]],
    [[0.6, 0.4], [0.4, 0.6]],
    [[0.2, 0.8], [0.8, 0.2]],
    [[0.5, 0.5], [0.7, 0.3]],
])

# Terminal distributions LEAF_DISTS[c, room, action]. All means equal 0.5.
LEAF_DISTS = np.array([
    [['posskew', 'trimodal'], ['moderate', 'rarezero']],
    [['moderate', 'rarezero'], ['negskew', 'bernoulli']],
    [['posskew', 'moderate'], ['negskew', 'rarezero']],
    [['trimodal', 'negskew'], ['bernoulli', 'posskew']],
], dtype=object)

TRUE_EXPECTILES = np.zeros((NCTX, NROOM, NACTION, 7))
for c in range(NCTX):
    for s in range(NROOM):
        for a in range(NACTION):
            vals, probs = e6.DISTS[LEAF_DISTS[c, s, a]]
            TRUE_EXPECTILES[c, s, a] = [e6.expectile(vals, probs, t)
                                        for t in e6.TAUS]
TRUE_LEAF_U = {u: TRUE_EXPECTILES @ w for u, w in e6.UTILITIES.items()}
TRUE_PATH_U = {}
OPT_PATH = {}
OPT_LEAF = {}
for u in TEST_UTILS:
    leaf_u = TRUE_LEAF_U[u]                       # (C,S,A)
    best_leaf = leaf_u.max(axis=2)                # (C,S)
    path_u = np.einsum('cps,cs->cp', TRANS, best_leaf)
    TRUE_PATH_U[u] = path_u
    OPT_PATH[u] = path_u.argmax(axis=1)
    OPT_LEAF[u] = leaf_u.argmax(axis=2)           # (C,S)


def sample_leaf(c, room, action, rng):
    vals, probs = e6.DISTS[LEAF_DISTS[c, room, action]]
    return float(rng.choice(vals, p=probs))


def make_model(variant, seed):
    if variant == 'moment':
        return e6.MomentMemory(nfeat=16, seed=seed)
    C = 1 if variant in ('scalar', 'dist') else 4
    Q = 7 if variant in ('dist', 'joint', 'randgate', 'oracle') else 1
    learn_gate = variant in ('comp', 'joint')
    return FactorizedModel(nfeat=16, Q=Q, C=C, seed=seed,
                           eta_c=np.linspace(0.35, 0.15, C), lr_chan=0.05,
                           learn_A=False, learn_gate=learn_gate,
                           A_readout=False)


def leaf_values(m, variant, X, g, utility):
    """Values for the four room-action leaves under the frozen memory."""
    if variant == 'moment':
        return np.array([[m.values(X[s, a], utility) for a in range(NACTION)]
                         for s in range(NROOM)])
    w = e6.UTILITIES[utility] if m.Q == 7 else np.ones(m.Q) / m.Q
    Vq = np.stack([m.U[c] @ X[s, a]
                   for s in range(NROOM) for a in range(NACTION)
                   for c in range(m.C)])
    Vq = Vq.reshape(NROOM, NACTION, m.C, m.Q)
    return np.einsum('sac,c->sa', Vq @ w, g)


def normalize_counts(counts):
    out = counts.copy()
    denom = out.sum(axis=2, keepdims=True)
    denom[denom == 0] = 1.0
    return out / denom


def run(variant, seed, cue_noise=CUE_NOISE):
    rng = np.random.default_rng(41000 + seed)
    if variant == 'oracle':
        path_acc = {u: 1.0 for u in TEST_UTILS}
        leaf_acc = {u: 1.0 for u in TEST_UTILS}
        pol_acc = {u: 1.0 for u in TEST_UTILS}
        regret = {u: 0.0 for u in TEST_UTILS}
        return dict(variant=variant, seed=seed,
                    policy_acc=1.0, path_acc=path_acc, leaf_acc=leaf_acc,
                    policy_by_utility=pol_acc, regret_by_utility=regret,
                    mean_regret=0.0, dist_l1=0.0, trans_tv=0.0,
                    purity=1.0, neff=4.0)

    m = make_model(variant, seed)
    C = getattr(m, 'C', 1)
    X = make_states(NROOM * NACTION, 16, seed=17).reshape(NROOM, NACTION, 16)
    ctx_feats = make_states(NCTX, 16, seed=9)
    ctx = e6.gen_schedule(rng, T, SWITCH)
    gate_rec = np.zeros((T, C))
    trans_counts = np.zeros((C, NPATH, NROOM))

    for t in range(T):
        c = ctx[t]
        o = ctx_feats[c] + cue_noise * rng.standard_normal(16)
        o /= np.linalg.norm(o)
        if variant == 'randgate':
            g = np.eye(C)[rng.integers(0, C)]
            m.last_g = g
        else:
            g = m.gate(o, context=None)
        path = int(rng.integers(0, NPATH))
        room = int(rng.random() < TRANS[c, path, 1])
        action = int(rng.integers(0, NACTION))
        r = sample_leaf(c, room, action, rng)
        m.learn(X[room, action], r, context=c, g_pre=g, obs=o)
        trans_counts[:, path, room] += g
        gate_rec[t] = g

    P_hat = normalize_counts(trans_counts)

    path_acc = {}; leaf_acc = {}; pol_acc = {}; regret_u = {}
    for u in TEST_UTILS:
        pa = np.zeros(NCTX); la = np.zeros(NCTX); po = np.zeros(NCTX)
        rg = np.zeros(NCTX)
        for c in range(NCTX):
            o = ctx_feats[c] / np.linalg.norm(ctx_feats[c])
            if variant == 'randgate':
                g = np.eye(C)[rng.integers(0, C)]
            else:
                g = m.gate(o, context=None)
            Vleaf = leaf_values(m, variant, X, g, u)
            P_read = np.einsum('k,kps->ps', g, P_hat)
            best_leaf_model = Vleaf.max(axis=1)
            path_val = P_read @ best_leaf_model
            path = int(path_val.argmax())
            leaves = Vleaf.argmax(axis=1)
            pa[c] = float(path == OPT_PATH[u][c])
            la[c] = float(np.mean(leaves == OPT_LEAF[u][c]))
            po[c] = 0.5 * pa[c] + 0.5 * la[c]
            # True expected regret of the model's full two-step policy.
            true_leaf = TRUE_LEAF_U[u][c]
            model_val = sum(TRANS[c, path, s] * true_leaf[s, leaves[s]]
                            for s in range(NROOM))
            oracle_val = TRUE_PATH_U[u][c].max()
            rg[c] = float(oracle_val - model_val)
        path_acc[u] = float(pa.mean())
        leaf_acc[u] = float(la.mean())
        pol_acc[u] = float(po.mean())
        regret_u[u] = float(rg.mean())

    # Frozen memory retention.
    if getattr(m, 'Q', None) == 7:
        l1s = []
        for c in range(NCTX):
            o = ctx_feats[c] / np.linalg.norm(ctx_feats[c])
            if variant == 'randgate':
                g = np.eye(C)[rng.integers(0, C)]
            else:
                g = m.gate(o, context=None)
            j = int(g.argmax())
            pred = np.stack([m.U[j] @ X[s, a]
                             for s in range(NROOM) for a in range(NACTION)])
            pred = pred.reshape(NROOM, NACTION, 7)
            l1s.append(float(np.abs(pred - TRUE_EXPECTILES[c]).mean()))
        dist_l1 = float(np.mean(l1s))
    else:
        dist_l1 = np.nan
    tv = []
    for c in range(NCTX):
        # compare each context's most-used compartment transition estimate
        o = ctx_feats[c] / np.linalg.norm(ctx_feats[c])
        if variant == 'randgate':
            g = np.eye(C)[rng.integers(0, C)]
        else:
            g = m.gate(o, context=None)
        j = int(g.argmax())
        tv.append(float(0.5 * np.abs(P_hat[j] - TRANS[c]).sum(axis=1).mean()))
    trans_tv = float(np.mean(tv))

    purity = neff = np.nan
    if C > 1 and variant != 'randgate':
        assign = gate_rec.argmax(1)
        usage = np.array([(assign == j).mean() for j in range(C)])
        neff = float(np.exp(-(usage[usage > 1e-9]
                              * np.log(usage[usage > 1e-9])).sum()))
        purity = float(sum((assign == j).mean()
                           * max((ctx[assign == j] == c).mean()
                                 for c in range(NCTX))
                           for j in range(C) if (assign == j).any()))
    policy_acc = float(np.mean(list(pol_acc.values())))
    mean_regret = float(np.mean(list(regret_u.values())))
    return dict(variant=variant, seed=seed, policy_acc=policy_acc,
                path_acc=path_acc, leaf_acc=leaf_acc,
                policy_by_utility=pol_acc, regret_by_utility=regret_u,
                mean_regret=mean_regret, dist_l1=dist_l1,
                trans_tv=trans_tv, purity=purity, neff=neff,
                gate_rec=gate_rec, ctx=ctx)


if __name__ == '__main__':
    variants = ['scalar', 'moment', 'dist', 'comp', 'randgate', 'joint', 'oracle']
    res = {v: [] for v in variants}
    for v in variants:
        for s in range(NSEEDS):
            res[v].append(run(v, s))
            print(f'{v} seed {s} done', flush=True)
    HERE = os.path.dirname(os.path.abspath(__file__))
    np.save(os.path.join(HERE, 'exp8_sequential.npy'), res, allow_pickle=True)

    print('\nOracle path choices:')
    for u in TEST_UTILS:
        print(f'  {u:12s}: {OPT_PATH[u].tolist()}')
    print('\nSummary:')
    print(f"{'variant':9s} {'policy':>7s} {'regret':>7s} {'L1':>7s} "
          f"{'transTV':>8s} {'purity':>7s}")
    for v in variants:
        pol = np.array([r['policy_acc'] for r in res[v]])
        reg = np.array([r['mean_regret'] for r in res[v]])
        l1 = np.array([r['dist_l1'] for r in res[v]], float)
        tv = np.array([r['trans_tv'] for r in res[v]], float)
        pur = np.array([r['purity'] for r in res[v]], float)
        print(f"{v:9s} {pol.mean():7.3f} {reg.mean():7.3f} "
              f"{np.nanmean(l1):7.3f} {np.nanmean(tv):8.3f} "
              f"{np.nanmean(pur):7.3f}")
    print('\nPer-utility policy accuracy:')
    for v in variants:
        print(f"{v:9s} " + ' '.join(
            f"{u}={np.mean([r['policy_by_utility'][u] for r in res[v]]):.3f}"
            for u in TEST_UTILS))

    from scipy import stats
    j = np.array([r['policy_acc'] for r in res['joint']])
    best = np.maximum(np.array([r['policy_acc'] for r in res['dist']]),
                      np.array([r['policy_acc'] for r in res['comp']]))
    d = j - best
    tt, pp = stats.ttest_1samp(d, 0)
    print(f"\nsequential synergy joint-max(dist,comp): "
          f"{d.mean():+.4f}±{d.std():.4f} t={tt:.2f} p={pp:.6f} "
          f"dz={d.mean()/(d.std()+1e-12):.2f}")
