"""
P2 Exp7: unseen-utility generalization from frozen distributional memories.

Acquisition is identical to Exp6: latent contexts, raw rewards only, all action
means equal. At test, the model is evaluated across a parameterized family of
readouts anchored at the mean expectile:
    rho < 0: mean -> risk-averse
    rho = 0: mean
    rho > 0: mean -> risk-seeking
Seen calibration points: rho = {-1, 0, +1}.
Unseen tests: interpolation rho = {-0.5, +0.5} and extrapolation
rho = {-1.5, +1.5}.

This is not a claim that 7 expectiles represent arbitrary utilities. It tests
whether one frozen expectile basis supports interpolation and modest
extrapolation within a predeclared monotone risk-readout family.
"""
import numpy as np
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from p2_model import FactorizedModel, TAUS7, make_states
import p2_exp6_revaluation as e6

NCTX = e6.NCTX
NSEEDS = 20
T = 9600
SWITCH = 40
CUE_NOISE = 0.25
TAUS = np.array(TAUS7)
MEAN_W = np.zeros(7); MEAN_W[3] = 1.0
W_AV = e6.UTILITIES['risk_averse']
W_SEEK = e6.UTILITIES['risk_seeking']
SEEN_RHOS = (-1.0, 0.0, 1.0)
UNSEEN_RHOS = (-1.5, -0.5, 0.5, 1.5)
ALL_RHOS = (-1.5, -1.0, -0.5, 0.0, 0.5, 1.0, 1.5)


def rho_weights(rho):
    if rho < 0:
        w = MEAN_W + abs(rho) * (W_AV - MEAN_W)
    else:
        w = MEAN_W + rho * (W_SEEK - MEAN_W)
    np.clip(w, 0.0, None, out=w)
    if w.sum() == 0:
        return MEAN_W.copy()
    return w / w.sum()


RHO_W = {r: rho_weights(r) for r in ALL_RHOS}
TRUE_VAL = {r: e6.TRUE_EXPECTILES @ w for r, w in RHO_W.items()}
OPT = {r: TRUE_VAL[r].argmax(axis=1) for r in ALL_RHOS}


def moment_value(m, x, rho):
    f = m.M[0] @ x
    if rho < 0:
        return float(f[0] + abs(rho) * (-2.0 * f[4]))
    return float(f[0] + rho * (2.0 * f[3]))


def model_values(m, variant, arms, c, clean_cue, rho, rng):
    if variant == 'moment':
        return np.array([moment_value(m, arms[a], rho) for a in range(2)])
    w = RHO_W[rho] if m.Q == 7 else np.ones(m.Q) / m.Q
    if variant == 'oracle':
        return TRUE_VAL[rho][c].copy()
    if variant == 'randgate':
        g = np.eye(m.C)[rng.integers(0, m.C)]
    else:
        g = m.gate(clean_cue, context=None)
    Vq = np.stack([m.U[j] @ arms[a] for a in range(2) for j in range(m.C)])
    Vq = Vq.reshape(2, m.C, m.Q)
    return Vq @ w @ g


def run(variant, seed, cue_noise=CUE_NOISE):
    rng = np.random.default_rng(27000 + seed)
    m = e6.make_model(variant, seed)
    arms = make_states(2, 16, seed=5)
    ctx_feats = make_states(NCTX, 16, seed=9)
    ctx = e6.gen_schedule(rng, T, SWITCH)
    gate_rec = np.zeros((T, getattr(m, 'C', 1)))

    for t in range(T):
        c = ctx[t]
        o = ctx_feats[c] + cue_noise * rng.standard_normal(16)
        o /= np.linalg.norm(o)
        if variant == 'randgate':
            g = np.eye(m.C)[rng.integers(0, m.C)]
            m.last_g = g
        else:
            g = m.gate(o, context=c if variant == 'oracle' else None)
        a = int(rng.integers(0, 2))
        r = e6.sample_reward(c, a, rng)
        m.learn(arms[a], r, context=c, g_pre=g, obs=o)
        gate_rec[t] = g

    # Frozen evaluation across the readout family.
    acc_rho = {}; reg_rho = {}; choice_rho = {}
    for rho in ALL_RHOS:
        co = np.zeros(NCTX); re = np.zeros(NCTX); ch = np.zeros(NCTX, dtype=int)
        for c in range(NCTX):
            o = ctx_feats[c] / np.linalg.norm(ctx_feats[c])
            vals = model_values(m, variant, arms, c, o, rho, rng)
            a = int(vals[1] > vals[0])
            ch[c] = a
            co[c] = float(np.isclose(TRUE_VAL[rho][c, a],
                                     TRUE_VAL[rho][c].max()))
            re[c] = float(TRUE_VAL[rho][c].max() - TRUE_VAL[rho][c, a])
        acc_rho[rho] = float(co.mean())
        reg_rho[rho] = float(re.mean())
        choice_rho[rho] = ch

    if variant == 'oracle':
        dist_l1 = 0.0
    elif getattr(m, 'Q', None) == 7:
        l1s = []
        for c in range(NCTX):
            o = ctx_feats[c] / np.linalg.norm(ctx_feats[c])
            if variant == 'randgate':
                g = np.eye(m.C)[rng.integers(0, m.C)]
            else:
                g = m.gate(o, context=None)
            j = int(g.argmax())
            pred = np.stack([m.U[j] @ arms[a] for a in range(2)])
            l1s.append(float(np.abs(pred - e6.TRUE_EXPECTILES[c]).mean()))
        dist_l1 = float(np.mean(l1s))
    else:
        dist_l1 = np.nan

    purity = neff = np.nan
    if getattr(m, 'C', 1) > 1 and variant != 'randgate':
        assign = gate_rec.argmax(1)
        usage = np.array([(assign == j).mean() for j in range(m.C)])
        neff = float(np.exp(-(usage[usage > 1e-9]
                              * np.log(usage[usage > 1e-9])).sum()))
        purity = float(sum((assign == j).mean()
                           * max((ctx[assign == j] == c).mean()
                                 for c in range(NCTX))
                           for j in range(m.C) if (assign == j).any()))

    seen_acc = float(np.mean([acc_rho[r] for r in SEEN_RHOS]))
    unseen_acc = float(np.mean([acc_rho[r] for r in UNSEEN_RHOS]))
    all_acc = float(np.mean([acc_rho[r] for r in ALL_RHOS]))
    return dict(variant=variant, seed=seed, seen_acc=seen_acc,
                unseen_acc=unseen_acc, all_acc=all_acc,
                acc_rho=acc_rho, reg_rho=reg_rho, choice_rho=choice_rho,
                dist_l1=dist_l1, purity=purity, neff=neff,
                gate_rec=gate_rec, ctx=ctx)


if __name__ == '__main__':
    variants = ['scalar', 'moment', 'dist', 'comp', 'randgate', 'joint', 'oracle']
    res = {v: [] for v in variants}
    for v in variants:
        for s in range(NSEEDS):
            res[v].append(run(v, s))
    HERE = os.path.dirname(os.path.abspath(__file__))
    np.save(os.path.join(HERE, 'exp7_unseen_utility.npy'), res,
            allow_pickle=True)

    print('Optimal arms by rho:')
    for r in ALL_RHOS:
        print(f'  rho={r:+.1f}: {OPT[r].tolist()}')
    print('\nSummary:')
    print(f"{'variant':9s} {'seen':>7s} {'unseen':>7s} {'all':>7s} "
          f"{'L1':>7s} {'purity':>7s}")
    for v in variants:
        seen = np.mean([r['seen_acc'] for r in res[v]])
        unseen = np.mean([r['unseen_acc'] for r in res[v]])
        allacc = np.mean([r['all_acc'] for r in res[v]])
        l1 = np.nanmean([r['dist_l1'] for r in res[v]])
        pur = np.nanmean([r['purity'] for r in res[v]])
        print(f"{v:9s} {seen:7.3f} {unseen:7.3f} {allacc:7.3f} "
              f"{l1:7.3f} {pur:7.3f}")
    print('\nAccuracy by rho:')
    for v in variants:
        vals = [np.mean([r['acc_rho'][rho] for r in res[v]]) for rho in ALL_RHOS]
        print(f"{v:9s} " + ' '.join(f"{rho:+.1f}:{x:.3f}"
                                   for rho, x in zip(ALL_RHOS, vals)))

    from scipy import stats
    j = np.array([r['unseen_acc'] for r in res['joint']])
    best = np.maximum(np.array([r['unseen_acc'] for r in res['dist']]),
                      np.array([r['unseen_acc'] for r in res['comp']]))
    d = j - best
    tt, pp = stats.ttest_1samp(d, 0)
    print(f"\nunseen synergy joint-max(dist,comp): {d.mean():+.4f}±{d.std():.4f} "
          f"t={tt:.2f} p={pp:.6f} dz={d.mean()/(d.std()+1e-12):.2f}")
