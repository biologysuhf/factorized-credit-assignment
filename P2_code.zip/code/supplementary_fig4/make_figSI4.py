"""Supplementary Fig. 4: utility-family generalization + sequential planning (7 panels), supports Fig. 5 and Extended Data Fig. 1.
 Data: exp7_unseen_utility.npy (a-c, 7 variants x 20 seeds)
             exp8_sequential.npy (d-g, 7 variants x 20 seeds)
 Error bars = std(ddof=1)/sqrt(20)
 Output: supplementary_fig4.png
"""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
CODE = os.path.dirname(os.path.abspath(__file__))   # adjust to the actual path if needed
r7 = np.load(os.path.join(CODE, "exp7_unseen_utility.npy"), allow_pickle=True).item()
r8 = np.load(os.path.join(CODE, "exp8_sequential.npy"), allow_pickle=True).item()
ALL_RHOS = (-1.5, -1.0, -0.5, 0.0, 0.5, 1.0, 1.5)
UNSEEN_RHOS = (-1.5, -0.5, 0.5, 1.5)
TEST_UTILS = ["risk_averse", "risk_seeking", "lower_tail"]

colors = {"scalar": "#888888", "moment": "#b07aa1", "dist": "#2176AE",
          "comp": "#E8A33D", "randgate": "#7A5195", "joint": "#C0392B",
          "oracle": "#2B2B2B"}
labels = {"scalar": "Scalar", "moment": "Moment", "dist": "Dist-only",
          "comp": "Comp-only", "randgate": "Rand-gate", "joint": "Joint",
          "oracle": "Oracle"}
V7 = ["scalar", "moment", "dist", "comp", "randgate", "joint", "oracle"]
util_labels = {"risk_averse": "Risk-averse", "risk_seeking": "Risk-seeking",
               "lower_tail": "Lower-tail"}


def ms(res, v, key=None, u=None):
    xs = np.array([r[key] for r in res[v]] if key else
                  [r["policy_by_utility"][u] for r in res[v]], dtype=float)
    return xs.mean(), xs.std(ddof=1) / np.sqrt(len(xs))


fig = plt.figure(figsize=(14.2, 6.6), dpi=150)
gs = fig.add_gridspec(2, 4, wspace=0.42, hspace=0.55,
                      width_ratios=[1, 1.05, 0.95, 0.95])

# ---------- a: interpolation + extrapolation ----------
ax = fig.add_subplot(gs[0, 0])
m = [ms(r7, v, "unseen_acc") for v in V7]
ax.bar(np.arange(7), [x[0] for x in m], yerr=[x[1] for x in m],
       color=[colors[v] for v in V7], capsize=3, error_kw=dict(lw=1),
       width=0.68)
ax.axhline(0.5, c="k", ls=":", lw=0.9)
ax.set_xticks(np.arange(7))
ax.set_xticklabels([labels[v] for v in V7], rotation=25, ha="right",
                   fontsize=7.5)
ax.set_ylim(0, 1.08); ax.set_ylabel("Unseen-utility accuracy")
ax.set_title("Interpolation + extrapolation", fontsize=10, loc="left",
             fontweight="bold")

# ---------- b: frozen memories across the utility family ----------
ax = fig.add_subplot(gs[0, 1])
for v in ["scalar", "moment", "dist", "comp", "joint", "oracle"]:
    ys = [np.mean([r["acc_rho"][rho] for r in r7[v]]) for rho in ALL_RHOS]
    ax.plot(ALL_RHOS, ys, "o-", ms=4, lw=1.5, color=colors[v],
            label=labels[v])
for rho in UNSEEN_RHOS:
    ax.axvline(rho, color="0.88", lw=0.7, zorder=0)
ax.axhline(0.5, c="k", ls=":", lw=0.9)
ax.set_xlabel(r"Risk-readout parameter $\rho$"); ax.set_ylabel("Accuracy")
ax.set_ylim(0.35, 1.30)
ax.set_title("Across the utility family", fontsize=10,
             loc="left", fontweight="bold")
ax.legend(fontsize=6.5, frameon=False, ncol=2, loc="upper left")

# ---------- c: memory retention ----------
ax = fig.add_subplot(gs[0, 2])
shown = ["dist", "randgate", "joint", "oracle"]
m = [ms(r7, v, "dist_l1") for v in shown]
ax.bar(np.arange(4), [x[0] for x in m], yerr=[x[1] for x in m],
       color=[colors[v] for v in shown], capsize=3, error_kw=dict(lw=1),
       width=0.62)
ax.set_xticks(np.arange(4))
ax.set_xticklabels([labels[v] for v in shown], rotation=20, ha="right",
                   fontsize=7.5)
ax.set_ylabel("Expectile L1 error"); ax.set_ylim(0, 0.1)
for i, x in enumerate(m):
    if x[0] == 0:
        ax.text(i, 0.002, "0", ha="center", fontsize=8, color="#2B2B2B")
pur = np.mean([r["purity"] for r in r7["joint"]])
ax.text(0.03, 0.92, f"Joint purity = {pur:.2f}", transform=ax.transAxes,
        fontsize=8.5)
ax.set_title("Memory retention", fontsize=10, loc="left", fontweight="bold")

# ---------- d: sequential zero-update planning ----------
ax = fig.add_subplot(gs[0, 3])
m = [ms(r8, v, "policy_acc") for v in V7]
ax.bar(np.arange(7), [x[0] for x in m], yerr=[x[1] for x in m],
       color=[colors[v] for v in V7], capsize=3, error_kw=dict(lw=1),
       width=0.68)
ax.axhline(0.5, c="k", ls=":", lw=0.9)
ax.set_xticks(np.arange(7))
ax.set_xticklabels([labels[v] for v in V7], rotation=25, ha="right",
                   fontsize=7.5)
ax.set_ylim(0, 1.08); ax.set_ylabel("Two-step policy accuracy")
ax.set_title("Sequential zero-update planning", fontsize=10, loc="left",
             fontweight="bold")

# ---------- e: utility-specific planning ----------
ax = fig.add_subplot(gs[1, 0])
show = ["scalar", "moment", "dist", "comp", "joint"]
x = np.arange(3); w = 0.15
for i, v in enumerate(show):
    m = [ms(r8, v, u=u) for u in TEST_UTILS]
    ax.bar(x + (i - 2) * w, [y[0] for y in m], w * 0.9,
           yerr=[y[1] for y in m], color=colors[v], capsize=2,
           error_kw=dict(lw=0.8), label=labels[v])
ax.axhline(0.5, c="k", ls=":", lw=0.9)
ax.set_xticks(x)
ax.set_xticklabels([util_labels[u] for u in TEST_UTILS], fontsize=8)
ax.set_ylim(0, 1.08); ax.set_ylabel("Policy accuracy")
ax.set_title("Utility-specific planning", fontsize=10, loc="left",
             fontweight="bold")
ax.legend(fontsize=6.3, frameon=False, ncol=2)

# ---------- f: outcome memory retention ----------
ax = fig.add_subplot(gs[1, 1])
m = [ms(r8, v, "dist_l1") for v in shown]
ax.bar(np.arange(4), [x[0] for x in m], yerr=[x[1] for x in m],
       color=[colors[v] for v in shown], capsize=3, error_kw=dict(lw=1),
       width=0.62)
ax.set_xticks(np.arange(4))
ax.set_xticklabels([labels[v] for v in shown], rotation=20, ha="right",
                   fontsize=7.5)
for i, x in enumerate(m):
    if x[0] == 0:
        ax.text(i, 0.0014, "0", ha="center", fontsize=8, color="#2B2B2B")
ax.set_ylabel("Outcome expectile L1"); ax.set_ylim(0, 0.07)
ax.set_title("Outcome memory retention", fontsize=10, loc="left",
             fontweight="bold")

# ---------- g: transition memory retention ----------
ax = fig.add_subplot(gs[1, 2])
m = [ms(r8, v, "trans_tv") for v in shown]
ax.bar(np.arange(4), [x[0] for x in m], yerr=[x[1] for x in m],
       color=[colors[v] for v in shown], capsize=3, error_kw=dict(lw=1),
       width=0.62)
ax.set_xticks(np.arange(4))
ax.set_xticklabels([labels[v] for v in shown], rotation=20, ha="right",
                   fontsize=7.5)
ax.set_ylabel("Transition TV error"); ax.set_ylim(0, 0.27)
for i, x in enumerate(m):
    if x[0] == 0:
        ax.text(i, 0.005, "0", ha="center", fontsize=8, color="#2B2B2B")
pur8 = np.mean([r["purity"] for r in r8["joint"]])
ax.text(0.03, 0.92, f"Joint purity = {pur8:.2f}", transform=ax.transAxes,
        fontsize=8.5)
ax.set_title("Transition memory retention", fontsize=10, loc="left",
             fontweight="bold")

for axx in fig.axes:
    axx.spines[["top", "right"]].set_visible(False)
# panel letters: placed directly above each subplot y-axis label (absolute pixel
# positioning, avoiding drift of transAxes offsets with subplot/tick widths)
fig.canvas.draw()
_fw, _fh = fig.bbox.size
for axx, L in zip(fig.axes, "abcdefg"):
    bb = axx.get_window_extent()
    fig.text((bb.x0 - 60) / _fw, (bb.y1 + 10) / _fh, L,
             fontsize=15, fontweight="bold", va="bottom", ha="right")
fig.text(0.5, -0.02, "mean ± SEM, n = 20 seeds (all panels)",
         fontsize=8, color="#444", ha="center", va="top")
out = os.path.join(HERE, "supplementary_fig4.png")
fig.savefig(out, bbox_inches="tight")
print("saved:", os.path.abspath(out))
