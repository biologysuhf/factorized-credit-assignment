"""P2 Exp7 figure: unseen utility interpolation/extrapolation."""
import numpy as np
import matplotlib.pyplot as plt
import os
from p2_exp7_unseen_utility import ALL_RHOS, UNSEEN_RHOS

HERE = os.path.dirname(os.path.abspath(__file__))
res = np.load(os.path.join(HERE, 'exp7_unseen_utility.npy'), allow_pickle=True).item()
colors = {'scalar': '#8c8c8c', 'moment': '#b07aa1', 'dist': '#2176ae',
          'comp': '#e8a33d', 'randgate': '#7a5195', 'joint': '#c0392b',
          'oracle': '#2b2b2b'}
labels = {'scalar': 'Scalar', 'moment': 'Moment', 'dist': 'Dist-only',
          'comp': 'Comp-only', 'randgate': 'Rand-gate', 'joint': 'Joint',
          'oracle': 'Oracle'}
variants = ['scalar', 'moment', 'dist', 'comp', 'randgate', 'joint', 'oracle']

fig, axes = plt.subplots(1, 3, figsize=(10.8, 3.4))

ax = axes[0]
means = [np.mean([r['unseen_acc'] for r in res[v]]) for v in variants]
sems = [np.std([r['unseen_acc'] for r in res[v]]) / np.sqrt(len(res[v]))
        for v in variants]
ax.bar(np.arange(len(variants)), means, yerr=sems, capsize=3,
       color=[colors[v] for v in variants], width=0.68)
ax.axhline(0.5, color='k', ls=':', lw=0.9)
ax.set_xticks(np.arange(len(variants)))
ax.set_xticklabels([labels[v] for v in variants], rotation=25, ha='right', fontsize=7)
ax.set_ylim(0, 1.08); ax.set_ylabel('Unseen-utility accuracy')
ax.set_title('a  Interpolation + extrapolation', loc='left', fontsize=9.5,
             fontweight='bold')

ax = axes[1]
for v in ['scalar', 'moment', 'dist', 'comp', 'joint', 'oracle']:
    ys = [np.mean([r['acc_rho'][rho] for r in res[v]]) for rho in ALL_RHOS]
    ax.plot(ALL_RHOS, ys, 'o-', ms=4, lw=1.5, color=colors[v], label=labels[v])
for rho in UNSEEN_RHOS:
    ax.axvline(rho, color='0.85', lw=0.7, zorder=0)
ax.axhline(0.5, color='k', ls=':', lw=0.9)
ax.set_xlabel('Risk-readout parameter ρ')
ax.set_ylabel('Accuracy')
ax.set_ylim(0.35, 1.06)
ax.set_title('b  Frozen memories across the utility family', loc='left',
             fontsize=9.5, fontweight='bold')
ax.legend(fontsize=6, frameon=False, ncol=2)

ax = axes[2]
shown = ['dist', 'randgate', 'joint', 'oracle']
means = [np.mean([r['dist_l1'] for r in res[v]]) for v in shown]
sems = [np.std([r['dist_l1'] for r in res[v]]) / np.sqrt(len(res[v]))
        for v in shown]
ax.bar(np.arange(len(shown)), means, yerr=sems, capsize=3,
       color=[colors[v] for v in shown], width=0.62)
ax.set_xticks(np.arange(len(shown)))
ax.set_xticklabels([labels[v] for v in shown], rotation=20, ha='right', fontsize=7)
ax.set_ylabel('Expectile L1 error')
ax.set_ylim(0, 0.1)
pur = np.mean([r['purity'] for r in res['joint']])
ax.text(0.03, 0.92, f'Joint purity = {pur:.2f}', transform=ax.transAxes,
        fontsize=8)
ax.set_title('c  Memory retention', loc='left', fontsize=9.5,
             fontweight='bold')

for a in axes:
    a.spines[['top', 'right']].set_visible(False)
fig.tight_layout()
fig.savefig(os.path.join(HERE, 'exp7_unseen_utility.png'), dpi=220)
print('saved exp7_unseen_utility.png')
