"""Figure 6 | Capacity and robustness  (v3, 2026-10-03)
Changes vs v2:
  b) legend removed (the two y axes are colour-coded; stated in the caption).
  c) arrow annotations and colorbar removed; k value printed under each point,
     with a one-line mechanism note below seed 1.
  a) unchanged.
Usage: cd to this directory, then  python make_fig6_v3.py
Output: fig6_capacity_v3.png (300 dpi)
"""
import json, glob, re
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams["font.family"] = "Liberation Sans"
COL = {"dist-only": "#1f77b4", "comp-only": "#ff9f1a", "joint": "#d62728",
       "oracle": "#111111"}
# jitter calibrated so adjacent circles overlap by 1/3 (marker s=15, spacing = 2/3 diameter)
JIT_A = {0: -0.047, 1: -0.0235, 2: 0.0, 3: 0.0235, 4: 0.047}   # panel a
JIT_B = {0: -0.0085, 1: -0.0043, 2: 0.0, 3: 0.0043, 4: 0.0085}  # panel b


def load_all():
    out = {}
    for f in glob.glob("data/gate_*.json"):
        b = glob.os.path.basename(f)
        m = re.match(r"gate_(\w+(?:-\w+)*)_s(\d+)(?:_n(\d+))?(?:_gr([\d.]+))?\.json", b)
        if not m:
            continue
        v, seed, n, gr = m.group(1), int(m.group(2)), m.group(3), \
            (float(m.group(4)) if m.group(4) else None)
        out[(v, seed, n or "main", gr)] = json.load(open(f))
    return out


D = load_all()


def series(variant, n):
    xs = sorted(s for (v, s, nn, g) in D if v == variant and nn == n and g is None)
    return xs, [D[(variant, s, n, None)]["R_reval"] for s in xs]


fig, axes = plt.subplots(1, 3, figsize=(15.5, 4.8))

# ---------- panel a: N scaling ----------
ax = axes[0]
plot_at = [("2", "2"), ("main", "3L"), ("3", "3R"), ("6", "6")]
xpos = {"2": 2, "3L": 2.88, "3R": 3.12, "6": 6}
mk = {"dist-only": "o", "comp-only": "s", "joint": "D", "oracle": "x"}
for v in ["dist-only", "comp-only", "joint", "oracle"]:
    xs_all, ys_all = [], []
    for nk, xk in plot_at:
        seeds, ys = series(v, nk)
        if not ys:
            continue
        xs_j = [xpos[xk] + JIT_A[s] for s in seeds]
        m = float(np.mean(ys)); sem = float(np.std(ys) / np.sqrt(len(ys)))
        xs_all.append(xpos[xk]); ys_all.append(m)
        ax.scatter(xs_j, ys, color=COL[v], s=15, alpha=0.45, zorder=2)
        ax.errorbar([xpos[xk]], [m], yerr=[sem], fmt=mk[v], color=COL[v],
                    markersize=6, mec="black", mew=0.5, ecolor=COL[v],
                    elinewidth=1.0, capsize=2.5, zorder=4)
    order = np.argsort(xs_all)
    ax.plot([xs_all[i] for i in order], [ys_all[i] for i in order], "-",
            color=COL[v], label=v, zorder=3, lw=1.4)
labels = {"2": ("push,\npeg", "center", -0.02),
          "3L": ("push, peg,\nsweep", "right", -0.05),
          "3R": ("push, peg,\ndrawer", "left", 0.05),
          "6": ("push, peg, sweep,\ndrawer, pick, assembly", "center", 0.0)}
from matplotlib.transforms import blended_transform_factory
trans = blended_transform_factory(ax.transData, ax.transAxes)
for xk, xp in xpos.items():
    txt, ha, xo = labels[xk]
    ax.annotate(txt, (xp + xo, -0.17), transform=trans, ha=ha, va="top",
                fontsize=7.4, annotation_clip=False)
ax.set_xticks([2, 3, 6]); ax.set_xlabel("number of latent contexts $N$")
ax.xaxis.set_label_coords(0.5, -0.55)
ax.set_ylabel("Revaluation accuracy $R$")
ax.set_ylim(0.2, 1.09)
ax.set_xlim(1.6, 6.4)
ax.set_title("Scaling with contexts\n(per-seed dots, mean $\\pm$ SEM)", fontsize=11)
ax.legend(frameon=False, fontsize=8.5, loc="lower left", bbox_to_anchor=(0.02, 0.06))
ax.spines[["top", "right"]].set_visible(False)

# ---------- panel b: radius scan (no legend; dual y axes colour-coded) ----------
ax = axes[1]
grs = sorted({g for (v, s, n, g) in D if g is not None and v == "joint"})
Rmean, Pmean, Rsem, Psem = [], [], [], []
Rpts, Ppts = [], []
for g in grs:
    ds = [D[k] for k in D if k[0] == "joint" and k[3] == g]
    Rs = [d["R_reval"] for d in ds]; Ps = [d["purity"] for d in ds]
    Rmean.append(np.mean(Rs)); Rsem.append(np.std(Rs) / np.sqrt(len(Rs)))
    Pmean.append(np.mean(Ps)); Psem.append(np.std(Ps) / np.sqrt(len(Ps)))
    Rpts.append((g, Rs)); Ppts.append((g, Ps))
for (g, Rs) in Rpts:
    seeds = sorted(s for (v, s, n, gg) in D if v == "joint" and gg == g)
    ax.scatter([g + JIT_B[s] for s in seeds], Rs, color=COL["joint"], s=15,
               alpha=0.45, zorder=2)
ax.plot(grs, Rmean, "D-", color=COL["joint"], zorder=3)
ax.errorbar(grs, Rmean, yerr=Rsem, fmt="none", ecolor=COL["joint"],
            elinewidth=1.0, capsize=2.5, zorder=3)
ax.set_xlabel("seeding radius (gate threshold)")
ax.set_ylabel("$R$ (joint)", color=COL["joint"])
ax.set_ylim(0.4, 1.09)
ax.set_xlim(0.12, 0.56)
ax.set_xticks(grs)  # only the measured radii 0.15/0.2/0.3/0.4/0.5
ax.axvspan(0.3, 0.5, color="#d62728", alpha=0.06)
ax2 = ax.twinx()
for (g, Ps) in Ppts:
    seeds = sorted(s for (v, s, n, gg) in D if v == "joint" and gg == g)
    ax2.scatter([g + JIT_B[s] for s in seeds], Ps, color="#2ca02c", s=15,
                alpha=0.45, zorder=2)
ax2.plot(grs, Pmean, "s--", color="#2ca02c", zorder=3)
ax2.errorbar(grs, Pmean, yerr=Psem, fmt="none", ecolor="#2ca02c",
             elinewidth=1.0, capsize=2.5, zorder=3)
ax2.set_ylabel("routing purity", color="#2ca02c")
ax2.set_ylim(0.4, 1.09)
ax.set_title("Robustness to seeding radius\n(5 seeds per radius)", fontsize=11)
ax.spines[["top"]].set_visible(False)

# ---------- panel c: N=6 boundary anatomy (no colorbar, text annotations) ----------
ax = axes[2]
pts = []
for k in sorted(D, key=lambda t: (t[0], t[1], str(t[2]), str(t[3]))):
    v, s, n, g = k
    if v == "joint" and n == "6":
        d = D[k]
        pts.append((s, d["R_reval"], d.get("k_discovered")))
ax.scatter([p[0] for p in pts], [p[1] for p in pts], s=110, color=COL["joint"],
           edgecolor="black", zorder=3)
for s, y, k in pts:
    ax.annotate(f"$k$={k}", (s, y), textcoords="offset points",
                xytext=(0, -20), ha="center", fontsize=8)
ax.annotate("never seeded\n(pick_place inverted)", (1, 0.80),
            textcoords="offset points", xytext=(0, -48), ha="center",
            fontsize=7.4)
ax.axhline(1.0, color="black", lw=0.8, ls="--")
ax.set_xticks([p[0] for p in pts]); ax.set_xlabel("seed")
ax.set_ylabel("$R$ (joint, $N$=6)")
ax.set_ylim(0.66, 1.0)
ax.set_yticks(np.arange(0.70, 1.01, 0.05))
ax.set_title("Boundary anatomy: failures track\ndiscovery misses, not learning",
             fontsize=11)
ax.spines[["top", "right"]].set_visible(False)

for a, tag in zip(axes, "abc"):
    a.text(-0.16, 1.05, tag, transform=a.transAxes, fontsize=15,
           fontweight="bold", va="bottom")
fig.subplots_adjust(left=0.045, right=0.995, top=0.87, bottom=0.34,
                    wspace=0.42)
fig.savefig("fig6_capacity_v3.png", dpi=300, bbox_inches="tight")
print("saved fig6_capacity_v3.png")
