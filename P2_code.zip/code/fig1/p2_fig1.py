"""P2 Exp1 figure: 4 panels."""
import numpy as np
import matplotlib.pyplot as plt
import os
from p2_exp1_reversal import true_expectiles, N1, N2, N3
from p2_model import TAUS7

HERE = os.path.dirname(os.path.abspath(__file__))
res = np.load(os.path.join(HERE, 'exp1_results.npy'), allow_pickle=True).item()
variants = ['scalar', 'dist', 'comp', 'joint']
labels = {'scalar': 'Scalar RPE', 'dist': 'Distributional only',
          'comp': 'Compartment only', 'joint': 'Joint (full)'}
colors = {'scalar': '#888888', 'dist': '#2176ae', 'comp': '#e8a33d', 'joint': '#c0392b'}

fig, axes = plt.subplots(1, 4, figsize=(13.2, 3.2))

# (a) learning curves
ax = axes[0]
T = N1 + N2 + N3
tt = np.arange(T)
for v in variants:
    curves = np.stack([r['curve'] for r in res[v]])
    m = curves.mean(0)
    k = 15
    ms = np.convolve(m, np.ones(k)/k, 'same')
    ax.plot(tt, ms, color=colors[v], lw=1.8, label=labels[v])
ax.axvline(N1, color='k', ls=':', lw=0.8); ax.axvline(N1+N2, color='k', ls=':', lw=0.8)
ax.text(N1/2, 1.10, 'Ctx A', ha='center', fontsize=9)
ax.text(N1+N2/2, 1.10, 'Ctx B (reversed)', ha='center', fontsize=9)
ax.text(N1+N2+N3/2, 1.10, 'Probe\nA', ha='center', fontsize=8)
ax.set_ylim(-0.02, 1.30); ax.set_xlabel('Trial'); ax.set_ylabel('Accuracy')
ax.set_title('a  Reversal learning & retention', loc='left', fontsize=10, fontweight='bold')
ax.legend(fontsize=7, frameon=False, loc='center left')

# (b) retention probe bar
ax = axes[1]
xs = np.arange(4)
ret = [[r['retention'] for r in res[v]] for v in variants]
ax.bar(xs, [np.mean(x) for x in ret], color=[colors[v] for v in variants], width=0.62)
ax.errorbar(xs, [np.mean(x) for x in ret],
            yerr=[np.std(x)/np.sqrt(len(x)) for x in ret], fmt='k.', capsize=3)
ax.axhline(0.5, color='k', ls=':', lw=0.8)
ax.set_xticks(xs); ax.set_xticklabels(['Scalar', 'Dist', 'Comp', 'Joint'], fontsize=8)
ax.set_ylim(0, 1.05); ax.set_ylabel('Probe accuracy (return to A)')
ax.set_title('b  Memory retention after reversal', loc='left', fontsize=10, fontweight='bold')

# (c) distributional fidelity
ax = axes[2]
taus = np.array(TAUS7)
t0 = true_expectiles(0.8, TAUS7); t1 = true_expectiles(0.2, TAUS7)
ax.plot(taus, t0, 'o--', color='0.25', ms=4, lw=1, label='True A: arm0 (p=.8)')
ax.plot(taus, t1, 's--', color='0.55', ms=4, lw=1, label='True A: arm1 (p=.2)')
cj0 = np.mean([r['ch0'] for r in res['joint']], axis=0)
cj1 = np.mean([r['ch1'] for r in res['joint']], axis=0)
cd0 = np.mean([r['ch0'] for r in res['dist']], axis=0)
ax.plot(taus, cj0, 'o-', color=colors['joint'], ms=5, lw=1.6, mfc='none',
        label='Joint: arm0 (preserved)')
ax.plot(taus, cj1, 'o-', color=colors['joint'], ms=5, lw=1.6, alpha=0.45,
        mfc='none', label='Joint: arm1 (preserved)')
ax.plot(taus, cd0, '^-', color=colors['dist'], ms=5, lw=1.6, mfc='none',
        label='Dist-only: arm0 (overwritten by B)')
ax.set_xlabel(r'Expectile level $\tau$'); ax.set_ylabel('Channel value')
ax.set_title('c  Learned reward distribution (ctx A)', loc='left', fontsize=10, fontweight='bold')
ax.legend(fontsize=6.5, frameon=False, loc='center left')

# (d) factorial summary: retention vs dist fidelity
ax = axes[3]
for v in variants:
    ret_v = np.mean([r['retention'] for r in res[v]])
    if 'dist_L1' in res[v][0]:
        fid = 1 - np.mean([r['dist_L1'] for r in res[v]]) / 0.5   # normalized
    else:
        fid = np.nan
    ax.scatter(fid if not np.isnan(fid) else 0.02, ret_v, s=140, color=colors[v],
               zorder=3, edgecolor='k', lw=0.7)
    ax.annotate(labels[v], (fid if not np.isnan(fid) else 0.02, ret_v),
                textcoords='offset points', xytext=(8, -4), fontsize=8)
ax.set_xlabel('Distributional fidelity (1 − norm. L1)'); ax.set_ylabel('Retention')
ax.set_xlim(-0.05, 1.1); ax.set_ylim(-0.05, 1.05)
ax.set_title('d  Only the joint model keeps both', loc='left', fontsize=10, fontweight='bold')

for a in axes:
    a.spines[['top', 'right']].set_visible(False)
fig.tight_layout()
fig.savefig(os.path.join(HERE, 'exp1_reversal.png'), dpi=220)
print('saved exp1_reversal.png')
