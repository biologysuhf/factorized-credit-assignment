"""P2 Figure 1 — concept schematic (first version).
(a) WHAT x WHERE factorization; (b) four-question architecture;
(c) biological mapping; (d) update rule + interference bound.
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle
from matplotlib.lines import Line2D

plt.rcParams.update({'font.size': 8.5, 'axes.linewidth': 0.8})

TAU = [0.1, 0.25, 0.4, 0.5, 0.6, 0.75, 0.9]
CMAP = plt.cm.viridis
CHAN_COLORS = [CMAP(i / (len(TAU) - 1)) for i in range(len(TAU))]
COMP_COLORS = ['#d95f02', '#1b9e77', '#7570b3', '#e7298a']

fig = plt.figure(figsize=(7.2, 8.6))
gs = fig.add_gridspec(3, 2, height_ratios=[1.0, 1.0, 0.9], hspace=0.42, wspace=0.30,
                      left=0.06, right=0.97, top=0.93, bottom=0.05)


def panel_label(ax, label, x=-0.10):
    ax.text(x, 1.04, label, transform=ax.transAxes, fontsize=11, fontweight='bold', va='top')


# ---------------- (a) WHAT: heterogeneous distributional channels ----------------
axA = fig.add_subplot(gs[0, 0])
panel_label(axA, 'a')
x = np.linspace(0, 1, 400)
dist = np.exp(-((x - 0.42) ** 2) / (2 * 0.12 ** 2)) + 0.9 * np.exp(-((x - 0.85) ** 2) / (2 * 0.04 ** 2))
dist /= dist.max()
axA.fill_between(x, 0, dist, color='0.85', zorder=1)
axA.plot(x, dist, color='0.35', lw=1.2, zorder=2)
# expectile locations (illustrative, monotone in tau)
ex_locs = 0.12 + 0.78 * np.array(TAU)
for t, lx, c in zip(TAU, ex_locs, CHAN_COLORS):
    axA.axvline(lx, color=c, lw=1.4, ls='--', alpha=0.9, zorder=3)
axA.set_xlabel('reward  $r$')
axA.set_ylabel('density')
axA.set_yticks([])
axA.set_title('WHAT is taught:\nheterogeneous distributional channels', fontsize=9)
axA.text(0.02, 0.97, r'$d_q=\alpha_q^{\pm}\delta \;\rightarrow\;\tau_q$-expectile',
         transform=axA.transAxes, fontsize=7.5, va='top',
         bbox=dict(boxstyle='round,pad=0.25', fc='white', ec='0.6', lw=0.5))
for s in ['top', 'right']:
    axA.spines[s].set_visible(False)

# ---------------- (a2) WHERE: routing into compartments ----------------
axB = fig.add_subplot(gs[0, 1])
panel_label(axB, 'b')
axB.set_xlim(0, 1); axB.set_ylim(0, 1); axB.axis('off')
axB.set_title('WHERE it is written:\nlearned routing into protected compartments', fontsize=9)
# broadcast teaching signal (left)
axB.add_patch(Circle((0.13, 0.55), 0.075, fc='#fdd49e', ec='#d95f02', lw=1.2, zorder=3))
axB.text(0.13, 0.55, 'DA\nchannels', ha='center', va='center', fontsize=7)
# gate
gate_x = 0.38
axB.add_patch(FancyBboxPatch((gate_x - 0.06, 0.15), 0.12, 0.80, boxstyle='round,pad=0.02',
                             fc='#deebf7', ec='#3182bd', lw=1.2, zorder=2))
axB.text(gate_x, 0.90, 'gate $g_c(t)$', ha='center', fontsize=8, color='#08519c')
axB.text(gate_x, 0.50, 'routing\n(learned,\nlabel-free)', ha='center', va='center', fontsize=6.5, color='#08519c')
# compartments
comp_ys = [0.85, 0.63, 0.41, 0.19]
comp_x = 0.78
gates_on = [1, 0, 0, 1]
for i, (cy, col, on) in enumerate(zip(comp_ys, COMP_COLORS, gates_on)):
    axB.add_patch(FancyBboxPatch((comp_x - 0.10, cy - 0.075), 0.20, 0.15, boxstyle='round,pad=0.02',
                                 fc=col if on else 'white', ec=col, lw=1.2, alpha=0.9 if on else 0.45))
    axB.text(comp_x, cy, f'M{i}', ha='center', va='center', fontsize=8,
             color='white' if on else col)
    axB.text(comp_x + 0.14, cy, f'$g_{i}$={"1" if on else "0"}', va='center', fontsize=7.5, color=col)
    axB.add_patch(FancyArrowPatch((gate_x + 0.07, 0.55), (comp_x - 0.11, cy),
                                  arrowstyle='-|>', mutation_scale=8,
                                  color=col, lw=1.4 if on else 0.7,
                                  alpha=0.95 if on else 0.35, zorder=1))
axB.add_patch(FancyArrowPatch((0.21, 0.55), (gate_x - 0.07, 0.55), arrowstyle='-|>',
                              mutation_scale=9, color='#d95f02', lw=1.6))
axB.text(0.5, 0.02, 'write permitted      write blocked', fontsize=7, color='0.4', ha='center')

# ---------------- (b) four-question architecture ----------------
axC = fig.add_subplot(gs[1, 0])
panel_label(axC, 'c')
axC.set_xlim(0, 1); axC.set_ylim(0, 1); axC.axis('off')
axC.set_title('Four-question architecture', fontsize=9)
boxes = [
    (0.03, 0.72, 0.44, 0.20, '#deebf7', '#3182bd', 'Where am I?\nlatent-context inference\n(windowed sufficient statistics)'),
    (0.53, 0.72, 0.44, 0.20, '#e5f5e0', '#31a354', 'Where to write?\ncompartment routing $g_c$'),
    (0.03, 0.30, 0.44, 0.20, '#fdd49e', '#d95f02', 'What to store?\noutcome distribution\n(expectile channels)'),
    (0.53, 0.30, 0.44, 0.20, '#f2f0f7', '#756bb1', 'What matters now?\nutility-dependent readout\n$\\sum_q w_q^{(\\rho)} V_{q,c}$'),
]
for (bx, by, bw, bh, fc, ec, txt) in boxes:
    axC.add_patch(FancyBboxPatch((bx, by), bw, bh, boxstyle='round,pad=0.02', fc=fc, ec=ec, lw=1.3))
    axC.text(bx + bw / 2, by + bh / 2, txt, ha='center', va='center', fontsize=6.8)
arr = dict(arrowstyle='-|>', mutation_scale=10, lw=1.4, color='0.35')
axC.add_patch(FancyArrowPatch((0.47, 0.82), (0.53, 0.82), **arr))
axC.add_patch(FancyArrowPatch((0.75, 0.72), (0.75, 0.50), **arr))
axC.add_patch(FancyArrowPatch((0.53, 0.40), (0.47, 0.40), **arr))
# feedback: readout -> action -> reward -> inference
axC.add_patch(FancyArrowPatch((0.25, 0.30), (0.25, 0.72), connectionstyle='arc3,rad=0.35',
                              arrowstyle='-|>', mutation_scale=10, lw=1.2, color='0.55', ls='--'))
axC.text(0.02, 0.50, 'reward history', fontsize=6.5, color='0.45', rotation=90, va='center')

# ---------------- (c) biological mapping ----------------
axD = fig.add_subplot(gs[1, 1])
panel_label(axD, 'd')
axD.set_xlim(0, 1); axD.set_ylim(0, 1); axD.axis('off')
axD.set_title('Biological mapping', fontsize=9)
# dopamine population
for i, t in enumerate(TAU):
    y = 0.90 - i * 0.085
    axD.plot([0.05, 0.20], [y, y], color=CHAN_COLORS[i], lw=3.2, solid_capstyle='round')
    axD.text(0.03, y, f'$\\tau$={t}', fontsize=5.5, va='center', ha='right')
axD.text(0.125, 0.985, 'DA heterogeneity\n(expectile tiling)', ha='center', fontsize=7, va='top')
axD.add_patch(FancyArrowPatch((0.24, 0.62), (0.44, 0.62), arrowstyle='-|>', mutation_scale=11,
                              color='0.35', lw=1.6))
# axonal compartments (mushroom body style)
axD.plot([0.46, 0.92], [0.62, 0.62], color='0.5', lw=4.5, solid_capstyle='round', zorder=1)
comp_pos = [0.53, 0.66, 0.79, 0.90]
for i, (px, col) in enumerate(zip(comp_pos, COMP_COLORS)):
    axD.add_patch(Circle((px, 0.62), 0.045, fc=col, ec='white', lw=1.0, zorder=3))
axD.text(0.69, 0.48, 'axonal compartments\n(companion MS: Su et al.)', ha='center', fontsize=7, va='top')
# plasticity + readout annotations
axD.annotate('gated plasticity\n$g_c \\cdot \\sum_q A_{cq} d_q$', xy=(0.53, 0.67), xytext=(0.30, 0.86),
             fontsize=6.5, ha='center',
             arrowprops=dict(arrowstyle='-|>', color='0.3', lw=1.0))
axD.annotate('utility readout\n(objective changes, synapses frozen)', xy=(0.90, 0.62), xytext=(0.70, 0.10),
             fontsize=6.5, ha='center',
             arrowprops=dict(arrowstyle='-|>', color='#756bb1', lw=1.0))

# ---------------- (e) update rule + bound ----------------
axE = fig.add_subplot(gs[2, :])
panel_label(axE, 'e', x=-0.03)
axE.axis('off')
axE.set_title('Factorized update rule and interference bound', fontsize=9)
axE.text(0.5, 0.78, r'$\Delta W_{ij}^{(c)} \;=\; -\eta_c \;\cdot\; g_c(t) \;\cdot\; e_{ij}^{(c)}(t) \;\cdot\; \sum_q A_{cq}\, d_q(t)$',
         ha='center', va='center', fontsize=15,
         bbox=dict(boxstyle='round,pad=0.45', fc='#f7f7f7', ec='0.5', lw=1.0))
terms = [
    (0.135, 'WHAT\nheterogeneous\nteaching channels', '#d95f02'),
    (0.345, 'WHERE\nrouting gate\n(learned / inferred)', '#3182bd'),
    (0.545, 'eligibility\nsynaptic trace', '0.45'),
    (0.80, 'channel->compartment\ncoupling $A_{cq}$\n(fixed uniform, main text)', '#756bb1'),
]
for tx, tt, col in terms:
    axE.text(tx, 0.40, tt, ha='center', va='center', fontsize=7.5, color=col)
axE.text(0.5, 0.13,
         r'cross-context interference:  $|\Delta_i^{(j)}| \;\leq\; \eta\,|\delta_j|\,(g_i^{\top} g_j)$   '
         r'$\Rightarrow$  routing overlap bounds forgetting',
         ha='center', va='center', fontsize=9.5, color='0.25')

fig.savefig('.', dpi=300)
fig.savefig('.')
print('saved fig1_concept.png/pdf')
