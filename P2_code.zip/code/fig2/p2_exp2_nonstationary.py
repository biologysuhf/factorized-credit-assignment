"""
P2 Experiment 2: non-stationary reward distributions.
Separating *uncertainty* (reward statistics change within the same context ->
update in place, channel spread adapts) from *novelty* (context cue changes ->
new compartment, old distribution preserved).

Phases (single arm presented per trial; reward depends on phase):
  P1: ctx A, reward ~ Ber(0.5)            (high variance)
  P2: ctx A, reward = 0.5 deterministically (same context, variance collapse
      -> should update SAME compartment in place: spread shrinks)
  P3: ctx B, reward ~ Ber(0.5)            (same statistics, new context
      -> should allocate compartment 2, leaving compartment 1 intact)

Readouts:
  spread   : channel max-min = uncertainty signal (should track variance)
  gate     : which compartment is written (novelty signal)
  preserve : L1 between compartment-0 channels and the deterministic-0.5
             target after phase 3 (joint small; dist-only overwritten again)
"""
import numpy as np
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from p2_model import FactorizedModel, TAUS7, make_states

N1, N2, N3 = 200, 200, 200
NSEEDS = 10


def run(variant, seed):
    rng = np.random.default_rng(2000 + seed)
    Q = {'scalar': 1, 'dist': 7, 'comp': 1, 'joint': 7}[variant]
    C = {'scalar': 1, 'dist': 1, 'comp': 2, 'joint': 2}[variant]
    m = FactorizedModel(nfeat=16, Q=Q, C=C, seed=seed,
                        eta_c=[0.25] * C, lr_chan=0.25)
    x = make_states(1, 16, seed=11)[0]

    spread1 = spread2 = np.nan
    trajs = np.zeros(N1 + N2 + N3)
    spread_traj = np.zeros(N1 + N2 + N3)
    gate_traj = np.zeros((N1 + N2 + N3, C))

    for t in range(N1):                            # P1: A, high variance
        r = float(rng.random() < 0.5)
        g, M, _ = m.learn(x, r, context=0)
        trajs[t] = m.behavior_value(x, 0)
        spread_traj[t] = m.uncertainty(x, 0 if C==1 else 0) if Q == 7 else np.nan
        gate_traj[t] = g
    if Q == 7:
        spread1 = m.uncertainty(x, 0)
    for t in range(N2):                            # P2: A, deterministic 0.5
        r = 0.5
        g, M, _ = m.learn(x, r, context=0)
        trajs[N1 + t] = m.behavior_value(x, 0)
        spread_traj[N1 + t] = m.uncertainty(x, 0) if Q == 7 else np.nan
        gate_traj[N1 + t] = g
    if Q == 7:
        spread2 = m.uncertainty(x, 0)
        ch_afterP2 = m.dist_values(x, 0).copy()
    for t in range(N3):                            # P3: B, high variance again
        r = float(rng.random() < 0.5)
        g, M, _ = m.learn(x, r, context=1)
        trajs[N1 + N2 + t] = m.behavior_value(x, 1)
        spread_traj[N1 + N2 + t] = (m.uncertainty(x, 1 if C==2 else 0) if Q == 7 else np.nan)
        gate_traj[N1 + N2 + t] = g

    out = dict(v_end=float(trajs[-20:].mean()))
    if Q == 7:
        out['spread_after_highvar'] = float(spread1)
        out['spread_after_lowvar'] = float(spread2)
        # preservation of compartment-0 (low-var, all expectiles = 0.5)
        out['preserve_L1'] = float(np.abs(m.dist_values(x, 0) - 0.5).mean())
        out['ch_afterP2'] = ch_afterP2
        out['ch_final_c0'] = m.dist_values(x, 0).copy()
        out['ch_final_c1'] = (m.dist_values(x, 1).copy() if C == 2
                              else np.full(Q, np.nan))
    out['value_traj'] = trajs
    out['spread_traj'] = spread_traj
    return out


if __name__ == '__main__':
    variants = ['scalar', 'dist', 'comp', 'joint']
    res = {v: [] for v in variants}
    for v in variants:
        for s in range(NSEEDS):
            res[v].append(run(v, s))
    np.save(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         'exp2_results.npy'), res, allow_pickle=True)
    for v in variants:
        line = f"{v:9s}"
        for k in res[v][0]:
            if 'traj' in k or 'ch_' in k:
                continue
            vals = [r[k] for r in res[v]]
            line += f"  {k} {np.mean(vals):+.3f}±{np.std(vals):.3f}"
        print(line)
