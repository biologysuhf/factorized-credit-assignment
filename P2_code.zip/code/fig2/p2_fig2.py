"""P2 Exp2 figure: uncertainty vs novelty dissociation."""
import numpy as np
import matplotlib.pyplot as plt
import os
from p2_exp2_nonstationary import N1, N2, N3
from p2_model import TAUS7

HERE = os.path.dirname(os.path.abspath(__file__))
res = np.load(os.path.join(HERE, 'exp2_results.npy'), allow_pickle=True).item()
colors = {'scalar': '#888888', 'dist': '#2176ae', 'comp': '#e8a33d', 'joint': '#c0392b'}
labels = {'scalar': 'Scalar RPE', 'dist': 'Distributional only',
          'comp': 'Compartment only', 'joint': 'Joint (full)'}

fig, axes = plt.subplots(1, 4, figsize=(13.2, 3.2))
T = N1 + N2 + N3
tt = np.arange(T)

# (a) value trajectory: mean value stable throughout
ax = axes[0]
for v in ['joint', 'dist']:
    tr = np.stack([r['value_traj'] for r in res[v]])
    ax.plot(tt, tr.mean(0), color=colors[v], lw=1.6, label=labels[v])
ax.axhline(0.5, color='k', ls=':', lw=0.8)
for xb in (N1, N1 + N2):
    ax.axvline(xb, color='k', ls=':', lw=0.8)
ax.text(N1/2, 0.9, 'A: Ber(.5)\nhigh var', ha='center', fontsize=8)
ax.text(N1+N2/2, 0.9, 'A: r=0.5\nlow var', ha='center', fontsize=8)
ax.text(N1+N2+N3/2, 0.9, 'B: Ber(.5)\nnew ctx', ha='center', fontsize=8)
ax.set_ylim(0, 1.05); ax.set_xlabel('Trial'); ax.set_ylabel('Behavioral value V(s)')
ax.set_title('a  Mean value stable throughout', loc='left', fontsize=10, fontweight='bold')
ax.legend(fontsize=7.5, frameon=False, loc='lower right')

# (b) channel spread = uncertainty signal
ax = axes[1]
for v in ['dist', 'joint']:
    sp = np.stack([r['spread_traj'] for r in res[v]])
    ax.plot(tt, sp.mean(0), color=colors[v], lw=1.6, label=labels[v])
for xb in (N1, N1 + N2):
    ax.axvline(xb, color='k', ls=':', lw=0.8)
ax.set_xlabel('Trial'); ax.set_ylabel('Channel spread (max − min)')
ax.set_title('b  Spread tracks reward variance\n(in-place uncertainty update)', loc='left', fontsize=10, fontweight='bold')
ax.legend(fontsize=7.5, frameon=False)

# (c) compartment-0 channels after P3
ax = axes[2]
taus = np.array(TAUS7)
ax.axhline(0.5, color='0.4', ls='--', lw=1.2, label='P2 endpoint (deterministic r=0.5)')
ber = np.sort([t*0.5/(t*0.5+(1-t)*0.5) for t in taus])  # = taus; Ber(.5) expectiles
ax.plot(taus, taus, 's:', color='0.6', ms=4, lw=1, label='Ber(.5) expectiles')
cd = np.mean([r['ch_final_c0'] for r in res['dist']], axis=0)
cj = np.mean([r['ch_final_c0'] for r in res['joint']], axis=0)
ax.plot(taus, cd, '^-', color=colors['dist'], ms=5, lw=1.6, mfc='none',
        label='Dist-only comp (overwritten)')
ax.plot(taus, cj, 'o-', color=colors['joint'], ms=5, lw=1.6, mfc='none',
        label='Joint comp-0 (preserved)')
ax.set_xlabel(r'Expectile level $\tau$'); ax.set_ylabel('Channel value')
ax.set_title('c  Comp-0 channels after ctx-B\nepisode', loc='left', fontsize=10, fontweight='bold')
ax.legend(fontsize=6.5, frameon=False, loc='upper left')

# (d) dissociation summary
ax = axes[3]
groups = ['Spread\nhigh-var', 'Spread\nlow-var', 'Preservation\nerror (L1)']
xg = np.arange(3); w = 0.34
for i, v in enumerate(('dist', 'joint')):
    vals = [np.mean([r['spread_after_highvar'] for r in res[v]]),
            np.mean([r['spread_after_lowvar'] for r in res[v]]),
            np.mean([r['preserve_L1'] for r in res[v]])]
    ax.bar(xg + (i - 0.5) * w, vals, w * 0.9, color=colors[v], label=labels[v])
ax.set_xticks(xg); ax.set_xticklabels(groups, fontsize=8)
ax.set_ylabel('Value'); ax.set_ylim(0, 0.95)
ax.set_title('d  Uncertainty ≠ novelty', loc='left', fontsize=10, fontweight='bold')
ax.legend(fontsize=7, frameon=False)

for a in axes:
    a.spines[['top', 'right']].set_visible(False)
fig.tight_layout()
fig.savefig(os.path.join(HERE, 'exp2_nonstationary.png'), dpi=220)
print('saved exp2_nonstationary.png')
