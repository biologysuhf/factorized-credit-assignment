"""
P2 Experiment 1: probabilistic reversal, factorized credit assignment.

Design (mirrors P1 context-reversal logic, made bandit):
  - Two arm stimuli a0 / a1 with FIXED features, identical in both contexts;
    the context cue (A / B) reaches the routing gate ONLY.
  - Context A: arm0 -> Ber(0.8) reward, arm1 -> Ber(0.2)   (arm0 optimal)
  - Context B (reversal): arm0 -> Ber(0.2), arm1 -> Ber(0.8) (arm1 optimal)
  - Phases: A (N1 trials) -> B (N2 trials) -> return to A (N3 probe trials,
    LEARNING OFF to measure pure retention, as in P1 probe tests).

Predictions (go/no-go):
  scalar (Q=1,C=1)     : relearning in B overwrites A -> poor return (forgetting)
  dist-only (Q=7,C=1)  : same interference, but good distributional fidelity
  comp-only (Q=1,C=2)  : contexts protected, no distribution
  joint (Q=7,C=2)      : both protected memory AND distributional fidelity
"""
import numpy as np
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from p2_model import FactorizedModel, TAUS7, make_states

P = {(0, 0): 0.8, (0, 1): 0.2,      # context A
     (1, 0): 0.2, (1, 1): 0.8}      # context B (reversed)
N1, N2, N3 = 300, 300, 30
EPS = 0.10
NOISE = 0.02          # small value noise so ties break ~50/50
NSEEDS = 10


def true_expectiles(p, taus):
    t = np.asarray(taus, float)
    return t * p / (t * p + (1 - t) * (1 - p))


def choose(model, x0, x1, ctx, rng, learn_on=True):
    if rng.random() < EPS:
        return rng.integers(0, 2)
    v0 = model.behavior_value(x0, ctx) + NOISE * rng.standard_normal()
    v1 = model.behavior_value(x1, ctx) + NOISE * rng.standard_normal()
    return int(v1 > v0)


def run(variant, seed):
    rng = np.random.default_rng(1000 + seed)
    Q = {'scalar': 1, 'dist': 7, 'comp': 1, 'joint': 7}[variant]
    C = {'scalar': 1, 'dist': 1, 'comp': 2, 'joint': 2}[variant]
    m = FactorizedModel(nfeat=16, Q=Q, C=C, seed=seed,
                        eta_c=[0.25] * C, lr_chan=0.25)
    X = make_states(2, 16, seed=7, overlap=0.0)   # arm0 / arm1 features
    x0, x1 = X[0], X[1]

    acc1 = np.zeros(N1); acc2 = np.zeros(N2); acc3 = np.zeros(N3)
    dist_l1 = np.nan

    for t in range(N1):                       # phase 1: context A
        a = choose(m, x0, x1, 0, rng)
        r = float(rng.random() < P[(0, a)])
        m.learn((x0, x1)[a], r, context=0)
        acc1[t] = float(a == 0)
    if Q == 7:                                # distribution fidelity @ end A
        dist_l1 = 0.0
        for arm, x, p in ((0, x0, 0.8), (1, x1, 0.2)):
            pred = np.sort(m.dist_values(x, compartment=0))
            dist_l1 += np.abs(pred - true_expectiles(p, TAUS7)).mean()
        dist_l1 /= 2
    for t in range(N2):                       # phase 2: context B (reversal)
        a = choose(m, x0, x1, 1, rng)
        r = float(rng.random() < P[(1, a)])
        m.learn((x0, x1)[a], r, context=1)
        acc2[t] = float(a == 1)
    for t in range(N3):                       # phase 3: probe A, learning OFF
        a = choose(m, x0, x1, 0, rng, learn_on=False)
        acc3[t] = float(a == 0)

    out = dict(
        a1_end=float(acc1[-20:].mean()),
        a2_start=float(acc2[:10].mean()),     # transfer into B
        a2_end=float(acc2[-20:].mean()),
        a3_probe=float(acc3[:10].mean()),     # retention of A after B
        switch_cost=float(acc1[-20:].mean() - acc2[:10].mean()),
        retention=float(acc3[:10].mean()),
    )
    if Q == 7:
        out['dist_L1'] = float(dist_l1)
    out['curve'] = np.concatenate([acc1, acc2, acc3])
    if Q == 7:
        out['ch0'] = np.sort(m.dist_values(x0, compartment=0))
        out['ch1'] = np.sort(m.dist_values(x1, compartment=0))
    return out


if __name__ == '__main__':
    variants = ['scalar', 'dist', 'comp', 'joint']
    res = {v: [] for v in variants}
    for v in variants:
        for s in range(NSEEDS):
            res[v].append(run(v, s))
    np.save(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         'exp1_results.npy'), res, allow_pickle=True)
    for v in variants:
        keys = res[v][0].keys()
        line = f"{v:9s}"
        for k in keys:
            vals = [r[k] for r in res[v]]
            line += f"  {k} {np.mean(vals):+.3f}±{np.std(vals):.3f}"
        print(line)
