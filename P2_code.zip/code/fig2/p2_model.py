"""
P2 go/no-go core model: factorized credit assignment.

  d_q (WHAT)      : Q distributional teaching channels with expectile-style
                    asymmetric scaling  d_q = alpha_q^+ * d  (d >= 0)
                                          alpha_q^- * d  (d < 0)
                    so channel q converges to the tau_q-expectile of the
                    reward distribution (Dabney et al. 2020 style).
  g_c (WHERE)     : compartment routing gate (context-given in Exp1/2,
                    learned in Exp3). The context cue reaches the GATE ONLY,
                    never the readout features -- as in P1.
  A_cq            : channel -> compartment coupling (fixed uniform in
                    Exp1/2, learned in Exp3).

Core update (compartment c):
      dv_c  = eta_c * g_c * x(s) * M_c ,   M_c = sum_q A_cq d_q
      d_q   = r - V_{q,c}(s),  V_{q,c}(s) = u_{q,c} . x(s)

Value predictions are read from the active compartment's own synapses
(as in P1 blocking: V is read from the compartment's synapses); the
dopamine population signal d_q is broadcast, plasticity is compartment-
gated.  C = 1 variants therefore suffer genuine interference: the same
stimulus features drive one shared readout under reversed rewards.
"""

import numpy as np

TAUS7 = (0.1, 0.25, 0.4, 0.5, 0.6, 0.75, 0.9)


def channel_alphas(Q, taus=None):
    if taus is None:
        if Q == 7:
            taus = TAUS7
        elif Q == 1:
            taus = (0.5,)                     # symmetric scalar RPE
        else:
            taus = tuple(np.linspace(0.1, 0.9, Q))
    taus = np.asarray(taus, float)
    assert len(taus) == Q
    return taus.copy(), 1.0 - taus          # alpha+, alpha-


class FactorizedModel:
    def __init__(self, nfeat=16, Q=7, C=2, seed=0, eta_c=None,
                 lr_chan=0.25, learn_A=False, learn_gate=False,
                 A_readout=False, lr_A=0.3):
        self.rng = np.random.default_rng(seed)
        self.N, self.Q, self.C = nfeat, Q, C
        self.eta_c = np.asarray(eta_c if eta_c is not None
                                else np.linspace(0.4, 0.1, C))
        self.lr_chan = lr_chan
        self.learn_A, self.learn_gate = learn_A, learn_gate
        self.A_readout = A_readout
        self.lr_A = lr_A
        self.u_ema = np.zeros(C)          # per-compartment utility baseline
        # per-compartment channel value readouts  V_{q,c}(s) = U[c,q] . x
        self.U = np.zeros((C, Q, nfeat))
        self.a_pos, self.a_neg = channel_alphas(Q)
        # per-compartment behavioural scalar readout
        self.Vw = np.zeros((C, nfeat))
        if learn_A:
            self.A = np.abs(self.rng.normal(0, 0.5, (C, Q))) + 0.2
        else:
            self.A = np.ones((C, Q)) / Q
        # learned-gate state (Exp3)
        self.proto = np.zeros((C, nfeat))
        self.proto_n = np.zeros(C)
        if learn_gate:                        # symmetry breaking (k-means init)
            P0 = self.rng.normal(0, 1, (C, nfeat))
            self.proto = P0 / np.linalg.norm(P0, axis=1, keepdims=True)
            self.proto_n = np.ones(C)         # pseudo-count
        self.gate_temp = 8.0
        self.gate_calls = 0
        self.last_g = np.zeros(C)
        self.last_M = np.zeros(C)

    # ---------- gate ----------
    def gate(self, x, context=None):
        if not self.learn_gate:
            g = np.zeros(self.C)
            g[(context or 0) % self.C] = 1.0
        else:
            self.gate_calls += 1
            temp = min(4.0 + self.gate_calls / 200.0, 12.0)   # sharpen over time
            sims = np.array([self._cos(x, self.proto[c]) for c in range(self.C)])
            # usage-balancing novelty: rarely used compartments stay attractive
            usage = self.proto_n / self.proto_n.sum()
            util = temp * sims - 1.0 * np.log(usage + 1e-6)
            g = np.exp(util - util.max())
            g /= g.sum()
        self.last_g = g
        return g

    @staticmethod
    def _cos(a, b):
        n = np.linalg.norm(a) * np.linalg.norm(b)
        return float(a @ b / n) if n > 0 else 0.0

    # ---------- learning ----------
    def learn(self, x, r, context=None, g_pre=None, obs=None):
        g = g_pre if g_pre is not None else self.gate(x, context)
        dq_all = np.zeros(self.Q)
        M = np.zeros(self.C)
        for c in range(self.C):
            if g[c] < 1e-3:
                continue
            Vq = self.U[c] @ x                      # (Q,)
            d = r - Vq
            dq = np.where(d >= 0, self.a_pos * d, self.a_neg * d)
            self.U[c] += (self.lr_chan * g[c]
                          * np.where(d >= 0, self.a_pos, self.a_neg)[:, None]
                          * d[:, None] * x[None, :])
            M[c] = float(self.A[c] @ dq)
            self.Vw[c] += self.eta_c[c] * g[c] * M[c] * x
            dq_all += dq
        if self.learn_A:
            Vc = float(g @ np.array([self.U[c] @ x @ np.ones(self.Q) / self.Q
                                     for c in range(self.C)])) \
                if g.any() else float(np.mean(self.U @ x))
            resid = r - Vc
            self.A += 0.05 * np.outer(g * resid, dq_all)
            np.clip(self.A, 0.0, None, out=self.A)
            rs = self.A.sum(axis=1, keepdims=True)
            rs[rs == 0] = 1.0
            self.A /= rs
        if self.learn_gate:
            xg = obs if obs is not None else x
            win = int(g.argmax())                    # winner-take-all update
            self.proto[win] = ((self.proto[win] * self.proto_n[win] + xg)
                               / (self.proto_n[win] + 1))
            self.proto_n[win] += 1
        self.last_M = M
        return g, M, dq_all

    def learn_utility(self, u, x, g):
        """REINFORCE-style utility gradient on A_cq:
        dA_c ~ g_c * (u - baseline_c) * V_{.,c}(x).  Same A then shapes both
        the teaching mixture M_c and the behavioural readout V_c."""
        Vq = self.U @ x                                       # (C,Q)
        for c in range(self.C):
            if g[c] < 1e-3:
                continue
            resid = u - self.u_ema[c]
            self.u_ema[c] += 0.05 * g[c] * resid
            self.A[c] += self.lr_A * g[c] * resid * Vq[c]
        np.clip(self.A, 0.0, None, out=self.A)
        rs = self.A.sum(axis=1, keepdims=True)
        rs[rs == 0] = 1.0
        self.A /= rs

    # ---------- behaviour / readout ----------
    def behavior_value(self, x, context=None, w=None):
        """Behavioural value read from the distributional channels:
        V(x) = sum_c g_c * (w . V_{.,c}(x)),  w = channel weights
        (uniform = risk-neutral mean; risk-skewed w -> risk sensitivity).
        For Q = 1 this reduces to the scalar-RPE value (the mean)."""
        Vq = np.stack([self.U[c] @ x for c in range(self.C)])   # (C,Q)
        if w is None:
            if self.A_readout:
                val = Vq * self.A                              # (C,Q)
                g_ = self.last_g if (self.learn_gate and self.last_g.any()) else None
                if g_ is None:
                    g_ = np.zeros(self.C)
                    g_[(context or 0) % self.C] = 1.0
                return float((g_ @ val.sum(axis=1)))
            w = np.ones(self.Q) / self.Q
        if self.learn_gate:
            g = self.last_g if self.last_g.any() \
                else np.ones(self.C) / self.C
        else:
            g = np.zeros(self.C)
            g[(context or 0) % self.C] = 1.0
        return float(g @ (Vq @ w))

    def dist_values(self, x, compartment=0):
        """Q channel values = learned expectiles of the reward dist."""
        return self.U[compartment] @ x

    def uncertainty(self, x, compartment=0):
        v = self.dist_values(x, compartment)
        return float(v.max() - v.min())


def make_states(n_states, nfeat, seed, overlap=0.0):
    rng = np.random.default_rng(seed)
    X = rng.normal(0, 1, (n_states, nfeat))
    if overlap > 0:
        base = rng.normal(0, 1, nfeat)
        X = np.sqrt(1 - overlap) * X + np.sqrt(overlap) * base[None, :]
    X /= np.linalg.norm(X, axis=1, keepdims=True)
    return X
